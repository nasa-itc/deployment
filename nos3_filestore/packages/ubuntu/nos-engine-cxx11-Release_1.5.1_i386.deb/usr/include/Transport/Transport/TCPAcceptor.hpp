/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_TCP_ACCEPTOR_HPP
#define NOS_ENGINE_TRANSPORT_TCP_ACCEPTOR_HPP

#include <Utility/IWorkHub.hpp>

#include <Transport/Types.hpp>
#include <Transport/Acceptor.hpp>
#include <Transport/Transport/TCPTransport.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \brief Represents a server which listens for connection requests from clients for
        /// the TCP transport.
        ///
        /// \see TCPConnector
        /// \see TCPConnection
        ///
        class NOS_ENGINE_TRANSPORT_API_PUBLIC TCPAcceptor :
            public Acceptor,
            public TCPTransport
        {
        private:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            typedef std::function<void(tcp::socket *socket)> BindSuccessCallback;

        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct and instance of the TCPAcceptor class.
            /// 
            /// \param uri      The URI which the Acceptor will listen on.
            /// \param work_hub The work hub to use for performing asyncronous work.
            /// 
            TCPAcceptor(const URI &uri, Utility::IWorkHub &work_hub);

        private:
            TCPAcceptor(const TCPAcceptor&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the TCPAcceptor class.
            /// 
            virtual ~TCPAcceptor();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            TCPAcceptor& operator=(const TCPAcceptor&); //!< Disable the copy assignment operator.

            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Handle stopping while listen operation is in-progress.
            ///
            /// \param socket The socket for the in-progress listen.
            ///
            void handle_stopping(tcp::socket *socket);

            ///
            /// \brief Handle failure for listen operation in-progress.
            ///
            /// \param socket The socket for the in-progress listen.
            ///
            void handle_failure(tcp::socket *socket);

            ///
            /// \brief Remove socket from collection.
            ///
            /// \param socket The socket to remove.
            ///
            void remove_socket(tcp::socket *socket);

            ///
            /// \brief Remove socket from collection and close it.
            ///
            /// \param socket The socket to remove and close.
            ///
            void remove_and_close_socket(tcp::socket *socket);

            ///
            /// \brief Bind to the socket for this Acceptor.
            ///
            /// \param socket   The socket to bind.
            /// \param callback Callback to execute when the bind is completed.
            ///
            void socket_bind(tcp::socket *socket, BindSuccessCallback callback);

            ///
            /// \brief Perform an accept (listen) operation.
            ///
            /// \param socket The socket to use for accepting.
            ///
            void socket_accept(tcp::socket *socket);

        protected:
            // ------------------------------------------------------------------------------------
            // Acceptor overrides
            // ------------------------------------------------------------------------------------

            virtual void process_acceptor_stop(std::unique_lock<std::mutex> &lock);

			virtual void process_listen(std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- sockets ----
            tcp::acceptor acceptor;                         //!< boost tcp acceptor
            std::vector<tcp::socket *> listening_sockets;   //!< collection of listening sockets
        };
    }
}

#endif