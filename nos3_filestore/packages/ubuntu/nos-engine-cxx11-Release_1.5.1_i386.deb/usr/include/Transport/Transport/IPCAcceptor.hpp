/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_IPC_ACCEPTOR_HPP
#define NOS_ENGINE_TRANSPORT_IPC_ACCEPTOR_HPP

#include <ItcIpc/MessageQueue/Server.hpp>

#include <Utility/IWorkHub.hpp>

#include <Transport/Types.hpp>
#include <Transport/Acceptor.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \brief Represents a server which listens for connection requests from clients for
        /// the interprocess communication transport.
        ///
        /// \see IPCConnector
        /// \see IPCConnection
        ///
        class NOS_ENGINE_TRANSPORT_API_PUBLIC IPCAcceptor :
            public Acceptor
        {
        private:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            typedef std::shared_ptr<ItcIpc::MessageQueue::Server> MessageQueueServerPtr;
            typedef std::weak_ptr<ItcIpc::MessageQueue::Server> MessageQueueServerWeakPtr;
            typedef std::deque<ItcIpc::MessageQueue::ClientId> IPCConnectedClients;

        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct and instance of the IPCAcceptor class.
            /// 
            /// \param uri      The URI which the Acceptor will listen on.
            /// \param work_hub The work hub to use for performing asyncronous work.
            /// 
            IPCAcceptor(const URI &uri, Utility::IWorkHub &work_hub);

        private:
            IPCAcceptor(const IPCAcceptor&);    //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the CopyAcceptor class.
            /// 
            virtual ~IPCAcceptor();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            IPCAcceptor& operator=(const IPCAcceptor&); //!< Disable the copy assignment operator.

            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Called when a client connects to the IPC MessageQueue server.
            ///
            /// \param id The id of the new client.
            ///
            void on_client_connect(ItcIpc::MessageQueue::ClientId id);

            ///
            /// \brief Called when a client disconnects from the IPC MessageQueue server.
            ///
            /// \param id The id of the client that disconnected.
            ///
            void on_client_disconnect(ItcIpc::MessageQueue::ClientId id);

            ///
            /// \brief Process a IPC listen operation.
            ///
            /// \param lock A lock that has acquired get_mutex().
            ///
            void ipc_process(std::unique_lock<std::mutex> &lock);

        protected:
            // ------------------------------------------------------------------------------------
            // Acceptor overrides
            // ------------------------------------------------------------------------------------

            virtual void process_acceptor_stop(std::unique_lock<std::mutex> &lock);

			virtual void process_listen(std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- ipc message queue ----
            MessageQueueServerPtr server;   //!< IPC MessageQueue server.
            IPCConnectedClients clients;    //!< IDs of connected clients.
        };
    }
}

#endif

