/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_IACCEPTOR_HPP
#define NOS_ENGINE_TRANSPORT_IACCEPTOR_HPP

#include <Utility/Events/IOnDestroy.hpp>
#include <Utility/States/IStoppable.hpp>

#include <Transport/Types.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \brief Represents a server which listens for connection requests from clients.
        ///
        /// \see IConnector
        /// \see IConnection
        ///
        class IAcceptor :
            public virtual Utility::IEngineThreadSafeObjectWithCV,
            public virtual Utility::Events::IOnDestroy,
            public virtual Utility::States::IStoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IAcceptor class.
            ///
            /// \note Derived classes are responsible for calling stop() on destruction.
            /// 
            virtual ~IAcceptor() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the URI which the Acceptor is listening on.
            ///
            /// \return The URI.
            ///
            virtual const URI &get_uri() = 0;

            ///
            /// \brief Syncronously (blocking) listen for a new connection request.
            ///
            /// \return The Connection instance representing the successfully established
            /// connection to the client.
            ///
            virtual Connection *listen_blocking() = 0;

            ///
            /// \brief Ayncronously (non-blocking) listen for a new connection request.
            ///
            /// \param callback The callback to execute when a connection is successfully
            /// established with a client (or an error occurs).
            ///
            virtual void listen_async(ListenCallback callback) = 0;

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Stop the Acceptor implementation.
            ///
            /// \param lock A lock that has acquired a lock of get_stoppable_mutex().
            ///
            virtual void process_acceptor_stop(std::unique_lock<std::mutex> &lock) = 0;

            ///
            /// \brief Perform a listen operation.
            ///
            /// \param lock A lock that has acquired a lock of get_mutex().
            ///
            virtual void process_listen(std::unique_lock<std::mutex> &lock) = 0;
        };
    }
}

#endif