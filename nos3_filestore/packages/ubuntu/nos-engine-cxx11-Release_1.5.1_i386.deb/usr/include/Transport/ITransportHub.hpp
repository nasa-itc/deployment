/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_ITRANSPORT_HUB_HPP
#define NOS_ENGINE_TRANSPORT_ITRANSPORT_HUB_HPP

#include <Utility/States/IStoppable.hpp>

#include <Transport/Types.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \brief Represents a hub that manages a collection of threads which are used for
        /// performing listen and connect operations.
        ///
        /// When the transport hub is stopped all Acceptor, Connectors, and Connections which
        /// were created via the hub will also be stopped.
        ///
        class ITransportHub :
            public virtual Utility::IEngineThreadSafeObjectWithCV,
            public virtual Utility::States::IStoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the ITransportHub class.
            /// 
            virtual ~ITransportHub() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \copydoc IAcceptor::listen_blocking()
            ///
            /// \param local_uri The URI to listen on.
            ///
            virtual Connection *listen_blocking(const std::string &local_uri) = 0;

            ///
            /// \copydoc IAcceptor::listen_async(ListenCallback)
            ///
            /// \param local_uri The URI to listen on.
            ///
            virtual void listen_async(const std::string &local_uri, ListenCallback callback) = 0;

            ///
            /// \copydoc IConnector::connect_blocking(const size_t, const size_t, const size_t)
            ///
            /// \param remote_uri The URI to connect to.
            ///
            virtual Connection *connect_blocking(
                const std::string &remote_uri,
                const size_t retries = DEFAULT_CONNECT_RETRY_COUNT,
                const size_t retry_delay = DEFAULT_CONNECT_RETRY_DELAY_MS,
                const size_t attempt_timeout = DEFAULT_CONNECT_ATTEMPT_TIMEOUT_MS) = 0;

            ///
            /// \copydoc IConnector::connect_async(ConnectCallback, const size_t, const size_t, const size_t)
            ///
            /// \param remote_uri The URI to connect to.
            ///
            virtual void connect_async(
                const std::string &remote_uri,
                ConnectCallback callback,
                const size_t retries = DEFAULT_CONNECT_RETRY_COUNT,
                const size_t retry_delay = DEFAULT_CONNECT_RETRY_DELAY_MS,
                const size_t attempt_timeout = DEFAULT_CONNECT_ATTEMPT_TIMEOUT_MS) = 0;

            ///
            /// \brief Get the Utility::IWorkHub that is used for async listen/connect operations.
            ///
            /// \return The Utility::IWorkHub for async operations.
            ///
            virtual Utility::IWorkHub &get_work_hub() = 0;

            ///
            /// \brief Get the existing Acceptor that is used to listen on the specified URI.
            ///
            /// \param local_uri The local URI of an existing Acceptor.
            ///
            /// \return The Acceptor for the URI.
            ///
            virtual Acceptor *get_acceptor(const std::string &local_uri) = 0;

            ///
            /// \brief Get a collection containing all Acceptors.
            ///
            virtual AcceptorVector get_acceptors() = 0;

            ///
            /// \brief Get the existing Connector that is used to connect on the specified URI.
            ///
            /// \param remote_uri The remove URI of an existing Connector.
            ///
            /// \return The Connector for the URI.
            ///
            virtual Connector *get_connector(const std::string &remote_uri) = 0;

            ///
            /// \brief Get a collection containing all Connectors.
            ///
            virtual ConnectorVector get_connectors() = 0;

            ///
            /// \brief Get a collection containing all server Connections (ie connections
            /// created for listen operations).
            ///
            virtual ConnectionVector get_server_connections() = 0;

            ///
            /// \brief Get a collection containing all server Connections (ie connections
            /// created for listen operations) for the specified URI.
            ///
            /// \param local_uri The local URI to filter server connections by.
            ///
            virtual ConnectionVector get_server_connections(const std::string &local_uri) = 0;

            ///
            /// \brief Get a collection containing all client Connections (ie connections
            /// created for connect operations).
            ///
            virtual ConnectionVector get_client_connections() = 0;

            ///
            /// \brief Get a collection containing all client Connections (ie connections
            /// created for connect operations) for the specified URI.
            ///
            /// \param local_uri The remote URI to filter client connections by.
            ///
            virtual ConnectionVector get_client_connections(const std::string &remote_uri) = 0;
        };
    }
}

#endif