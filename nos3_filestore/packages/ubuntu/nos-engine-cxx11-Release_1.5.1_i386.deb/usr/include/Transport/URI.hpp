/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_URI_HPP
#define NOS_ENGINE_TRANSPORT_URI_HPP

#include <string>
#include <vector>
#include <functional>

#include <boost/lexical_cast.hpp>

#include <Transport/Types.hpp>
#include <Transport/IURI.hpp>
#include <Transport/Error.hpp>

namespace NosEngine
{
    namespace Transport
    {
        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC std::string URI_SCHEME_DELIMITER;
        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC std::string URI_PARAM_DELIMITER;

        /// 
        /// \copydoc IURI
        /// 
        class NOS_ENGINE_TRANSPORT_API_PUBLIC URI :
            public IURI
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the URI class.
            /// 
            /// \param uri URI string.
            ///
            /// \throw Transport::Error::InvalidURI if URI validation fails.
            /// \throw Utility::Error::NotFound if a transport registration for the scheme of the
            /// URI can't be found.
            /// 
            URI(const std::string &uri);
            
            /// 
            /// \brief Construct an instance of the URI class.
            /// 
            /// \param uri URI string.
            /// \param registry Transporty registry to use for scheme lookup and URI validation.
            ///
            /// \throw Transport::Error::InvalidURI if URI validation fails.
            /// \throw Utility::Error::NotFound if a transport registration for the scheme of the
            /// URI can't be found.
            /// 
            URI(const std::string &uri, TransportRegistry &registry);
            
            /// 
            /// \brief Destructor for an instance of the URI class.
            /// 
            virtual ~URI();

            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Conversion operator for std::string.
            /// 
            virtual operator std::string() const;

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IURI implementation
            // ------------------------------------------------------------------------------------

            virtual const std::string &to_string() const;
            
            virtual const std::string &get_scheme() const;
            
            virtual const std::string &operator[] (const URIParameters::size_type &index) const;
            
            virtual const URIParameters &get_parameters() const;

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Parse the scheme and parameters out of the URI string.
            ///
            /// \throw Transport::Error::InvalidURI if parsing fails.
            ///
            void parse();

            ///
            /// \brief Validate this URI using the provided transport registry.
            /// 
            /// \param registry Transporty registry to use for scheme lookup and URI validation.
            ///
            /// \throw Transport::Error::InvalidURI if URI validation fails.
            /// \throw Utility::Error::NotFound if a transport registration for the scheme of the
            /// URI can't be found.
            ///
            void validate(TransportRegistry &registry);

        protected:
            // ------------------------------------------------------------------------------------
            // IURI implementation
            // ------------------------------------------------------------------------------------

            virtual bool get_bool_parameter(const URIParameters::size_type &index) const;

            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            std::string uri;        //!< The original URI string (trimmed).
            std::string scheme;     //!< The scheme string from the URI.
            URIParameters params;   //!< The parameters from the URI (stored as strings).
        };
    }
}

#endif