/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_CONNECTOR_HPP
#define NOS_ENGINE_TRANSPORT_CONNECTOR_HPP

#include <string>
#include <deque>
#include <functional>
#include <memory>

#include <Utility/IWorkHub.hpp>
#include <Utility/Events/OnDestroy.hpp>
#include <Utility/States/Stoppable.hpp>

#include <Transport/Types.hpp>
#include <Transport/Globals.hpp>
#include <Transport/IConnector.hpp>
#include <Transport/Result.hpp>
#include <Transport/URI.hpp>

namespace NosEngine {
namespace Transport {

///
/// \copydoc IConnector
///
class NOS_ENGINE_TRANSPORT_API_PUBLIC Connector :
    public IConnector,
    public Utility::Events::OnDestroy,
    public Utility::States::Stoppable {
private:
    // ============================================================================================
    // Types
    // --------------------------------------------------------------------------------------------

    struct ConnectOperation {
        size_t retry_count;
        size_t max_retries;
        size_t retry_delay;
        size_t attempt_timeout;
        Utility::TimerId timer_id;
        std::function<void(const bool, ConnectCallback)> connect_worker;
        ConnectCallback callback;
    };

    typedef std::list<ConnectOperation> ConnectOperations;

protected:
    // ============================================================================================
    // Life cycle
    // --------------------------------------------------------------------------------------------

    /// 
    /// \brief Construct and instance of the Connector class.
    /// 
    /// \param scheme   The expected scheme for validating the provided URI.
    /// \param uri      The URI which the Connector will connect to.
    /// \param work_hub The work hub to use for performing asyncronous work.
    /// 
    Connector(const std::string &scheme, const URI &uri, Utility::IWorkHub &work_hub);

private:
    Connector();                    //!< Disable the default constructor.
    Connector(const Connector &);   //!< Disable the copy constructor.

public:
    /// 
    /// \brief Destructor for an instance of the Connector class.
    ///
    /// \note Derived classes are responsible for calling stop() on destruction.
    /// 
    virtual ~Connector();

private:
    // ============================================================================================
    // Operators
    // --------------------------------------------------------------------------------------------

    Connector& operator=(const Connector&); //!< Disable the copy assignment operator.

public:
    // ============================================================================================
    // Public API
    // --------------------------------------------------------------------------------------------

    // --------------------------------------------------------------------------------------------
    // IConnector implementation
    // --------------------------------------------------------------------------------------------

    virtual const URI &get_uri();

    virtual Connection *connect_blocking(
        const size_t retries = DEFAULT_CONNECT_RETRY_COUNT,
        const size_t retry_delay = DEFAULT_CONNECT_RETRY_DELAY_MS,
        const size_t attempt_timeout = DEFAULT_CONNECT_ATTEMPT_TIMEOUT_MS);

    virtual void connect_async(
        ConnectCallback callback,
        const size_t retries = DEFAULT_CONNECT_RETRY_COUNT,
        const size_t retry_delay = DEFAULT_CONNECT_RETRY_DELAY_MS,
        const size_t attempt_timeout = DEFAULT_CONNECT_ATTEMPT_TIMEOUT_MS);

private:
    // ============================================================================================
    // Internal API
    // --------------------------------------------------------------------------------------------

    ///
    /// \brief Execute the callback stored in Connector::connect_result with the result stored in
    /// Connector::connect_result.
    ///
    /// \param lock A lock that has acquired a lock of get_mutex().
    ///
    void exec_callback(std::unique_lock<std::mutex> &lock);

    ///
    /// \brief Execute the callback.
    ///
    /// If an error occurred during the connect operation the error will be stored in
    /// Connector::connect_result and passed to the callback.
    ///
    /// \param callback     The callback to execute.
    /// \param connection   The connection for the current connect operation (nullptr when error).
    ///
    void exec_callback(const ConnectCallback &callback, Connection *connection);

protected:
    // --------------------------------------------------------------------------------------------
    // IConnector implementation
    // --------------------------------------------------------------------------------------------

    ///
    /// \brief Post a work item to Connector::work_hub which executes the current connect
    /// callback stored in Connector::connect_result with the result stored in
    /// Connector::connect_result.
    ///
    virtual void post_result();

    // --------------------------------------------------------------------------------------------
    // IConnector (IEngineThreadSafeObjectWithCV) implementation
    // --------------------------------------------------------------------------------------------

    virtual std::mutex &get_mutex() const;

    virtual std::condition_variable &get_cv() const;

    // ------------------------------------------------------------------------------------
    // Stoppable implementation
    // ------------------------------------------------------------------------------------

    virtual bool is_stopping_no_lock() const;

    virtual void set_stopping_no_lock(const bool &stopping);

    virtual bool is_stopped_no_lock() const;

    virtual void set_stopped_no_lock(const bool &stopped);

    virtual void process_stop(std::unique_lock<std::mutex> &lock);

    // ============================================================================================
    // Data members
    // --------------------------------------------------------------------------------------------

    // ---- configuration ----
    URI uri;                                        //!< The URI which the Connector connects to.

    // ---- threading ----
    Utility::IWorkHub &work_hub;                    //!< The hub which the Connector is using to perform async work.
    NosEngine::Utility::WorkChain *connect_chain;   //!< Work chain the Connector is using to perform async work serially.
    ConnectOperations connect_operations;           //!< Collection of ConnectOperation for currently queued connect operations.

    // ---- thread syncronization ----
    mutable std::mutex mutex;
    mutable std::condition_variable cond;

    // ---- connect operation result ----
    ConnectResultPtr connect_result;                //!< For storing connect opertion results.

    // ---- status ----
    bool stopping;                                  //!< Indicates if the Connector is stopping.
    bool stopped;                                   //!< Indicates if the Connector is stopped.
};

}}

#endif

