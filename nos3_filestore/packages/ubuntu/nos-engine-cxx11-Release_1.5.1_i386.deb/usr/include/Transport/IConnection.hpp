/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_ICONNECTION_HPP
#define NOS_ENGINE_TRANSPORT_ICONNECTION_HPP

#include <Utility/Events/IOnDestroy.hpp>
#include <Utility/States/IStoppable.hpp>

#include <Transport/Types.hpp>
#include <Transport/Events/IOnDisconnected.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \brief Represents a connection between a client and server.
        ///
        /// \see IAcceptor
        /// \see IConnector
        ///
        class IConnection :
            public virtual Utility::IEngineThreadSafeObjectWithCV,
            public virtual Utility::Events::IOnDestroy,
            public virtual Transport::Events::IOnDisconnected,
            public virtual Utility::States::IStoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IConnection class.
            ///
            /// \note Derived classes are responsible for calling stop() on destruction.
            /// 
            virtual ~IConnection() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the URI for this end of the connection.
            ///
            /// \return The URI.
            ///
            virtual const URI &get_local_uri() const = 0;

            ///
            /// \brief Get the URI for the other end of the connection.
            ///
            /// \return The URI.
            ///
            virtual const URI &get_remote_uri() const = 0;

            ///
            /// \brief Get a value indicating if the connection is still established.
            ///
            /// \return true if the connection is still established.
            ///
            virtual bool is_connected() = 0;

            ///
            /// \brief Syncronously (blocking) send the data contained in the buffer, accross
            /// the connection, to the other end.
            ///
            /// \param buffer A buffer containing the data to send.
            ///
            virtual void send_blocking(Utility::Buffer *buffer) = 0;

            ///
            /// \brief Ayncronously (non-blocking) send the data contained in the buffer, accross
            /// the connection, to the other end.
            ///
            /// The callback being called does not necessarily mean that the other end of the
            /// connection has received the data.
            ///
            /// \param buffer A buffer containing the data to send.
            /// \param callback The callback to execute when the send operation is completed
            /// (or an error occurs).
            ///
            virtual void send_async(Utility::Buffer *buffer, SendCallback callback) = 0;

            ///
            /// \brief Syncronously (blocking) receive data, accross the connection, from the
            /// other end.
            ///
            /// \return A buffer containing the data received.
            ///
            virtual Utility::Buffer *receive_blocking() = 0;

            ///
            /// \brief Ayncronously (non-blocking) receive data, accross the connection, from the
            /// other end.
            ///
            /// \param callback The callback to execute when data is received (or an error occurs).
            ///
            virtual void receive_async(ReceiveCallback callback) = 0;

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Stop the Connection implementation.
            ///
            /// \param lock A lock that has acquired a lock of get_stoppable_mutex().
            ///
            virtual void process_connection_stop(std::unique_lock<std::mutex> &lock) = 0;

            ///
            /// \brief Perform a send operation.
            ///
            /// \param lock A lock that has acquired a lock of get_mutex().
            ///
            virtual void process_send(Utility::Buffer *buffer, std::unique_lock<std::mutex> &lock) = 0;

            ///
            /// \brief Perform a receive operation.
            ///
            /// \param lock A lock that has acquired a lock of get_mutex().
            ///
            virtual void process_receive(std::unique_lock<std::mutex> &lock) = 0;
        };
    }
}

#endif