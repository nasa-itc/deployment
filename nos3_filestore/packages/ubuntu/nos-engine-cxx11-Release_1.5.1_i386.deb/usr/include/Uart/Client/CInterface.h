/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UART_C_INTERFACE
#define NOS_ENGINE_UART_C_INTERFACE

#include <Uart/visibility.hpp>
#include <stdint.h>
#include <stddef.h>

#include <Client/CInterface.h>

#ifdef __cplusplus
    #include <Uart/Client/Uart.hpp>
    typedef NosEngine::Uart::Uart NE_Uart;
#else
    typedef struct NE_Uart NE_Uart;
#endif

#ifdef __cplusplus
extern "C"
{
#endif

/*
 * \brief UART data callback function
 */
typedef void(*NE_UartDataCallback)(const uint8_t *buf, size_t len, void *user);

/*
 * \brief UART status codes
 */
typedef enum
{
    NE_UART_SUCCESS = 0,
    NE_UART_FAILURE
} NE_UartStatus;
 
/*
 * \brief Open a UART port on the named bus
 *
 * \param name Device name
 * \param connection NOS connection string
 * \param bus UART bus name
 * \param port UART port
 *
 * \return UART handle
 */
extern NOS_ENGINE_UART_API_PUBLIC
NE_Uart* NE_uart_open(const char *name, const char *connection, const char *bus, uint8_t port);

/*
 * \brief Open a UART port on the named bus
 *
 * \param name Device name
 * \param connection NOS connection string
 * \param bus UART bus name
 * \param port UART port
 * \param num_service_threads The number of service threads that should be created
 *
 * \return UART handle
 */
extern NOS_ENGINE_UART_API_PUBLIC
NE_Uart* NE_uart_open2(const char *name, const char *connection, const char *bus, uint8_t port, const size_t num_service_threads);

/*
 * \brief Open a UART port on the named bus
 *
 * \param transport_hub Existing transport hub to use
 * \param name Device name
 * \param connection NOS connection string
 * \param bus UART bus name
 * \param port UART port
 *
 * \return UART handle
 */
extern NOS_ENGINE_UART_API_PUBLIC
NE_Uart* NE_uart_open3(NE_TransportHub *transport_hub, const char *name, const char *connection, const char *bus, uint8_t port);

/**
 * \brief Get the transport hub of the UART device.
 * 
 * If the device owns the hub (ie hub was not provided to the init function) then use
 * the hub returned with caution.  When this device is closed the hub it owns
 * will be destroyed as well.
 * 
 * \return The tranport hub of the UART device.
*/
extern NOS_ENGINE_UART_API_PUBLIC
NE_TransportHub* NE_uart_get_transport_hub(NE_Uart *uart);

/*
 * \brief Close UART port
 *
 * \note Handle is no longer valid after port is closed
 *
 * \param uart UART handle
 *
 * \return Status code
 */
extern NOS_ENGINE_UART_API_PUBLIC
NE_UartStatus NE_uart_close(NE_Uart **uart);

/*
 * \brief Set new message received callback
 *
 * \param uart UART handle
 * \param cb Callback function
 * \param user User data
 */
extern NOS_ENGINE_UART_API_PUBLIC
void NE_uart_set_read_callback(NE_Uart *uart, NE_UartDataCallback cb, void *user);

/*
 * \brief Read data from the UART
 *
 * \param uart UART handle
 * \param buf Buffer to read data into
 * \param len Number of bytes to read
 *
 * \return Number of bytes read
 */
extern NOS_ENGINE_UART_API_PUBLIC
size_t NE_uart_read(NE_Uart *uart, uint8_t *buf, size_t len);

/*
 * \brief Read character from the UART port
 *
 * \param uart UART handle
 * \param c Character to store read data
 *
 * \return Status code
 */
extern NOS_ENGINE_UART_API_PUBLIC
NE_UartStatus NE_uart_getc(NE_Uart *uart, uint8_t *c);

/*
 * \brief Write data to the UART
 *
 * \param uart UART handle
 * \param buf Data buffer to write
 * \param len Number of bytes to write
 *
 * \return Number of bytes written
 */
extern NOS_ENGINE_UART_API_PUBLIC
size_t NE_uart_write(NE_Uart *uart, const uint8_t *const buf, size_t len);

/*
 * \brief Write character to the UART port
 *
 * \param uart UART handle
 * \param c Character to transmit
 */
extern NOS_ENGINE_UART_API_PUBLIC
void NE_uart_putc(NE_Uart *uart, uint8_t c);

/*
 * \brief Get number of bytes available in data queue
 *
 * \param uart UART handle
 *
 * \return Number of bytes available in data queue
 */
extern NOS_ENGINE_UART_API_PUBLIC
size_t NE_uart_available(NE_Uart *uart);

/*
 * \brief Flush data queue
 *
 * \param uart UART handle
 */
extern NOS_ENGINE_UART_API_PUBLIC
void NE_uart_flush(NE_Uart *uart);

/*
 * \brief Set message queue size
 *
 * \param uart UART handle
 * \param queue_size Data queue size in number of messages
 */
extern NOS_ENGINE_UART_API_PUBLIC
void NE_uart_set_queue_size(NE_Uart *uart, unsigned int queue_size);

#ifdef __cplusplus
}
#endif

#endif

