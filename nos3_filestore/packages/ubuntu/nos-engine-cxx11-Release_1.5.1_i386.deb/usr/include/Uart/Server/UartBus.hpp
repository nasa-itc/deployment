/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UART_UART_BUS_HPP
#define NOS_ENGINE_UART_UART_BUS_HPP

#include <Uart/visibility.hpp>
#include <Server/Bus.hpp>
#include <string>
#include <map>

namespace NosEngine
{
    namespace Common
    {
        class MessageRouter;
    }

    namespace Server
    {
        class DataNode;
    }

    namespace Uart
    {
        class UartBusRouter;

        /*
         * \brief Server side bus for the UART protocol
         */
        class NOS_ENGINE_UART_API_PUBLIC UartBus : public Server::Bus
        {
        public:
            /*
             * \brief Create the server side UART bus
             * 
             * \param name Bus name
             */
            UartBus(NosEngine::Utility::IWorkHub &work_hub, const std::string& name);

            /*
             * \brief Destructor
             */
            ~UartBus();

            /*
             * \brief Get the protocol identifier string
             * 
             * \return Protocol identifier string
             */
            virtual std::string get_protocol() const;

            /*
             * \brief Get the UART bus router
             *
             * \return UART bus router
             */
            virtual Common::IMessageRouter* get_router() const;

            /*
             * \brief Open the UART data node port connection
             *
             * \param port UART port
             * \param name Data node name
             *
             * \return True on success
             */
            bool open(unsigned int port, const std::string& name);

            /*
             * \brief Close the UART data node port connection
             *
             * \param port UART port
             * \param name Data node name
             *
             * \return True on success
             */
            bool close(unsigned int port, const std::string& name);

            /*
             * \brief Get the connected data node
             *
             * \param src Source data node name
             *
             * \return Destination data node name or empty string if no connection
             */
            std::string get_connected_node(const std::string& src);

        private:
            UartBusRouter *router; //!< UART bus router

            typedef std::map<std::string, unsigned int> PortMap;
            PortMap ports; //!< Data node ports

            typedef std::pair<Server::DataNode*, Server::DataNode*> NodePair;
            typedef std::map<unsigned int, NodePair> ConnectionMap;
            ConnectionMap connections; //!< UART port connections
        };
    }
}

#endif

