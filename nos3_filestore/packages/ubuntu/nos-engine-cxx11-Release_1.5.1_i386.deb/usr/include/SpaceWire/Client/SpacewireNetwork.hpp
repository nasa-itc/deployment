/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SPACEWIRE_CLIENT_SPACEWIRELINK_HPP
#define NOS_ENGINE_SPACEWIRE_CLIENT_SPACEWIRELINK_HPP

#include <SpaceWire/visibility.hpp>
#include <SpaceWire/Client/types.hpp>
#include <Client/types.hpp>
#include <Transport/TransportHub.hpp>
#include <unordered_map>

namespace NosEngine
{
    namespace SpaceWire
    {
        namespace Client
        {
            /**
                \brief Represets a logical group of SpaceWire nodes/routers for a SpacewireNetwork.
                
                Nodes are capable of sending and receiving packets to other nodes in the
                same network.
            */
            class NOS_ENGINE_SPACEWIRE_API_PUBLIC SpacewireNetwork
            {
            public:
                /**
                    \brief Instantiate a client-side spacewire network object.
                    
                    \param server_uri           The transport connection string
                    \param name                 Unique name for the network
                    \param num_service_threads  The number of service threads that should be created

                    \throw runtime_error if the server doesn't have a protocol available for SpaceWire
                */
                SpacewireNetwork(std::string server_uri, std::string name, const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);

                /**
                    \brief Instantiate a client-side spacewire network object.
                    
                    \param transport_hub    Existing transport hub to use
                    \param server_uri       The transport connection string
                    \param name             Unique name for the network

                    \throw runtime_error if the server doesn't have a protocol available for SpaceWire
                */
                SpacewireNetwork(NosEngine::Transport::TransportHub &transport_hub, std::string server_uri, std::string name);

                ~SpacewireNetwork();

                /**
                    \brief Get the transport hub used by this instance.

                    If the instance owns the hub (ie hub was not provided to the constructor) then use
                    the hub returned with caution.  When this instance is destroyed the hub it owns
                    will be destroyed as well.

                    \return The tranport hub of this instance.
                */
                Transport::TransportHub &get_transport_hub() const;

                /**
                    \brief Get a node from the network.

                    This method will not create and register a node in the network if it does not exist.
                    The port for the node must be unique at the spacewire router-level (does not have to be globally unique across all routers)

                    \param router_name  the name of the router the node is connected to
                    \param router_port  unique address for the router output port which the node is connected to

                    \throw runtime_error if the port is invalid
                */
                SpacewireNode* get_spacewire_node(const std::string router_name, const Address router_port);

                /**
                    \brief Get a node from the network. If the node does not exist, it is created.

                    This method will create and register a node in the network if it does not already exist.
                    The name for the node must be unique at the spacewire router-level (does not have to be globally unique across all routers)

                    \param router_name  the name of the router the node is connected to
                    \param router_port  unique address for the router output port which the node is connected to

                    \throw runtime_error if the port is invalid
                */
                SpacewireNode* get_or_create_spacewire_node(const std::string router_name, const Address router_port);

                /**
                    \brief Remove an existing node from the network.

                    This method will remove a node from the network if possible. In the event that the node is not
                    known to this SpacewireNetwork object, the operation will simply return.

                    \param router_name  the name of the router the node is connected to
                    \param router_port  unique address for the router output port which the node is connected to

                    \throw runtime_error if the port is invalid
                */
                void remove_spacewire_node(const std::string router_name, const Address router_port);
            private:
                typedef std::unordered_map<std::string, SpacewireNode*> SpacewireNodeNameMap;

                NosEngine::Client::IBus* bus;
                SpacewireNodeNameMap spacewire_node_name_map;
            };
        }
    }
}

#endif /* NOS_ENGINE_SPACEWIRE_CLIENT_SPACEWIRELINK_HPP */
