/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_SERIALIZATION_ISERIALIZABLE_HPP
#define NOS_ENGINE_UTILITY_SERIALIZATION_ISERIALIZABLE_HPP

#include <Utility/Types.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \brief Interface for an object that can be serialized/deserialized.
        ///
        class ISerializable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the ISerializable class.
            /// 
            virtual ~ISerializable() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the size of the object, in bytes, when serialized.
            ///
            /// Returning an size smaller or larger than actually needed is valid, but
            /// is sub-optimal.
            ///
            /// \return The serialized size.
            ///
            virtual size_t get_serialized_size() const = 0;

            ///
            /// \brief Serialize this object using the provided ISerializer.
            ///
            /// \param serializer ISerializer to use to serialize this object.
            ///
            virtual void serialize(ISerializer &serializer) const = 0;

            ///
            /// \brief Deserialize this object using the provided IDeserializer.
            ///
            /// \param deserializer IDeserializer to use to deserialize this object.
            ///
            virtual void deserialize(IDeserializer &deserializer) = 0;
        };
    }
}

#endif // NOS_ENGINE_UTILITY_SERIALIZATION_ISERIALIZABLE_HPP