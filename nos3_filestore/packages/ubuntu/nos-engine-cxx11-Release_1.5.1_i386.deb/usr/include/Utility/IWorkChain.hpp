/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_IWORK_CHAIN_HPP
#define NOS_ENGINE_UTILITY_IWORK_CHAIN_HPP

#include <Utility/Types.hpp>
#include <Utility/Globals.hpp>
#include <Utility/Events/IOnDestroy.hpp>
#include <Utility/Events/IOnError.hpp>
#include <Utility/States/IPauseable.hpp>
#include <Utility/States/ICancelable.hpp>
#include <Utility/States/IStoppable.hpp>
#include <Utility/IWorkChainWorkWrapper.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \brief Represents a chain of work that is executed serialally in a work hub even
        /// if the work hub has more than one service thread.
        ///
        class IWorkChain :
            public virtual IEngineThreadSafeObjectWithCV,
            public virtual Events::IOnDestroy,
            public virtual Events::IOnError,
            public virtual States::IPauseable,
            public virtual States::ICancelable,
            public virtual States::IStoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IWorkChain class.
            /// 
            virtual ~IWorkChain() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get a value indicating if the current thread is the thread which
            /// is executing the current work chain work.
            /// 
            /// \return true if the current thread is executing work chain work.
            ///
            virtual bool in_chain_thread() const = 0;

            ///
            /// \brief Wait for callbacks associated with currently posted work to be called.
            /// 
            /// - The default for the timeout parameter is INFINITE_TIMEOUT.
            ///   + Passing in INFINITE_TIMEOUT for the timeout parameter waits forever.
            ///
            /// \param timeout The amount of time to wait for the callbacks to be called.
            /// 
            /// \throw Error::OperationTimedout if the callbacks were not called before the timeout was hit.
            ///
            virtual void wait_for_callbacks(const Timeout &timeout = INFINITE_TIMEOUT) = 0;

            ///
            /// \brief Wait for callbacks associated with current work to be called.
            ///
            /// \param timeout An absolute time to wait to for the callbacks to be called.
            /// 
            /// \throw Error::OperationTimedout if the callbacks were not called before the timeout was hit.
            ///
            virtual void wait_for_callbacks(const TimeoutClock::time_point &timeout) = 0;

            ///
            /// \brief Wait for currently posted work to finish.
            /// 
            /// - The default for the timeout parameter is INFINITE_TIMEOUT.
            ///   + Passing in INFINITE_TIMEOUT for the timeout parameter waits forever.
            ///
            /// \param timeout The amount of time to wait for the work to finish.
            /// 
            /// \throw Error::OperationTimedout if the work did not finish before the timeout was hit.
            ///
            virtual void wait_current_work(const Timeout &timeout = INFINITE_TIMEOUT) = 0;

            ///
            /// \brief Wait for currently posted work to finish.
            /// 
            /// - The default for the timeout parameter is INFINITE_TIMEOUT.
            ///   + Passing in INFINITE_TIMEOUT for the timeout parameter waits forever.
            ///
            /// \param timeout An absolute time to wait to for the work to finish.
            /// 
            /// \throw Error::OperationTimedout if the work did not finish before the timeout was hit.
            ///
            virtual void wait_current_work(const TimeoutClock::time_point &timeout) = 0;

            ///
            /// \brief Post a work item to the work chain's queue to be executed by
            /// one of the service threads of the work hub associated with the chain.
            /// 
            /// \note Work functions should return quickly; they must not block.
            /// They may post more work, or results.
            /// 
            /// \param work The work item to post.
            /// 
            /// \throw Error::Shutdown if called after IWorkChain::stop() was called.
            /// 
            virtual void post_work(CancelableWork work) = 0;

            ///
            /// \brief Post a work item to the work chain's queue to be executed by
            /// one of the service threads of the work hub associated with the chain.
            /// 
            /// \note Work functions should return quickly; they must not block.
            /// They may post more work, or results.
            /// 
            /// \param work The work item with callback to post.
            /// 
            /// \throw Error::Shutdown if called after IWorkChain::stop() was called.
            /// 
            virtual void post_work(IWorkChainWorkWrapper &work) = 0;

            ///
            /// \brief Post a work item to the work chain's queue to be executed by
            /// one of the service threads of the work hub associated with the chain.
            /// 
            /// \note Work functions should return quickly; they must not block.
            /// They may post more work, or results.
            /// 
            /// \param work The work item with callback to post.
            /// 
            /// \throw Error::Shutdown if called after IWorkChain::stop() was called.
            /// 
            virtual void post_work(IWorkChainWorkWrapper &&work) = 0;

            ///
            /// \brief Get the number of work items currently queued.
            /// 
            /// \note For statistics/debugging.
            /// 
            /// \return The number of work items.
            /// 
            virtual size_t get_work_queued_count() const = 0;

            ///
            /// \brief Get the number of work items which have started (and potentially
            /// finsihed) executing.
            /// 
            /// \note For statistics/debugging.
            /// 
            /// \return The number of work items.
            /// 
            virtual size_t get_work_started_count() const = 0;

            ///
            /// \brief Get the number of work items which have finished being executed.
            /// 
            /// \note For statistics/debugging.
            /// 
            /// \return The number of work items.
            /// 
            virtual size_t get_work_completed_count() const = 0;

            ///
            /// \brief Get the number of work items which are currently queued or being
            /// executed.
            ///
            /// \note For statistics/debugging.
            /// 
            /// inprogress = queued + (started - completed)
            /// 
            /// \return The number of work items.
            /// 
            virtual size_t get_work_queued_or_inprogress_count() const = 0;

            ///
            /// \brief Get the number of work items with callbacks which have been posted to the
            /// work chain.
            /// 
            /// \note For statistics/debugging.
            /// 
            /// \return The number of callbacks.
            /// 
            virtual size_t get_callback_count() const = 0;

            ///
            /// \brief Get the number of work items with callbacks which have been posted to the
            /// work chain and have had the associated callback called.
            /// 
            /// \note For statistics/debugging.
            /// 
            /// \return The number of callbacks.
            /// 
            virtual size_t get_callback_completed_count() const = 0;

            ///
            /// \brief Get a value indicating if the work chain is currently waiting for a work
            /// item callback to be called.
            /// 
            /// \return true if the work chain is waiting for a callback to be called.
            /// 
            virtual bool is_waiting_on_callback() const = 0;

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \copydoc post_work(CancelableWork)
            ///
            /// \param has_callback A value indicating if the work item has a callback associated
            /// with it.
            ///
            /// \see post_work(CancelableWork)
            /// \see post_work(WorkChainWorkWrapper &)
            /// \see post_work(WorkChainWorkWrapper &&)
            ///
            virtual void post_work(CancelableWork work, const bool &has_callback) = 0;

            /// 
            /// \brief Called by WorkChainWorkWrapper before executing its wrapped work.
            ///
            /// \return The id for the callback associated with the work item.
            /// 
            virtual CallbackId pre_execute_work_with_callback() = 0;

            /// 
            /// \brief Called by WorkChainWorkWrapper before executing its wrapped callback.
            ///
            /// \param callback_id The id of the callback that is being executed.
            /// 
            virtual void pre_execute_work_callback(const CallbackId &callback_id) = 0;

            /// 
            /// \brief Called by WorkChainWorkWrapper after executing its wrapped callback.
            ///
            virtual void post_execute_work_callback() = 0;

        private:
            // friend these methods of WorkChainWorkWrapper so that they can call protected
            // methods of IWorkChain
            friend void IWorkChainWorkWrapper::post(IWorkChain &, CancelableWork &);
            friend CallbackId IWorkChainWorkWrapper::pre_execute_work_with_callback(IWorkChain &);
            friend void IWorkChainWorkWrapper::pre_execute_work_callback(IWorkChain &, const CallbackId &);
            friend void IWorkChainWorkWrapper::post_execute_work_callback(IWorkChain &);
        };
    }
}

#endif // NOS_ENGINE_UTILITY_IWORK_CHAIN_HPP