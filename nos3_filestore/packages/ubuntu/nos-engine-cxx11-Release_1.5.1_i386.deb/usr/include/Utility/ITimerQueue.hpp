/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_ITIMER_QUEUE_HPP
#define NOS_ENGINE_UTILITY_ITIMER_QUEUE_HPP

#include <functional>

#include <Utility/Types.hpp>
#include <Utility/Events/IOnError.hpp>
#include <Utility/States/ICancelable.hpp>
#include <Utility/States/IStoppable.hpp>

namespace NosEngine
{
    namespace Utility
    {
        /// 
        /// \brief Represents a queue of events to be executed at given times.
        /// 
        /// There is no guarantee that an event will execute at exactly the time specified.
        /// Events will execute at exactly OR at a short time after the time specified.
        /// 
        class ITimerQueue :
            public virtual IEngineThreadSafeObjectWithCV,
            public virtual Events::IOnError,
            public virtual States::ICancelable,
            public virtual States::IStoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the ITimerQueue class.
            /// 
            virtual ~ITimerQueue() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            using States::ICancelable::cancel;

            /// 
            /// \brief Cancel a single currently queued event.
            /// 
            /// If an event matching the specified id isn't found, then nothing
            /// is canceled and this method simply returns.
            /// 
            /// \param id The id of the timer for the event.
            /// 
            virtual void cancel(const TimerId &id) = 0;

            /// 
            /// \brief Add an event to the timer queue to be executed at or after a relative time delay.
            /// 
            /// \param delay Delay duration in nanoseconds.
            /// \param callback Callback to execute for the event.
            /// 
            /// \return The id of the timer for the event.
            /// 
            virtual TimerId add(const std::chrono::nanoseconds delay, const TimerQueueCallback callback) = 0;

            /// 
            /// \brief Add an event to the timer queue to be executed at or after a relative time delay.
            /// 
            /// \param delay Delay duration in microseconds.
            /// \param callback Callback to execute for the event.
            /// 
            /// \return The id of the timer for the event.
            /// 
            virtual TimerId add(const std::chrono::microseconds delay, const TimerQueueCallback callback) = 0;

            /// 
            /// \brief Add an event to the timer queue to be executed at or after a relative time delay.
            /// 
            /// \param delay Delay duration in milliseconds.
            /// \param callback Callback to execute for the event.
            /// 
            /// \return The id of the timer for the event.
            /// 
            virtual TimerId add(const std::chrono::milliseconds delay, const TimerQueueCallback callback) = 0;

            /// 
            /// \brief Add an event to the timer queue to be executed at or after a relative time delay.
            /// 
            /// \param delay Delay duration in seconds.
            /// \param callback Callback to execute for the event.
            /// 
            /// \return The id of the timer for the event.
            /// 
            virtual TimerId add(const std::chrono::seconds delay, const TimerQueueCallback callback) = 0;

            /// 
            /// \brief Add an event to the timer queue to be executed at or after a relative time delay.
            /// 
            /// \param delay Delay duration in minutes.
            /// \param callback Callback to execute for the event.
            /// 
            /// \return The id of the timer for the event.
            /// 
            virtual TimerId add(const std::chrono::minutes delay, const TimerQueueCallback callback) = 0;

            /// 
            /// \brief Add an event to the timer queue to be executed at or after a relative time delay.
            /// 
            /// \param delay Delay duration in hours.
            /// \param callback Callback to execute for the event.
            /// 
            /// \return The id of the timer for the event.
            /// 
            virtual TimerId add(const std::chrono::hours delay, const TimerQueueCallback callback) = 0;

            /// 
            /// \brief Add an event to the timer queue to be executed at or after an absolute time.
            /// 
            /// \param time An absolute time.
            /// \param callback Callback to execute for the event.
            /// 
            /// \return The id of the timer for the event.
            /// 
            virtual TimerId add(const TimerQueueTimepoint time, const TimerQueueCallback callback) = 0;
        };
    }
}

#endif // NOS_ENGINE_UTILITY_ITIMER_QUEUE_HPP