/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_SERVER_HPP
#define NOS_ENGINE_SERVER_SERVER_HPP

#include <string>
#include <map>
#include <vector>
#include <memory>
#include <mutex>

#include <Utility/Queue.hpp>
#include <Utility/States/Stoppable.hpp>

#include <Transport/TransportHub.hpp>

#include <Common/TransactionManager.hpp>
#include <Common/IMessageConnection.hpp>

#include <Server/Types.hpp>
#include <Server/IServer.hpp>
#include <Server/DataLogger.hpp>
#include <Server/PluginTypes.hpp>

namespace ItcLoader
{
    class Loader;
}

namespace NosEngine
{
    namespace Server
    {
        ///
        /// \copydoc IServer
        ///
        class NOS_ENGINE_SERVER_API_PUBLIC Server :
            public IServer,
            public Utility::States::Stoppable
        {
        private:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            struct ListenOperation;

            // FIXME: Do these need to be shared pointers?
            // ---- pair types ----
            typedef std::pair<std::shared_ptr<Common::ISendOperator>, std::shared_ptr<Common::ReceiveOperator>> OperatorPair;

            // ---- map types ----
            typedef std::map<std::string, BusCreationFunction> BusCreationFunctionMap;
            typedef std::map<std::string, std::unique_ptr<ItcLoader::Loader>> PluginLoaderMap;
            typedef std::map<std::string, Transport::ListenCallback> ListenCallbackMap;
            typedef std::map<Common::IMessageConnection *, std::shared_ptr<Common::IMessageConnection>> MessageConnectionMap;
            typedef std::map<Common::IMessageConnection *, OperatorPair> OperatorMap;

        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Construct and instance of the Server class.
            ///
            /// \param num_service_threads  The number of service threads that should be created
            ///
            Server(const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);
            
            ///
            /// \brief Construct and instance of the Server class.
            /// 
            /// \param transport_hub    Existing transport hub to use
            ///
            Server(Transport::TransportHub &transport_hub);

        private:
            Server(const Server&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the Server class.
            /// 
            virtual ~Server();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            Server& operator=(const Server&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IServer implementation
            // ------------------------------------------------------------------------------------

            virtual Transport::TransportHub &get_transport_hub() const;

            virtual void enable_logger();

            virtual void add_transport(std::string local_uri, ClientConnectedCallback connected_callback = nullptr, ClientDisconnectedCallback disconnected_callback = nullptr);

            virtual void remove_transport(Common::IMessageConnection *message_connection);

            virtual void add_bus(Bus* bus_to_add);

            virtual Bus* get_bus(const std::string& name) const;

            virtual Bus* get_or_create_bus(std::string name, std::string protocol = Common::DEFAULT_PROTOCOL_NAME);

            virtual void for_each_bus(BusActionCallback callback);

            virtual void register_protocol_bus(const std::string& protocol, BusCreationFunction creator);

            virtual void load_plugin(const std::string& plugin);

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Called by constructors to perform common initialization.
            ///
            void init();

            ///
            /// \brief Called when a listen operation completes.
            ///
            /// \see add_transport()
            ///
            /// \param listen_op    Internal listen operation data.
            /// \param connection   The connection for the completed listen operation.
            /// \param error        Any error that occurred during listen (or success error).
            ///
            void listen_completed(ListenOperation &listen_op,
                                  Transport::Connection *connection,
                                  const Utility::Error::Error &error);

            ///
            /// \brief Called handshakes for a connection created for a listen are completed.
            ///
            /// \param listen_op            Internal listen operation data.
            /// \param message_connection   The connection for the completed handshakes.
            /// \param transport_id         The ID of the transport.
            /// \param error                Any error that occurred during listen (or success error).
            ///
            void listen_handshake_completed(ListenOperation &listen_op,
                                            Common::IMessageConnection &message_connection,
                                            Common::TransportID transport_id,
                                            const Utility::Error::Error &error);

            ///
            /// \brief Called when a connection created for a listen is disconnected.
            ///
            /// \param listen_op    Internal listen operation data.
            /// \param connection   The connection which has been disconnected.
            /// \param transport_id The ID of the transport.
            ///
            void listen_connection_disconnected(ListenOperation &listen_op,
                                                Common::IMessageConnection *connection,
                                                Common::TransportID id);

            ///
            /// \brief Post a work item to execute the user client connected callback with an
            /// error message due to failure.
            ///
            /// \param error    The error that occured.
            /// \param callback The user callback to execute.
            ///
            void post_failure(const Utility::Error::Error &error, const ClientConnectedCallback &callback);

            ///
            /// \brief Post a work item to execute the user client connected callback.
            ///
            /// \param transport_id The id of the transport for the connection to the client.
            /// \param error        The error that occured (or success error).
            /// \param callback     The user callback to execute.
            ///
            void post_client_connect(const Common::TransportID &transport_id, const Utility::Error::Error &error, const ClientConnectedCallback &callback);

            ///
            /// \brief Post a work item to execute the user client disconnected callback.
            ///
            /// \param transport_id The id of the transport for the connection that was disconnected.
            /// \param callback     The user callback to execute.
            ///
            void post_client_disconnect(const Common::TransportID &transport_id, const ClientDisconnectedCallback &callback);

            ///
            /// \brief Called by get_or_create_bus to create a Bus that uses the default protocol.
            ///
            /// \param name The name of the Bus to create.
            ///
            /// \return The new default Bus.
            ///
            Bus* create_default_bus(const std::string& name) const;

            ///
            /// \brief Add the Bus to the Server's collection of buses.
            ///
            /// \param bus_to_add The bus to add to the collection.
            ///
            void add_bus_internal(Bus* bus_to_add);

            ///
            /// \brief Find a Bus with the specified name in the bus collection.
            ///
            /// \param name The bus name to search for.
            ///
            /// \return The Bus found (or nullptr).
            ///
            Bus* find_bus(const std::string& name) const;

            ///
            /// \brief Setup the DataLogger for this server.
            ///
            void setup_logger() NOS_NOEXCEPT;

        protected:
            // ------------------------------------------------------------------------------------
            // IServer implementation
            // ------------------------------------------------------------------------------------

            virtual Common::IMessageRouter &get_server_router() const;

            // ------------------------------------------------------------------------------------
            // IServer (IEngineThreadSafeObjectWithCV) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

            virtual std::condition_variable &get_cv() const;

            // ------------------------------------------------------------------------------------
            // Stoppable implementation
            // ------------------------------------------------------------------------------------

            virtual bool is_stopping_no_lock() const;

            virtual void set_stopping_no_lock(const bool &stopping);

            virtual bool is_stopped_no_lock() const;

            virtual void set_stopped_no_lock(const bool &stopped);

            virtual void process_stop(std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- thread syncronization ----
            mutable std::mutex mutex;
            mutable std::condition_variable cond;
            std::condition_variable for_each_bus_done_cond;

            // ---- configuration ----
            Transport::TransportHub *transport_hub;
            bool owns_transport_hub;

            // ---- logging ----
            DataLogger data_logger;
            std::unique_ptr<IDataLoggerTarget> data_logger_file_target;

            // ---- transactions ----
            Common::TransactionManager manager;

            // ---- message routing ----
            Common::IMessageRouter* const router;

            // ---- protocol registration ----
            BusCreationFunctionMap protocol_bus_creation_function_map;
            PluginLoaderMap protocol_plugin_loader_map;

            // ---- buses ----
            std::vector<Bus*> bus_vec;
            NosEngine::Utility::Queue<Bus *> deletion_queue;    //!< queue of buses whose deletion were delayed
            bool delay_bus_deletion;                            //!< delay bus deletion during for_each_bus

            // ---- transport ----
            Common::TransportID transport_id;
            ListenCallbackMap listen_callback_map;
            MessageConnectionMap message_connection_map;
            OperatorMap operator_map;

            // ---- counters ----
            size_t for_each_bus_count;
            size_t transport_operations_started;
            size_t transport_operations_finished;

            // --- status ----
            bool stopping;
            bool stopped;
        };
    }
}

#endif

