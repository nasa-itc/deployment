/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_IDATA_LOGGER_HPP
#define NOS_ENGINE_SERVER_IDATA_LOGGER_HPP

#include <Server/Types.hpp>
#include <Server/PluginTypes.hpp>

namespace NosEngine
{
    namespace Server
    {
        ///
        /// \brief The data logger is used to capture all traffic that moves in and out of the
        /// server.
        ///
        /// The data logger can have multiple targets.
        ///
        /// Currently, all messages are sent to all targets; in the future, filtering on a
        /// per-target basis will be added.
        ///
        class IDataLogger :
            public virtual Utility::IEngineThreadSafeObjectWithCV
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IDataLogger class.
            /// 
            virtual ~IDataLogger() {}

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Add a new target to the logger
            ///
            /// The logger does not take over the lifetime of the target.
            /// Lifetime of the target should be guaranteed while it is added to the logger.
            ///
            /// \param to_add  new log target to add
            ///
            virtual void add_target(IDataLoggerTarget* to_add) = 0;

            ///
            /// \brief Removes a target from the logger.
            ///
            /// Once removed, no more messages will be sent to the target.
            ///
            /// \param to_remove  log target to remove
            ///
            virtual void remove_target(const IDataLoggerTarget* to_remove) = 0;

            ///
            /// \brief Removes all targets from the logger.
            ///
            virtual void remove_all_targets() = 0;
                
            ///
            /// \brief Get a value indicating if the logger has one or more targets.
            ///
            /// \return Value indicating if the logger has targets.
            ///
            virtual bool has_targets() = 0;

            ///
            /// \brief Logs a Message to all of the targets.
            ///
            /// \param message  message to log
            ///
            virtual void log_message(Common::Message &message) = 0;
                
            ///
            /// \brief Logs a Message to all of the targets.
            ///
            /// \param message  message to log
            ///
            virtual void log_message(Common::Message &&message) = 0;

            ///
            /// \brief Registers a protocol interpreter with the data logger
            ///
            /// \param protocol Name of the protocol
            /// \param interpreter The message interpreter
            ///
            virtual void register_protocol_interpreter(const std::string& protocol, MessageInterpreterFunction interpreter) = 0;
        };
    }
}

#endif