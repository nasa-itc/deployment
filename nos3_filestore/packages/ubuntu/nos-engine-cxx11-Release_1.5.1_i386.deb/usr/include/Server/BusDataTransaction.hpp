/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_BUS_DATA_TRANSACTION_HPP
#define NOS_ENGINE_SERVER_BUS_DATA_TRANSACTION_HPP

#include <list>

#include <Common/Transaction.hpp>
#include <Common/ITransactionManager.hpp>
#include <Common/Message.hpp>
#include <Common/Protocol.hpp>

#include <Server/visibility.hpp>
#include <Server/Types.hpp>

namespace NosEngine
{
	namespace Server
	{
        // TODO: Split these classes up into seperate files

		typedef std::function<void(Common::Message)> TransactionResultFunction;
        
        /// 
        /// \brief Represents a chain of transactions for sending a message to a data node.
        /// 
        /// The chain is initiated by a BusDataTransaction for a data message being sent from a source
        /// to a destination data node.
        /// 
        /// This class is non-copyable but movable (ie move only).
        /// 
        class BusDataTransactionChain
        {
        private:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            typedef std::list<Node*> NodeChain;

        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the BusDataTransactionChain class.
            /// 
            /// \param source The name of the source data node.
            /// \param destination The name of the destination data node.
            /// \param bus The bus which the source/destination nodes are attached to.
            /// \param confirm A value indicating if the chain is for a confirmed message.
            /// \param duplex A value indicating if the chain is for a duplex message.
            /// \param original_transaction The BusDataTransaction which initiated this chain.
            /// \param manager The transaction manager for the original transaction.
            /// 
            BusDataTransactionChain(const Common::Message &message,
                                    Bus* bus,
                                    BusDataTransaction *original_transaction,
                                    Common::ITransactionManager& manager);
            
            /// 
            /// \brief Construct an instance of the BusDataTransactionChain class.
            /// 
            /// \param source The source data node.
            /// \param destination The destination data node.
            /// \param confirm A value indicating if the chain is for a confirmed message.
            /// \param duplex A value indicating if the chain is for a duplex message.
            /// \param original_transaction The BusDataTransaction which initiated this chain.
            /// \param manager The transaction manager for the original transaction.
            /// \param finalizer A function to call when the chain is finished.
            /// 
            BusDataTransactionChain(const Common::Message &message, 
                                    DataNode* source,
                                    DataNode* destination,
                                    BusDataTransaction *original_transaction,
                                    Common::ITransactionManager& manager,
                                    TransactionResultFunction finalizer);

        private:
            BusDataTransactionChain(const BusDataTransactionChain&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Move constructor.
            /// 
            BusDataTransactionChain(BusDataTransactionChain &&other);

            /// 
            /// \brief Destructor for an instance of the BusDataTransactionChain class.
            /// 
            ~BusDataTransactionChain();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            BusDataTransactionChain& operator=(const BusDataTransactionChain&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get a value indicating if the node is in the chain.
            ///
            /// \param node The node to search for.
            ///
            /// \return true if the node is in the chain.
            ///
            bool contains(Common::INode* node);

            /// 
            /// \brief Remove the node from this chain (if found).
            /// 
            /// \param to_remove The node to remove from this chain.
            /// 
            void remove(Common::INode* to_remove);
            
            /// 
            /// \brief Get the total number of nodes currently in the chain.
            /// 
            /// \return The number of nodes.
            /// 
            size_t size() const;
            
            /// 
            /// \brief Get the number of nodes currently in the send chain.
            /// 
            /// \return The number of nodes.
            /// 
            size_t send_size() const;
            
            /// 
            /// \brief Get the number of nodes currently in the response chain.
            /// 
            /// \return The number of nodes.
            /// 
            size_t response_size() const;
            
            /// 
            /// \brief Get the source data node (ie node that sent the orginal message).
            /// 
            /// \return The source node.
            /// 
            DataNode* get_source() const;
            
            /// 
            /// \brief Get the destination data node.
            /// 
            /// \return The destination node.
            /// 
            DataNode* get_destination() const;
            
            /// 
            /// \brief Get the transaction id of the transaction which initiated this chain.
            /// 
            /// \return The original transaction id.
            /// 
            Common::TransactionID get_original_id() const;

            /// 
            /// \brief Set the transaction id of the transaction which initiated this chain.
            /// 
            /// \param id The original transaction id.
            /// 
            void set_original_id(const Common::TransactionID &id);
            
            /// 
            /// \brief Get the transaction manager of the transaction which initiated this chain.
            /// 
            /// \return The transaction manager.
            /// 
            Common::ITransactionManager& get_transaction_manager() const;
            
            /// 
            /// \brief Send a message to a data node which is the target of a BusDataTransaction.
            /// 
            /// The result returned by this method is what should be returned by the transaction work
            /// method which called send_message.
            /// 
            /// \param message The message to send.
            /// \param target The target data node to send the message to.
            /// \param current_transaction The transaction which is calling this method.
            /// 
            /// \return A transaction work result.
            /// 
            Common::TransactionWorkResult send_message(Common::Message &message,
                                                       DataNode* target,
                                                       Common::ITransaction* current_transaction,
                                                       std::unique_lock<std::mutex> &lock);
            
            /// 
            /// \brief Send a message to an interceptor node which is the target of a BusDataInterceptorTransaction.
            /// 
            /// The result returned by this method is what should be returned by the transaction work
            /// method which called send_message.
            /// 
            /// \param message The message to send.
            /// \param target The target interceptor node to send the message to.
            /// \param current_transaction The transaction which is calling this method.
            /// 
            /// \return A transaction work result.
            /// 
            Common::TransactionWorkResult send_message(Common::Message &message,
                                                       InterceptorNode* target,
                                                       Common::ITransaction* current_transaction,
                                                       std::unique_lock<std::mutex> &lock);
            
            /// 
            /// \brief Creates the new transaction for the next node in this chain.
            /// 
            /// This method may modify the message pass in. For example, if the next transaction
            /// is an interceptor transaction but the message is a data message then the
            /// message will be converted to an interceptor message.
            /// 
            /// \param message The message the new transaction will process.
            /// 
            void process_next(Common::Message &message, std::unique_lock<std::mutex> &lock);
            
            /// 
            /// \brief Perform the action requested by a target interceptor node of a BusDataInterceptorTransaction.
            /// 
            /// Actions include: pass, modify, block, and mimic.
            /// When the actio nis block or mimic the chain will be terminated a confirmation/reply
            /// message will be sent to the source node as the next step.
            /// 
            /// \param message The message that contains the response for the target.
            /// 
            void perform_interceptor_action(Common::Message& message, std::unique_lock<std::mutex> &lock);

            /// 
            /// \brief Terminate the chain with the provided message.
            /// 
            /// When the chain is terminated all reamining nodes in the chain are
            /// skipped. Except for the source node if the chain is for a
            /// confirmed/request message.
            /// 
            /// \param message The message to use when finalizing the chain.
            /// 
            void terminate(Common::Message& message, std::unique_lock<std::mutex> &lock);

            /// 
            /// \brief Convert message type to/from interceptor/data.
            /// 
            /// The desired type must be Interceptor or Data.
            /// If the message is already the desired type, then the message is not modified.
            /// 
            /// \param to_convert The message to convert.
            /// \param desired_type The desired type that message will be converted to.
            /// 
            static void convert_message(Common::Message& to_convert, const Common::MessageType& desired_type);
            
            /// 
            /// \brief Convert the message to a Data Message flagged as rejected.
            /// 
            /// \param to_reject The message to reject.
            /// \param code The response code to store in the message (ie reason for being rejected).
            /// 
            static void convert_to_rejection(Common::Message& to_reject, const Common::Protocol::ResponseCode &code);

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Called by constructors to perform common initialization.
            ///
            void init(const Common::Message &);

            ///
            /// \brief Pop a node from the front send/response chain.
            ///
            /// If the send chain IS NOT empty a node is popped from the send chain and returned.
            /// If the send chain IS empty and the response chain IS NOT empty a node is popped
            /// from the response chain and returned.
            ///
            /// \return The node.
            ///
            /// \throw Utility::Error::NotFound if both chains are empty.
            ///
            Node* pop();

            ///
            /// \brief Find and remove the specified DataNode from the specified NodeChain.
            ///
            /// \param to_remove    The DataNode to remove.
            /// \param chain        The NodeChain which contains the DataNode to be removed.
            ///
            /// \return true if the node was found and removed.
            ///
            bool remove_data_node(DataNode *to_remove, NodeChain &chain);

            ///
            /// \brief Find and remove the specified InterceptorNode from the specified
            /// NodeChain.
            ///
            /// \param to_remove    The InterceptorNode to remove.
            /// \param chain        The NodeChain which contains the InterceptorNode to be removed.
            ///
            /// \return true if the node was found and removed.
            ///
            bool remove_interceptor_node(InterceptorNode *to_remove, NodeChain &chain);

            ///
            /// \brief Queue the transaction, for the target node, up for processing.
            ///
            /// \param target       The target use to for queueing the transaction.
            /// \param message      The message for the transaction.
            /// \param transaction  The transaction to queue for processing.
            ///
            void process_transaction(Node *target,
                                     Common::Message &message,
                                     Common::ITransaction *transaction,
                                     std::unique_lock<std::mutex> &lock);

            ///
            /// \brief Send the message to the target node.
            ///
            /// \param message              The message to send.
            /// \param target               The server side Node to use to send to the client node.
            /// \param is_interceptor       Value indicating if the target node is an interceptor.
            /// \param current_transaction  The transaction to use when sending the message.
            ///
            Common::TransactionWorkResult send_message(Common::Message &message,
                                                       Node *target,
                                                       const bool &is_interceptor,
                                                       Common::ITransaction *current_transaction,
                                                       std::unique_lock<std::mutex> &lock);

            ///
            /// \brief Finalize the chain.
            ///
            /// \param message The message to send as the final message.
            ///
            void finalize(Common::Message &message, std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            DataNode* source;
            DataNode* destination;
            BusDataTransaction *original_transaction;
            Common::TransactionID original_id;
            Common::ITransactionManager& manager;
            TransactionResultFunction finalizer;
            NodeChain send_chain;
            NodeChain response_chain;
        };
        
        /// 
        /// \brief Represents a transaction for sending a message to a destination data node.
        /// 
        /// When the BusDataTransaction is for the source data node the transaction
        /// does not send anything to a target node, it simply generates a new transaction
        /// for the next node in the transaction chain.
        /// 
        /// When the BusDataTransaction is for the destination data node the transaction
        /// has two work passes:
        /// 1) Send a message to the target destination data node.
        /// 2) Generate a new transaction for the next node in the transaction chain
        ///    (only for confirmed/request messages)
        /// 
		class BusDataTransaction :
            public Common::Transaction 
		{
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the BusDataTransaction class.
            /// 
            /// \param source The source data node.
            /// \param destination The destination data node.
            /// \param message The message which the transaction will be processing.
            /// \param manager The transaction manager for this transaction.
            /// \param finalizer A function to call when the transaction chain is finished.
            /// 
			BusDataTransaction(DataNode* source,
                               DataNode* destination,
                               const Common::Message& message, 
                               Common::ITransactionManager& manager,
                               TransactionResultFunction finalizer);
            
            /// 
            /// \brief Construct an instance of the BusDataTransaction class.
            /// 
            /// \param bus The bus which the source/destination nodes are attached to.
            /// \param message The message which the transaction will be processing.
            /// \param manager The transaction manager for this transaction.
            /// 
            BusDataTransaction(Bus* bus,
                               const Common::Message& message,
                               Common::ITransactionManager& manager);
            
            /// 
            /// \brief Construct an instance of the BusDataTransaction class.
            /// 
            /// This constructor is used for creating a transaction which handles
            /// sending a message to the destination data node of a transaction chain.
            /// 
            /// \param target The data node that is the target of the message.
            /// \param chain The transaction chain which this transaction is part of.
            /// 
            BusDataTransaction(DataNode* target,
                               BusDataTransactionChain &chain);

        private:
            BusDataTransaction(const BusDataTransaction&); //!< Disable the copy constructor.
            
        public:
            /// 
            /// \brief Destructor for an instance of the BusDataTransaction class.
            /// 
            virtual ~BusDataTransaction();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            BusDataTransaction& operator=(const BusDataTransaction&); //!< Disable the copy assignment operator.
            
        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // Transaction implementation
            // ------------------------------------------------------------------------------------

            virtual void node_removed(NosEngine::Common::INode *removed);

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // Transaction implementation
            // ------------------------------------------------------------------------------------

            virtual Common::TransactionWorkResult work(std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            DataNode* target;
            BusDataTransactionChain chain;
            Common::ITransactionManager& manager;
            uint8_t work_pass;
            bool is_source_transaction;
		};
	}
}

#endif