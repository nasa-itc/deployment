/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_DATA_LOGGER_FILE_TARGET_HPP
#define NOS_ENGINE_SERVER_DATA_LOGGER_FILE_TARGET_HPP

#include <Server/IDataLoggerTarget.hpp>
#include <fstream>

namespace NosEngine
{
    namespace Server
    {
        ///
        /// \brief This log target provides basic file output for logging.
        ///
        class NOS_ENGINE_SERVER_API_PUBLIC DataLoggerFileTarget :
            public IDataLoggerTarget
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Instantiate a log target that writes to file.
            ///
            /// \param file_path  path to log file
            ///
            DataLoggerFileTarget(const char *file_path);

        private:
            DataLoggerFileTarget(const DataLoggerFileTarget&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the DataLoggerFileTarget class.
            /// 
            virtual ~DataLoggerFileTarget();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            DataLoggerFileTarget& operator=(const DataLoggerFileTarget&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            virtual void log(const char * message);

            virtual void log(const char * message, int len);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            std::ofstream file_out;
        };
    }
}

#endif /* NOS_ENGINE_SERVER_DATA_LOGGER_FILE_TARGET_HPP */
