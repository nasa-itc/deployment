/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/
#ifndef NOS_ENGINE_MS1553_SERVER_BUS_CONTROL_TRANSACTION_HPP
#define NOS_ENGINE_MS1553_SERVER_BUS_CONTROL_TRANSACTION_HPP

#include <MS1553/visibility.hpp>
#include <Common/Transaction.hpp>
#include <Common/ISendOperator.hpp>
#include <Common/Message.hpp>

#include <Server/BusControlTransaction.hpp>

namespace NosEngine
{
	namespace MS1553
	{
		class MS1553Bus;

        /*
         * \brief Control Transaction to Control messages on the 1553 Bus
         * \note Most messages will be processed by the base BusControlTransaction class
         */
		class BusControlTransaction : public Server::BusControlTransaction
		{
		public:
            
            /*
             * \brief Creates a transaction for Control operations on the 1553 bus
             *
             * \param bus The associated bus
             * \param send_interface Send interface associated with the transaction
             */
			BusControlTransaction(MS1553Bus* bus, Common::WeakSendOperator send_interface);
			
            /*
             * \brief Class destructor
             */
            virtual ~BusControlTransaction();
			
            /*
             * \brief Completion method for the control transaction
             *
             * \param result If the transaction was successful or not
             * \param original The orginal message passed to the transaction
             * \param response Response message to be sent 
             *
             * \return if the transaction is finished
             */
            virtual bool work_complete(bool result, const Common::Message& original, Common::Message response);
		private:
			MS1553Bus* const bus;
			Common::WeakSendOperator sender;
		};
	}
}

#endif 
