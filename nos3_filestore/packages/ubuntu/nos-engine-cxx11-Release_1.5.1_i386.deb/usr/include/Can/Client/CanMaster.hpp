/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CAN_MASTER_HPP
#define NOS_ENGINE_CAN_MASTER_HPP

#include <Can/visibility.hpp>
#include <Can/Client/CanDevice.hpp>
#include <Can/Types.hpp>
#include <cstdint>
#include <string>

namespace NosEngine
{
    namespace Can
    {
        /*
         * \brief Client side CAN master device
         *
         */
        class NOS_ENGINE_CAN_API_PUBLIC CanMaster : public CanDevice
        {
        public:
            /*
             * \brief Create CAN master device on the named bus
             *
             * \param identifier CAN master device base identifier
             * \param connection NOS connection string
             * \param bus CAN bus name
             * \param num_service_threads The number of service threads that should be created
             */
            CanMaster(
                CanIdentifier identifier,
                const std::string& connection,
                const std::string& bus = "can",
                const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);

            /*
             * \brief Create CAN master device on the named bus
             *
             * \param transport_hub Existing transport hub to use
             * \param identifier CAN master device base identifier
             * \param connection NOS connection string
             * \param bus CAN bus name
             */
            CanMaster(
                Transport::TransportHub &transport_hub,
                CanIdentifier identifier,
                const std::string& connection,
                const std::string& bus = "can");

            /*
             * \brief Destructor
             */
            virtual ~CanMaster();

            /*
             * \brief CAN master read
             *
             * \param identifier Slave device base identifier
             * \param rbuf Read data buffer
             * \param rlen Read data buffer length
             *
             * \return Transaction result
             */
            Result can_read(CanIdentifier identifier, uint8_t* rbuf, size_t rlen) const;

            /*
             * \brief CAN master write
             *
             * \param identifier Slave device base identifier
             * \param wbuf Write data buffer
             * \param wlen Write data buffer length
             *
             * \return Transaction result
             */
            Result can_write(CanIdentifier identifier, const uint8_t *wbuf, size_t wlen) const;

            /*
             * \brief CAN master transaction (write/read operation)
             *
             * \param identifier Slave device base identifier
             * \param wbuf Write data buffer
             * \param wlen Write data buffer length
             * \param rbuf Read data buffer
             * \param rlen Read data buffer length
             *
             * \return Transaction result
             */
            Result can_transaction(CanIdentifier identifier, const uint8_t *wbuf, size_t wlen,
                                   uint8_t* rbuf, size_t rlen) const;
        };
    }
}

#endif

