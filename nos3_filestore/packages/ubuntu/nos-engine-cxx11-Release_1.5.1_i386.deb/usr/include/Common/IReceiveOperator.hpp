/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_IRECEIVER_OPERATOR_HPP
#define NOS_ENGINE_COMMON_IRECEIVER_OPERATOR_HPP

#include <Utility/States/IStoppable.hpp>

#include <Common/types.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \brief Continuously pulls messages from a message connection and executes message routing.
        ///
        /// This class is the engine for incoming messages. A background thread will continually
        /// pull messages from the message connection and hand them off the message router.
        ///
        /// Currently the operation is single-threaded; i.e., a second message will not be 
        /// routed until the first message's routing has been completed.
        ///
        class IReceiveOperator :
            public virtual Utility::IEngineThreadSafeObjectWithCV,
            public virtual Utility::States::IStoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IReceiveOperator class.
            /// 
            ~IReceiveOperator() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the ID of the transport which this receive operator is using.
            ///
            /// \return The ID.
            ///
            virtual TransportID get_transport_id() const = 0;

            ///
            /// \brief Get the total number of receive operations which have been initiated.
            ///
            /// \return The number of receives.
            ///
            virtual size_t get_receive_count() const = 0;

            ///
            /// \brief Get the total number of receive operations which have been completed.
            ///
            /// \return The number of receives completed.
            ///
            virtual size_t get_receive_completed_count() const = 0;
        };
    }
}

#endif