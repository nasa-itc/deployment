/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/
#ifndef NOS_ENGINE_COMMON_TYPES_HPP
#define NOS_ENGINE_COMMON_TYPES_HPP

#include <functional>
#include <memory>

#include <Transport/Types.hpp>
#include <Common/visibility.hpp>
#include <Common/Fwd.hpp>

#ifndef _MSC_VER
#define NOS_NOEXCEPT noexcept
#define NOS_SNPRINTF snprintf

#define NOS_CONSTEXPR constexpr
#else
#define NOS_NOEXCEPT _NOEXCEPT
#define NOS_SNPRINTF _snprintf  //snprintf is part of C99 which windows does not support
#define NOS_CONSTEXPR
#endif

#ifdef __GNUC__
typedef long CHRONO_CLOCK_COUNT;
#else

#ifdef _WIN64
typedef long long CHRONO_CLOCK_COUNT;
#else
#ifdef WIN32
typedef long long CHRONO_CLOCK_COUNT;
#endif
#endif
#endif

#define LOGGER_CONFIG_FILENAME "nos_engine_log_config.xml"

namespace NosEngine
{
    namespace Common
    {
        // Enumerations
        enum class ErrorCode
        {
            MessageError,
            MessageOK,
            ErrorInvalid
        };

        enum class MessageType
        {
            Control,
            Query,
            Time,
            Data,
			Interceptor,
            Invalid
        };

		//TODO: Consider moving this maybe?
        //TODO: Make this an extern const std::string
        #define BROADCAST_NAME "*"

        const std::string DEFAULT_PROTOCOL_NAME = "base";

        // Typedefs
        //typedef void (*UnknownMessageFunc)(Message*);
        typedef std::shared_ptr<ISendOperator> SharedSendOperator;
        typedef std::weak_ptr<ISendOperator> WeakSendOperator;
        typedef std::function<void(Message*, WeakSendOperator)> UnknownMessageFunc;
        typedef int32_t TransportID;
        typedef int32_t BusID;
        typedef int32_t NodeID;
        typedef int32_t TransactionCount;
        typedef int64_t TransactionID;
        typedef int64_t BusRegistrationFlags;
        typedef int64_t SimTime;

        typedef std::function<void(IMessageConnection &message_connection, TransportID transport_id, const Utility::Error::Error &error)> MessageConnectionHandshakeCompleteCallback;
        typedef std::function<void(IMessageConnection &message_connection, TransportID transport_id)> MessageConnectionDisconnectedCallback;
        typedef std::function<void(Common::Message, const Utility::Error::Error &error)> ReceiveMessageCallback;
	}
}

#endif

