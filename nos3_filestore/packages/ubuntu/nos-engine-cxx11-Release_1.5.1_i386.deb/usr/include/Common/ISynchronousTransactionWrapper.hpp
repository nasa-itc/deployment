/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_ISYNCHRONOUS_TRANSACTION_WRAPPER_HPP
#define NOS_ENGINE_COMMON_ISYNCHRONOUS_TRANSACTION_WRAPPER_HPP

#include <Common/types.hpp>
#include <Common/Globals.hpp>
#include <Common/Message.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \brief A helper class to allow a thread to wait for a transaction to complete.
        ///
        /// This class creates a wrapper around a transaction to monitor the it for completion.
        /// When the transaction is complete, the response message will be available to the wait() caller.
        ///
        class ISynchronousTransactionWrapper :
            public virtual Utility::IEngineThreadSafeObject
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Destructor for an instance of the ISynchronousTransactionWrapper class.
            ///
            virtual ~ISynchronousTransactionWrapper() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Wait for the response message from the transaction.
            ///
            /// This call blocks until the transaction has finished and returns the 
            /// response message.
            ///
            /// This method can't be called twice. The second call will cause an exception
            /// to be thrown.
            ///
            /// \param timeout timeout in milliseconds (SYNC_WAIT_INFINITE_TIMEOUT = no timeout)
            ///
            /// \return the response message
            ///
            virtual Message wait(size_t timeout = SYNC_WAIT_INFINITE_TIMEOUT) = 0;

            ///
            /// \brief Get the internal transaction.
            ///
            /// NOTE: User should not delete the transaction using the returned pointer.
            /// The pointer should be passed to a transaction manager.
            /// The transaction manager or this wrapper will handling deleting
            /// the internal transaction.
            ///
            /// \return The internal transaction (null if called after a call to wait)
            ///
            virtual ITransaction* get_transaction() const = 0;
		};
	}
}

#endif
