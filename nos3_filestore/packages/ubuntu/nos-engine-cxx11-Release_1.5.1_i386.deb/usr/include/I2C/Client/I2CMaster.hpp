/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_I2C_MASTER_HPP
#define NOS_ENGINE_I2C_MASTER_HPP

#include <I2C/visibility.hpp>
#include <I2C/Client/I2CDevice.hpp>
#include <I2C/Types.hpp>
#include <cstdint>
#include <string>

namespace NosEngine
{
    namespace I2C
    {
        /*
         * \brief Client side I2C master device
         *
         * The NOS I2C implementation provides a familiar I2C API but differs at the hardware protocol
         * level for performance. Rather than sending and requiring slave devices to ACK/NACK individual
         * bytes, the entire transaction is handled in a single transport round trip. The slave device
         * returns the actual number of bytes read/written, providing a mechanism to model transaction
         * errors, such as a busy condition or a pre-mature NACK.
         *
         * These implementation details should be transparent to the end user.
         */
        class NOS_ENGINE_I2C_API_PUBLIC I2CMaster : public I2CDevice
        {
        public:
            /*
             * \brief Create I2C master device on the named bus
             *
             * \param address I2C master device base address
             * \param connection NOS connection string
             * \param bus I2C bus name
             * \param num_service_threads The number of service threads that should be created
             */
            I2CMaster(
                I2CAddress address,
                const std::string& connection,
                const std::string& bus = "i2c",
                const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);

            /*
             * \brief Create I2C master device on the named bus
             *
             * \param transport_hub Existing transport hub to use
             * \param address I2C master device base address
             * \param connection NOS connection string
             * \param bus I2C bus name
             */
            I2CMaster(
                Transport::TransportHub &transport_hub,
                I2CAddress address,
                const std::string& connection,
                const std::string& bus = "i2c");

            /*
             * \brief Destructor
             */
            virtual ~I2CMaster();

            /*
             * \brief I2C master read
             *
             * \param address Slave device base address
             * \param rbuf Read data buffer
             * \param rlen Read data buffer length
             *
             * \return Transaction result
             */
            Result i2c_read(I2CAddress address, uint8_t* rbuf, size_t rlen) const;

            /*
             * \brief I2C master write
             *
             * \param address Slave device base address
             * \param wbuf Write data buffer
             * \param wlen Write data buffer length
             *
             * \return Transaction result
             */
            Result i2c_write(I2CAddress address, const uint8_t *wbuf, size_t wlen) const;

            /*
             * \brief I2C master transaction (write/read operation)
             *
             * \param address Slave device base address
             * \param wbuf Write data buffer
             * \param wlen Write data buffer length
             * \param rbuf Read data buffer
             * \param rlen Read data buffer length
             *
             * \return Transaction result
             */
            Result i2c_transaction(I2CAddress address, const uint8_t *wbuf, size_t wlen,
                                   uint8_t* rbuf, size_t rlen) const;
        };
    }
}

#endif

