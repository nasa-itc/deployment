/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation. Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITCPROTOCOL_BCPROTOCOLHANDLER_HPP
#define ITCPROTOCOL_BCPROTOCOLHANDLER_HPP

#include <stdexcept>
#include <vector>
#include <queue>
#include <itc_visibility.hpp>

#include <ItcProtocol/BCProtocolMessage.hpp>

namespace ItcProtocol
{
    /**
        \brief ProtocolHandler utility class
        \note BC Protocol Utilizes Big Endian Notation
    */
    class DLL_PUBLIC BCProtocolHandler
    {

    public:

        /**
            \brief Provides the user the size of a frame buffer given a vector of messages
        */
        unsigned int static determine_frame_size(const std::vector<BCProtocolMessage> &MessageVector);

        /**
            \brief Provides the user the size of a frame buffer given the number of messages
        */
        unsigned int static determine_frame_size(const unsigned int NumberOfMessages);

        /**
            \brief build an ack ok message and inserts into the AckMessageBuffer
        */
        void static build_ack_ok_message(unsigned char *AckMessageBuffer);

        /**
            \brief build an ack schedule overrun error message and inserts into the AckMessageBuffer
        */
        void static build_ack_overrun_error_message(unsigned char *AckMessageBuffer);

        /**
            \brief retrieves the ack code from an AckMessage buffer
        */
        AckCode static get_ack_code(const unsigned char *const AckMessageBuffer);

        /**
            \brief Builds a complete frame packet which consists of N messages, which are provided in a vector

            \note It is the user's responsibility to allocate the FrameBuffer to the appropriate size. This method will check to ensure that
                  the size is correct.  if not, exception will be thrown

            \exception  std::underflow_error occurs when the FrameBufferSize param is greater than the size of the frame. Use determine_frame_size()
            \exception  std::overflow_error occurs when the FrameBufferSize param is smaller than the size of the frame.  Use determine_frame_size()
        */
        void static build_frame_packet(const std::vector<BCProtocolMessage> &MessageVector, unsigned char *FrameBuffer, const unsigned int FrameBufferSize, const uint32_t FirstMsgDelayMicroSec) throw(std::underflow_error, std::overflow_error);

        /**
           \brief Builds a complete frame packet which consists of N messages, which are provided in a queue

           \note It is the user's responsibility to allocate the FrameBuffer to the appropriate size. This method will check to ensure that
                 the size is correct.  if not, exception will be thrown

           \exception  std::underflow_error occurs when the FrameBufferSize param is greater than the size of the frame. Use determine_frame_size()
           \exception  std::overflow_error occurs when the FrameBufferSize param is smaller than the size of the frame.  Use determine_frame_size()

        */
        void static build_frame_packet(const std::queue<BCProtocolMessage> &MessageQueue, unsigned char *FrameBuffer, const unsigned int FrameBufferSize, const uint32_t FirstMsgDelayMicroSec) throw(std::underflow_error, std::overflow_error);

        /**
            \brief Extracts a frame packet, including all messages into a vector

            \note Given a buffer containing a frame, this method will extract individual messages and place them into the vector

            \exception  std::runtime_error
            \exception  std::underflow_error
            \exception  std::overflow_error
        */
        void static extract_messages(std::vector<BCProtocolMessage> &MessageVector, const unsigned char *FrameBuffer, const unsigned int FrameBufferSize, uint32_t &FirstMsgDelayMicroSec) throw(std::underflow_error, std::overflow_error);

        /**
            \brief Extracts a frame packet, including all messages into a queue

            \note Given a buffer containing a frame, this method will extract individual messages and place them into the queue

            \exception  std::runtime_error
            \exception  std::underflow_error
            \exception  std::overflow_error
        */
        void static extract_messages(std::queue<BCProtocolMessage> &MessageQueue, const unsigned char *FrameBuffer, const unsigned int FrameBufferSize, uint32_t &FirstMsgDelayMicroSec) throw(std::underflow_error, std::overflow_error);

        /**
            \brief verifies frame integrity by checking key tokens
        */
        bool static verify_frame(const unsigned char *const FrameBuffer, const unsigned int FrameBufferSize);

    };
}

#endif