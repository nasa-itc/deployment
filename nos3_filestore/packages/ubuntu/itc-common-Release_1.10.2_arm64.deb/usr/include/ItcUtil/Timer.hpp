/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef itc_util_timer_HPP
#define itc_util_timer_HPP

#include <ItcUtil/Threadpool.hpp>

#include <set>
#include <string>
#include <map>

#include "ItcUtil/config.hpp"
#include "ItcUtil/types.hpp"
#include "ItcUtil/TimerWork.hpp"

/* A timer allows you to insert work into a threadpool to be executed at some time later. This work can be
 one-shot or periodic. A timer will always maintain proper periodicity depending on OS interaction and
 the number of threads in your threadpool. As long as the number of threads in your threadpool meets or
 exceeds the number of pending operations then soft-realtime is guaranteed.

 All threadpool rules apply with timer. You can use a key for your work and this will ensure that only
 one item with the same key executes at once. Using a key in timer puts your work into a priority queue that
 can have things pushed in front of or behind existing items depending on their timeout.

 Note to developers: a timer has a threadpool. A timer is not a threadpool.

 RULES:

 1) As with threadpool, you must keep your ThreadPoolWork alive while it's in the timer.
 2) You can not delete your work from inside your callback unless you know it's been removed from the timer.
 3) The number of threads must be at least two for timer to work properly.
 4) You can remove work from the timer by calling remove. Once you have called this, you can delete your work. However,
    a race can occur where you call cancel from one thread while the work starts to run in another. In this case, your
    remove call will silently fail and the work will still be performed. To avoid this your work must know it could be
    removed and check some flag.
 5) Don't delete your timer from timer work.
 6) Absolute time values are in UTC.
 7) You can remove or insert work from timer work.
 8) You must still delete one-shot work.
 9) All work must be deleted with timer::delete_work. Do not ever "delete this" in a callback! EVER!
 TODO: Should we allow the timer to use an existing threadpool?
 TODO: Timer could work with a threadpool that has only 1 thread at the expense of more allocs. Allow?

*/

namespace ItcUtil
{
    class DLL_PUBLIC Timer : public boost::noncopyable
    {
    public:
        explicit Timer(int n_threads) throw(std::bad_alloc);
        ~Timer();

        /* These insert one-shot work to be fired at abs_time. */
        void work(TimerWork &work, const AbsoluteTime &abs_time) throw(std::bad_alloc, ThreadPoolClosing);
        void work(TimerWork &work, const char *key, const AbsoluteTime &abs_time) throw(std::bad_alloc, ThreadPoolClosing);
        void work(TimerWork &work, const std::string &key, const AbsoluteTime &abs_time) throw(std::bad_alloc, ThreadPoolClosing);
        void work(TimerWork &work, int key, const AbsoluteTime &abs_time) throw(std::bad_alloc, ThreadPoolClosing);

        /* These insert either one-shot or periodic work to be started at now+rel_time time.
         Periodic work will repeat every rel_time */
        /* if rel_time is 0, then will be one-shot and fire immediately in a timer thread */
        void work(TimerWork &work, const RelativeTime &rel_time, bool periodic, bool immediate = true) throw(std::bad_alloc, ThreadPoolClosing);
        void work(TimerWork &work, const char *key, const RelativeTime &rel_time, bool periodic, bool immediate = true) throw(std::bad_alloc, ThreadPoolClosing);
        void work(TimerWork &work, const std::string &key, const RelativeTime &rel_time, bool periodic, bool immediate = true) throw(std::bad_alloc, ThreadPoolClosing);
        void work(TimerWork &work, int key, const RelativeTime &rel_time, bool periodic, bool immediate = true) throw(std::bad_alloc, ThreadPoolClosing);

        /* These insert either one-shot or periodic work starting at start_time and firing again every period. */
        /* if period is 0, then will be one-shot */
        void work(TimerWork &work, const AbsoluteTime &start_time, const RelativeTime &period) throw(std::bad_alloc, ThreadPoolClosing);
        void work(TimerWork &work, const char *key, const AbsoluteTime &start_time, const RelativeTime &period) throw(std::bad_alloc, ThreadPoolClosing);
        void work(TimerWork &work, const std::string &key, const AbsoluteTime &start_time, const RelativeTime &period) throw(std::bad_alloc, ThreadPoolClosing);
        void work(TimerWork &work, int key, const AbsoluteTime &start_time, const RelativeTime &period) throw(std::bad_alloc, ThreadPoolClosing);

        bool is_closing() const throw();

        void delete_work(TimerWork &work) throw();
    private:
        friend class TimerTPWork;
        friend struct QueuedWork;
        friend class Trampoline;

        ThreadPool *const tp;
        TimerTPWork *const tw;

        class QueuedWorkWrapper
        {
        public:
            explicit QueuedWorkWrapper(QueuedWork *);

            bool operator<(const QueuedWorkWrapper &) const throw();

            QueuedWork *const qw;
        private:
            QueuedWorkWrapper &operator=(const QueuedWorkWrapper &to_copy);
        };

        typedef std::multiset<QueuedWorkWrapper> TimerSet;
        TimerSet timer_set;

        typedef std::map<TimerWork *, QueuedWorkWrapper> WorkMap;
        WorkMap work_map;

        boost::mutex mutex;
        boost::condition_variable cond;
    };
}

#endif
