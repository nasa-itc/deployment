/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_CCSDS_AOS_SENDER_HPP
#define ITC_CCSDS_AOS_SENDER_HPP

#include <ItcCcsds/AosChannel.hpp>
#include <ItcCcsds/AosPrimaryHeader.hpp>
#include <ItcCcsds/AosSenderFrameCallback.hpp>
#include <ItcCcsds/BadFrameSize.hpp>
#include <ItcCcsds/NoSuchTrailer.hpp>
#include <ItcCcsds/Types.hpp>

#define SCID_MAX  0xff
#define VCID_MAX  0x3f

namespace ItcCcsds
{
    /**
        \brief Builds an AOS frame from zero or more input data packets

        The general usage pattern for this class is to continually call the
        \ref add_data method.  This class will copy the data provided to
        this method to an internal buffer.  An entire AOS frame will be
        emitted when the frame is full, or when the \ref flush method is
        called.  Users will be notified of completed AOS frames by creating
        a \ref AosSenderFrameCallback instance and providing it to the
        \ref set_callback method.

        This class is not thread safe.

        Limitations:
            - If the frame error control field is used, the CRC is not
                updated.  The frame error control field will be 0x0000
            - If header error control is used, the CRC is not updated.
                The header error control field will be initialized to
                0x0000; it may be changed by the user via \ref set_header.
    */
    class DLL_PUBLIC AosSender : public AosChannel
    {
    public:
        /**
            \brief Instantiates an AOS channel.

            \param scid                        Spacecraft ID.  Will be clamped
                                                   to \ref SCID_MAX
            \param vcid                        Virtual channel ID.  Will be clamped
                                                    to \ref VCID_MAX
            \param frameSize                   Size of each AOS frame
            \param containsHeaderErrorControl  Whether or not the primary header contains
                                                   the 'header error control' field
            \param insertZoneSize              Size of the insert zone, or 0 if not used
            \param dataType                    Data type contained in the AOS frame
            \param trailerType                 Trailer type(s)
        */
        AosSender(unsigned int scid,
                  unsigned int vcid,
                  unsigned int frameSize,
                  bool containsHeaderErrorControl,
                  unsigned int insertZoneSize,
                  TransferFrameType dataType,
                  TransferFrameTrailerType trailerType);

        /**
            \brief Default destructor
        */
        ~AosSender();

        /**
            \brief Sets the user data callback used when an AOS frame has been
            completed

            \param callback  User callback
        */
        void set_callback(AosSenderFrameCallback *callback);

        /**
            \brief Adds data to the current AOS frame

            If the AOS channel is configured to contain M_PDU data, the provided Space Packet
            will be buffered internally until a call to \ref flush or the size of all
            accumulated packets is greater than or equal to the size of the AOS frame (minus
            any headers).  If this packet will overflow the AOS frame, it will be continued
            in the next frame.

            If the AOS channel is configured to contain B_PDU data, the frame will be flushed
            after every call to this method.  Fill data will be inserted to meet the AOS
            frame size requirements.

            When a frame is sent, the virtual channel frame count is automatically incremented.

            \param data     Data to add
            \param dataLen  Length of data.  This value should be specified in bytes if the
                                channel contains M_PDU data, or bits if the channel contains
                                B_PDU data

            \throw BadFrameSize  AOS channel mode is B_PDU and dataLen is greater than or
            equal to the size of the AOS frame (minus any headers)
        */
        void add_data(const unsigned char *const data,
                      const unsigned int data_len)
        throw(BadFrameSize);

        /**
             \brief Flush the current AOS frame

             Flushes the current AOS frame if the AOS channel.  If the amount of data added
             to the current frame is less than the expected size of data, appropriate fill
             data will be added to the frame to meet size requirements.
        */
        void flush();

        /**
            \brief Resets the current AOS frame

            Any existing data in the current AOS frame is discarded.
        */
        void reset();

        /**
            \brief Sets the insert zone data for the frame being built

            \param data      New insert zone data
            \param data_len  Length, in bytes, of the new insert zone data

            \throw BadFrameSize data_len is not equal to \ref insertZoneSize
        */
        void set_insert_zone_data(unsigned char *data, unsigned int data_len) throw(BadFrameSize);

        /**
            \brief Retrieves the operational control field trailer

            \return Operational control field trailer of the current frame being built

            \throw NoSuchTrailer if the AOS channel was not created with a
            operational control field trailer
        */
        AosOperationControlFieldTrailer get_op_control_field_trailer() throw(NoSuchTrailer);

        /**
            \brief Sets the operational control field trailer

            \param trailer New trailer value

            \throw NoSuchTrailer if the AOS channel was not created with a
            operational control field trailer
        */
        void set_op_control_field_trailer(const AosOperationControlFieldTrailer &trailer)
        throw(NoSuchTrailer);

        /**
            \brief Retrieves the APID used to add idle data to the M_PDU

            \return Idle APID
        */
        unsigned int get_M_PDU_idle_apid();

        /**
            \brief Sets the APID used to add idle data to the M_PDU

            \param apid  New APID
        */
        void set_M_PDU_idle_apid(unsigned int apid);

        /**
            \brief Gets the idle data pattern to use when adding idle
            data to a B_PDU

            \return Idle data pattern
        */
        unsigned char get_B_PDU_idle_data();

        /**
            \brief Sets the idle data pattern to use when adding idle
            data to a B_PDU

            \param byte Idle data pattern
         */
        void set_B_PDU_idle_data(unsigned char byte);

        /**
            \brief Retrieve the AOS primary header of the frame currently being built

            \return AOS primary header
        */
        AosPrimaryHeader get_header();

        /**
            \brief Sets the AOS primary header of the frame currently being built

            If new values for SCID and VCID are set, the values of the \ref scid
            and \ref vcid members will not be updated.

            \param hdr  New header values
        */
        void set_header(const AosPrimaryHeader &hdr);

        const unsigned int scid;
        const unsigned int vcid;

    private:
        void add_M_PDU(const unsigned char *const data, const unsigned int data_len);
        void add_B_PDU(const unsigned char *const data, const unsigned int data_len);
        void reset_cur_ptr();
        void update_M_PDU_header(unsigned int first_header_pointer);
        void update_B_PDU_header(unsigned int data_len);

        AosSenderFrameCallback *callback;
        unsigned char *frame_buf;
        unsigned char *cur_ptr;
        unsigned char *max_ptr;
        union
        {
            unsigned int mpdu;
            unsigned char bpdu;
        } idle_data;
    };
}

#endif /* ITC_CCSDS_AOS_SENDER_HPP */
