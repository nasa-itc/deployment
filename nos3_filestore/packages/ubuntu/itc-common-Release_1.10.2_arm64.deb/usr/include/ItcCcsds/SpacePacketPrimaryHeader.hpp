/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_CCSDS_SPACE_PACKET_HPP
#define ITC_CCSDS_SPACE_PACKET_HPP

// Ignore helper_collection warning for building with Boost 1.57 (assignment operator could not be generated).
#ifdef WIN32
#pragma warning(push)
#pragma warning(disable : 4512)
#endif

#include <boost/archive/text_iarchive.hpp>

#ifdef WIN32
#pragma warning(pop)
#endif

#include <boost/archive/text_oarchive.hpp>

#include <itc_visibility.hpp>

/**
    \brief Defines the size of a Space Packet primary header
*/
#define SPACEPACKET_PRI_HDR_SIZE 6

namespace ItcCcsds
{
    /**
        \brief Space Packet primary header structure

        Contains fields for all portions of a Space Packet header

        \remark All packet primary headers are unpacked into an instance of this structure
        \remark All packet primary headers are packed from an instance of this structure
    */
    class DLL_PUBLIC SpacePacketPrimaryHeader
    {
    public:

        /**
            \brief Unpacks a Space Packet primary header

            \param input        Pointer to buffer from which the SpacePacketPrimaryHeader
                                    will be unpacked
            \param output       Pointer to primary header structure to which the primary
                                    header will be unpacked
            \param payload_ptr  Output parameter indicating the beginning of the Space
                                    Packet payload within the supplied buffer
        */
        static void unpack(const unsigned char *input,
                           SpacePacketPrimaryHeader &output,
                           const unsigned char **payload_ptr = NULL);


        /**
            \brief Creates a CCSDS Space Packet primary header initialized
            with empty values.
        */
        SpacePacketPrimaryHeader();

        /**
            \brief Create a Space Packet primary header

            \param version_num      Version number - specification recommends this is set to zero
            \param type             Command/Telemetry indicator:
                                        0 - telemetry packet
                                        1 - command packet
            \param sec_header_flag  Secondary header flag
                                        1 - secondary header is present
                                        0 - secondary header not present
            \param apid             Application ID
            \param seq_flag         Sequence flag
                                        1 (0b01) - Indicates that the packet contains the first
                                                     segment of User Data
                                        0 (0b00) - Indicates that the packet contains a continuation
                                                     segment of User Data
                                        2 (0b10) - Indicates that the packet contains the last
                                                     segment of User Data
                                        3 (0b11) - Indicates that the packet contains unsegmented
                                                     user data (It is not part of a sequence of packets)
            \param packet_count     Packet count.  Should increase monotonically for all packets of
                                       the same APID, starting at 0
            \param packet_length    Contains a length count that equals one fewer than the length
                                       (in bytes) of the Packet Data Field (Packet Secondary Header
                                       and User Data Field)
        */
        SpacePacketPrimaryHeader(unsigned char version_num,
                                 unsigned char type,
                                 unsigned char sec_header_flag,
                                 unsigned short apid,
                                 unsigned char seq_flag,
                                 unsigned short packet_count,
                                 unsigned short packet_length);


        unsigned short version_num     :  3;
        unsigned short type            :  1;
        unsigned short sec_header_flag :  1;
        unsigned short apID            : 11;
        unsigned short seq_flag        :  2;
        unsigned short packet_count    : 14;
        unsigned short packet_length   : 16;

        /**
            \brief Packs a Space Packet primary header into a buffer

            \param output  Pointer to buffer to which the packed Space Packet Primary header
                             will be written
            \param input   Pointer to primary header structure from which the Space Packet
                             primary header will be packed
        */
        void pack(unsigned char *output);


        /**
            \brief Method that specifies which member data to serialize to the specified archive

            This method is only called internally by boost::serialization

            \param ar       Archive that serialized data is to be written to
            \param ver_num  Version number
        */
        template<class Archive>
        void serialize(Archive &ar, const unsigned int /*ver_num*/)
        {
            //temporary variables to hold bit field values to serialize/de-serialize
            unsigned char version_num_temp;
            unsigned char type_temp;
            unsigned char sec_header_flag_temp;
            unsigned short apID_temp;
            unsigned char seq_flag_temp;
            unsigned short packet_count_temp;
            unsigned short packet_length_temp;

            if(!Archive::is_loading::value)
            {
                version_num_temp     = version_num;
                type_temp            = type;
                sec_header_flag_temp = sec_header_flag;
                apID_temp            = apID;
                seq_flag_temp        = seq_flag;
                packet_count_temp    = packet_count;
                packet_length_temp   = packet_length;

                ar &version_num_temp;
                ar &type_temp;
                ar &sec_header_flag_temp;
                ar &apID_temp;
                ar &seq_flag_temp;
                ar &packet_count_temp;
                ar &packet_length_temp;
            }
            else if(Archive::is_loading::value)
            {
                ar &version_num_temp;
                ar &type_temp;
                ar &sec_header_flag_temp;
                ar &apID_temp;
                ar &seq_flag_temp;
                ar &packet_count_temp;
                ar &packet_length_temp;

                version_num     = version_num_temp;
                type            = type_temp;
                sec_header_flag = sec_header_flag_temp;
                apID            = apID_temp;
                seq_flag        = seq_flag_temp;
                packet_count    = packet_count_temp;
                packet_length   = packet_length_temp;
            }
        }
    };
}

// workaround until boost-5761 (https://svn.boost.org/trac/boost/ticket/5761) is corrected
BOOST_CLASS_TRACKING(ItcCcsds::SpacePacketPrimaryHeader, boost::serialization::track_never)

#endif /* ITC_CCSDS_SPACE_PACKET_HPP */
