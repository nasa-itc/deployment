/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_CCSDS_AOS_RECEIVER_HPP
#define ITC_CCSDS_AOS_RECEIVER_HPP

#include <boost/function.hpp>

#include <itc_visibility.hpp>

#include <ItcCcsds/AosChannel.hpp>
#include <ItcCcsds/AosReceiverDataCallback.hpp>
#include <ItcCcsds/BadFrameSize.hpp>
#include <ItcCcsds/NonconformantData.hpp>
#include <ItcCcsds/Types.hpp>

namespace ItcCcsds
{
    /**
        \brief An AOS channel receiver.

        Each receiver in use by the target system should use its own AosReceiver object.

        This class is not thread-safe.

        This class assumes all data provided to this system is in big-endian format.  This
        assumption has been made because space systems responsible for building the AOS
        frames typically run on big-endian processors (or are simulators that explicitly
        output data in big-endian format).
    */
    class DLL_PUBLIC AosReceiver : public AosChannel
    {
    public:
        /**
            \brief Instantiates an AOS channel.

            \param frameSize                   Size of each AOS frame
            \param containsHeaderErrorControl  Whether or not the primary header contains
                                                   the 'header error control' field
            \param insertZoneSize              Size of the insert zone, or 0 if not used
            \param dataType                    Data type contained in the AOS frame
            \param trailerType                 Trailer type(s)
        */
        AosReceiver(unsigned int frameSize,
                    bool containsHeaderErrorControl,
                    unsigned int insertZoneSize,
                    TransferFrameType dataType,
                    TransferFrameTrailerType trailerType);

        /**
            \brief Default destructor
        */
        ~AosReceiver();

        /**
            \brief Sets the user data callback used when parsing the entire AOS frame.

            \param callback  User callback
         */
        void set_callback(AosReceiverDataCallback *callback);

        /**
            \brief Parses an entire AOS frame.

            This method will parse the entire AOS frame and notify the callback
            when valid data is found.

            \param frame                AOS frame data.  May not be NULL.
            \param frameLength          AOS frame length, in bytes
            \param primaryHeader        Pointer to a structure to receive the AOS
                                            frame primary header information.  Optional.
            \param insertZone           Pointer to a location to receive a pointer
                                            to the start of the insert zone.  Optional.
                                            This is only set if provided and an insert
                                            zone is expected for this AOS channel
            \param opControlTrailer     Pointer to a structure to receive the operational
                                            control field trailer.  Optional.  This is only
                                            set if provided and an operational control
                                            trailer is expected for this AOS channel.
            \param errorControlTrailer  Pointer to a structure to receive the error
                                            control trailer.  Optional.  This is only set
                                            if provided and an error control trailer is
                                            expected for this AOS channel.

            \throw BadFrameSize  If the \ref frameLength parameter is not equal to
            the expected frame length provided in the constructor
            \throw InvalidState  If the data stream does not conform to the AOS standard
        */
        void parse_frame(const unsigned char *frame,
                         unsigned int frameLength,
                         AosPrimaryHeader *primaryHeader = NULL,
                         const unsigned char **insertZone = NULL,
                         AosOperationControlFieldTrailer *opControlTrailer = NULL,
                         AosFrameErrorControlFieldTrailer *errorControlTrailer = NULL)
        throw(BadFrameSize, NonconformantData);

    private:
        class OverflowPacket;

        void parse_M_PDU_Header(const unsigned char *pduStart, AosMPDUHeader &hdr);
        void walk_M_PDU(const AosPrimaryHeader *primaryHeader, const unsigned char *pduStart, unsigned int pduLength);
        void parse_B_PDU_Header(const unsigned char *pduStart, AosBPDUHeader &hdr);
        void walk_B_PDU(const AosPrimaryHeader *primaryHeader, const unsigned char *pduStart, unsigned int pduLength);

        OverflowPacket *overflow_packet;
        AosReceiverDataCallback *callback;
    };
}

#endif /* ITC_CCSDS_AOS_RECEIVER_HPP */
