/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_ASYNC_COMM_SOCKET_CLIENT_HPP
#define ITC_ASYNC_COMM_SOCKET_CLIENT_HPP

#include <string>

#include <boost/noncopyable.hpp>

#include <itc_visibility.hpp>

#include <ItcAsyncComm/Socket/DataReceivedCallback.hpp>
#include <ItcAsyncComm/Socket/Types.hpp>

namespace ItcAsyncComm
{
    namespace Socket
    {
        class ClientImpl;

        class DLL_PUBLIC Client : public boost::noncopyable
        {
        public:
            Client(const char *const host, const unsigned short port, const unsigned int reconnect_time = 10);
            ~Client();

            void send(const unsigned char *const data, const unsigned int dataLen) throw();

            bool is_connected() throw();

            void set_callback(DataReceivedCallback *callback) throw();
            DataReceivedCallback *get_callback() throw();

            void set_reconnect_time(const unsigned int reconnect_time) throw();
            unsigned int get_reconnect_time() throw();

            const std::string host;
            const unsigned short port;

        private:
            ClientImpl *pimpl;
        };
    }
}

#endif /* ITC_ASYNC_COMM_SOCKET_CLIENT_HPP */

