/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_LOGGER_LOGGER_OUTPUT_STREAM_HPP
#define ITC_LOGGER_LOGGER_OUTPUT_STREAM_HPP

#include <string>
#include <ostream>
#include <sstream>
#include <iomanip>
#include <exception>

#include <itc_common_config.hpp>
#include <itc_visibility.hpp>

#include <ItcLogger/Types.hpp>

namespace ItcLogger
{
    /**
        \brief Represents an output stream for logging.

        Using std::endl will log what is currently in the buffer.
        When the stream is destroyed anything left in the buffer is logged.
    */
    class DLL_PUBLIC LoggerOutputStream
    {
    public:
        /**
            \brief Destroy an instance of the LoggerOutputStream class.
        */
        virtual ~LoggerOutputStream();

        /**
            \brief Templated override for insertion operator.

            \param val Value to be formatted and inserted into the stream.

            \return The LoggerOutputStream object (*this).
        */
        template<typename T>
        LoggerOutputStream& operator<<(T val);
        
        /**
            \brief Template specialization for insertion operator.

            \param pf A function that takes and returns a stream object.

            \return The LoggerOutputStream object (*this).
        */
        LoggerOutputStream& operator<<(std::ostream& (*pf)(std::ostream&));
        
        /**
            \brief Template specialization for insertion operator.

            \param pf A function that takes and returns a stream object.

            \return The LoggerOutputStream object (*this).
        */
        LoggerOutputStream& operator<<(std::ios& (*pf)(std::ios&));
        
        /**
            \brief Template specialization for insertion operator.

            \param pf A function that takes and returns a stream object.

            \return The LoggerOutputStream object (*this).
        */
        LoggerOutputStream& operator<<(std::ios_base& (*pf)(std::ios_base&));
        
        /**
            \brief Template specialization for insertion operator.

            \param e Exception whose message will be inserted into the stream.

            \return The LoggerOutputStream object (*this).
        */
        LoggerOutputStream& operator<<(const std::exception &e);

    private:
        /**
            \brief Represents the underlying log message buffer of a logger output stream.
        */
        class LoggerStringBuffer : public std::stringbuf
        {
        public:
            /**
                \brief Construct an instance of the LoggerStringBuffer class.

                \param stream Buffer owner.
            */
            LoggerStringBuffer(LoggerOutputStream &stream);

            /**
                \brief Destroy an instance of the LoggerStringBuffer class.
            */
            virtual ~LoggerStringBuffer();

            virtual int sync();
            
            /**
                \brief Get a value which indicates if the buffer is currently empty.

                \return True if the buffer is empty.
            */
            bool is_empty();
            
            /**
                \brief Reset buffer pointers.
            */
            void reset();

        private:
            /**
                \brief Copy constructor (undefined).
            */
            LoggerStringBuffer(const LoggerStringBuffer &other);
            
            /**
                \brief Assignment constructor (undefined).
            */
			LoggerStringBuffer& operator=(const LoggerStringBuffer &other);

#ifdef ITC_COMMON_CXX11

            /**
                \brief Move constructor (undefined).
            */
            LoggerStringBuffer(LoggerStringBuffer &&other);
            
            /**
                \brief Move operator (undefined).
            */
			LoggerStringBuffer& operator=(LoggerStringBuffer &&other);

#endif
			
            LoggerOutputStream &stream; //!< Buffer owner
        };

        /**
            \brief Construct an instance of the LoggerOutputStream class.
        */
        LoggerOutputStream(const log_level_t log_level, Logger &logger);
        
        /**
            \brief Copy constructor.
        */
        LoggerOutputStream(const LoggerOutputStream &other);

        /**
            \brief Assignment operator (undefined).
        */
        LoggerOutputStream& operator=(const LoggerOutputStream &other);

#ifdef ITC_COMMON_CXX11

        /**
            \brief Move construct (undefined).
        */
        LoggerOutputStream(LoggerOutputStream &&other);

        /**
            \brief Move operator (undefined).
        */
        LoggerOutputStream& operator=(LoggerOutputStream &&other);

#endif

        /**
            \brief Get a value indicating if the log level is enabled.
        */
        bool is_level_enabled();

        /**
            \brief Log what is currently in the buffer.
        */
        void log_buffer();
        
        /**
            \brief Reset the log message buffer.
        */
        void reset();

        LoggerStringBuffer buffer;  //!< Log message buffer
        std::ostream buffer_stream; //!< Log message buffer stream
        log_level_t log_level;      //!< Log level to use when logging data stored in the buffer
        Logger &logger;             //!< The logger which the stream is associated with
        
        friend class GlobalLogger;
        friend class Logger;
    };

    template<typename T>
    LoggerOutputStream& LoggerOutputStream::operator<<(T val)
    {
        if (this->is_level_enabled())
        {
            this->buffer_stream << val;
        }

        return *this;
    }
}

#endif /* ITC_LOGGER_LOGGER_OUTPUT_STREAM_HPP */