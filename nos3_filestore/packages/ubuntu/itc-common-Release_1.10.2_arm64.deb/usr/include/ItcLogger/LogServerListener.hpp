/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_LOGGER_LOG_SERVER_LISTENER_HPP
#define ITC_LOGGER_LOG_SERVER_LISTENER_HPP

#include <algorithm>
#include <boost/asio.hpp>

#include <itc_visibility.hpp>

namespace ItcLogger
{
    /**
       \brief Listener for receiving log messages from the server.

       When the server receives log messages from one or more remote log targets,
       the \ref LogServer instance will notify all listeners.
    */
    class DLL_PUBLIC LogServerListener
    {
    public:
        /**
           \brief Empty destructor
        */
        virtual ~LogServerListener();

        /**
           \brief Notification that a new remote logger has come online.

           Users may override the function if desired.  The default implementation
           does nothing.

           \param socket  Socket the remote logger is connected to
        */
        virtual void new_logger(const boost::asio::ip::tcp::socket &socket);

        /**
           \brief Notification of a new log message has been received.

           Users must implement this function.

           \param socket  Socket the remote logger is connected to
           \param msg     Log message
        */
        virtual void new_message(const boost::asio::ip::tcp::socket &socket, const char *msg) throw() = 0;

        /**
           \brief Notification that a new remote logger has gone offline.

           Users may override the function if desired.  The default implementation
           does nothing.

           \param socket  Socket the remote logger was connected to
        */
        virtual void logger_closed(const boost::asio::ip::tcp::socket &socket);
    };
}

#endif /* ITC_LOGGER_LOG_SERVER_LISTENER_HPP */
