/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_LOGGER_TARGET_HPP
#define ITC_LOGGER_TARGET_HPP

#include <string>

#include <boost/noncopyable.hpp>
#include <boost/thread/mutex.hpp>

#include <itc_visibility.hpp>

#include <ItcLogger/TargetImpl.hpp>
#include <ItcLogger/Types.hpp>


/**
   \brief Name of the built-in STDIO log target

   The STDIO log target built-in to the itc_logger library provides logging to stderr and/or
   stdout.  Ordering of these messages is ensured by the itc_logger library.

   It accepts the following parameters:

   stderr_threshold  Optional.  Threshold at which log messages will be sent to stderr.  If
                     set to 'LOGGER_WARNING' (the default), messages at LOGGER_WARNING and
                     higher ('LOGGER_ERROR', 'LOGGER_FATAL') will be sent to stderr.  All
                     other messages will be sent to stdout.  If this value cannot be parsed
                     as a logging level, ItcLogger::InvalidArguments will be thrown.
   flush_rate  Optional.  This causes messages sent to stdout to be forcefully flushed after
               every N log messages.  Default value is 50.  This value must be parsable as
               a integer and be greater than 0.  A ItcLogger::InvalidArguments exception
               will be thrown otherwise.  Note that messages to stderr are always flushed
               immediately (by design of stderr).
*/
#define STDIO_BUILTIN_TARGET_IMPL  "stdio"

/**
   \brief Name of the built-in FILE log target

   The FILE log target built-in to the itc_logger library provides logging to files.  A
   file is opened when a target is instantiated (see below for options).  When an I/O
   error occurs, the message is dropped silently and the file target will attempt to
   re-open the file during the next log message.

   It accepts the following parameters:

   filename   Required.  The path of the file to log to.  This parameter is split into
              a path and filename component on the last / or \ character.  If the path
              is NULL, the file will be created in the current working directory.  If
              the filename component is empty, ItcLogger::InvalidArguments is thrown.  If the
              rollover option is 'true', or the 'prepend_date' option is true, the current
              date (in "yyyy-mm-dd-" format) is prepended to the name of the file.  If not
              set, a ItcLogger::InvalidArguments exception is thrown.
   rollover   Optional.  If 'true', the log filenames are prepended with the current date,
              and a new file is created for each day's log output.  If 'false' (the default),
              all logs go to the file named by the filename argument.
   overwrite   Optional.  If 'true', the file is overwritten when opened, or in the case of
               a filesystem error, when re-opened.  WARNING: potential data loss!  If 'false'
               (the default), the file is appended when opened or re-opened.
   prepend_date  If 'true', the current date is always prepended to the name of the file.
                 Default value if 'false'.  Implied when 'rollover'=true.
*/
#define FILE_BUILTIN_TARGET_IMPL   "file"

/**
   \brief Name of the built-in REMOTE log target

   The REMOTE log target built-in to the itc_logger library provides logging to a
   network server.  A socket is opened and a connection attempt is made to the
   named host/port when the target is instantiated.  Any log messages sent to the
   target while a connection attempt is being made (or while attempting to recover
   from a previous failed connection attempt or error) are cached until the
   connection succeeds, at which point all cached messages are sent to the server,
   or the maximum number of entries in the cache exceeds a configurable limit.

   When the first remote target is initialized, a new thread is started to handle
   TCP/IP asynchronously (using Boost ASIO).  This thread will never be stopped.
   All remote targets will share use of this thread.

   It accepts the following parameters:

   host  Required.  Hostname of the logging server.  If not set, a ItcLogger::InvalidArguments
         exception is thrown.
   port  Required.  Port the logging server is listening on.  Must be convertible to an
         unsigned short.  If not set, or could not parse a value, a ItcLogger::InvalidArguments
         exception is thrown.
   max_queue_size  Optional.  Maximum number of messages to keep in the message
                   cache.  Must be parsable as a integer greater than or equal to 0, or
                   else a ItcLogger::InvalidArguments exception will be thrown.  If 0, no
                   messages will be cached.  Default value is 100.  When log messages
                   are pruned from the queue to keep the number of entries under
                   this limit, the oldest messages are removed first.
*/
#define REMOTE_BUILTIN_TARGET_IMPL  "remote"


/**
   \brief Name of the built-in MEMORY log target

   The MEMORY log target built-in to the itc_logger library provides logging to
   memory.  It is primarily designed to be use by unit testing applications to
   ensure certain log messages are printed by the system under test.

   No parameters are accepted.

   See the \ref MemoryLoggerImpl class for use.
*/
#define MEMORY_BUILTIN_TARGET_IMPL  "memory"

#define TIMESTAMPED_MESSAGE_FORMAT        "%t | %s"             //!< Predefined format for a timestamped message.
#define TIMESTAMPED_LEVEL_MESSAGE_FORMAT  "%t | %l | %s"        //!< Predefined format for a timestamped message with log level.
#define FULL_DETAILS_MESSAGE_FORMAT       "%t | %l | %n | %s"   //!< Predefined format for a timestamped message with log level and logger name.


namespace ItcLogger
{
    /**
        \brief Logging target

        When a logger receives a valid log event, the logger will defer the actual logging
        to zero or more targets.  The target is responsible for ensuring the log message
        makes it to storage for later retrieval.

        In order to support a plug-in system, the target defers the work to a "target
        implementation" that may be loaded from a shared library.  Many typical log
        target implementations are built-in to this library.

        When a logging target is created, it must be provided the name of an implementation
        library.  This string must be either:
           1.  The name of a built-in target implementation.  The names of the built-in
                 implementations can be found by the *_BUILTIN_LOGGER_IMPL macros
           2.  The name of a dynamically loaded library providing the implementation.
                 When using a dynamic library, the library name to load is dynamically
                 computed as:
                    Linux:  ItcLogger_<name>
                    Windows: logger_<name>
                 See plugin.hpp for more information on how to implement a plugin.

        When using dynamically loaded libraries, the user of this function is responsible
        for ensuring the named library is in the PATH.
    */
    class DLL_PUBLIC Target : public boost::noncopyable
    {
    public:
        /**
            \brief Creates a new logging target.

            \param impl  Name of the target implementation library
            \param args  Key-value mapping of arguments to pass to the library

            \throw LibNotFound  The library could not be found.  Note that this is a subclass
                                  of ItcLogger::BadLibrary
            \throw LibNotValid  The library does not meet the interface requirements.  Note
                                  that this is a subclass of ItcLogger::BadLibrary.
            \throw InvalidArguments   A required argument for the target implementation is missing
        */
        Target(const char *impl, const LogArguments &args) throw(LibNotFound, LibNotValid, InvalidArguments);
        
        /**
            \brief Creates a new logging target.

            \param impl  Name of the target implementation library
            \param id    ID of the target
            \param args  Key-value mapping of arguments to pass to the library

            \throw LibNotFound  The library could not be found.  Note that this is a subclass
                                  of ItcLogger::BadLibrary
            \throw LibNotValid  The library does not meet the interface requirements.  Note
                                  that this is a subclass of ItcLogger::BadLibrary.
            \throw InvalidArguments   A required argument for the target implementation is missing
        */
        Target(const char *impl, const char *id, const LogArguments &args) throw(LibNotFound, LibNotValid, InvalidArguments);

        /**
            \brief Creates a new logging target.

            This constructor is useful in the situation where an application requires a very
            specialized log target implementation that is unlikely to be used in another
            application.  The user of this constructor is expected to instantiate a \ref
            TargetImpl instance and pass it to a new target.

            Note that this method takes ownership of the passed pointer.  When this target
            is deleted, the passed \a impl pointer will be deleted as well.

            \param impl  Log target implementation to use.  May not be NULL
        */
        Target(TargetImpl *impl);

        /**
            \brief Public destructor
        */
        ~Target();
        
        /**
            \brief Get the target id

            \return The target id
        */
        std::string get_id() const;

        /**
            \brief Sets the format to use when outputting a log message.

            A format string may contain special characters to customize output to a target.
            For instance, the format string "%s" would simply output the log message by
            itself.  The format string "%t %s" would output the date and timestamp
            followed by the log message.  A full list of special characters is:

               %d   Current date in YYYY-MM-DD format (e.g., 2012-01-01)
               %t   Current date and time in YYYY-MM-DD HH:MM:SS.sssss format (e.g., 2012-01-01 07:14:42.12345)
               %n   Name of the logger (e.g., log1)
               %h   ID of the thread issuing the log statement
               %l   Log level (e.g., DEBUG)
               %s   Log message
               %%   % character

            The default log format is %s.

            Any character, other than the special '%' character, will be copied to an output
            log message unaltered.

            The *_MESSAGE_FORMAT macros may also be used for convenient access to
            common logging formats.

            This method is thread safe.
        */
        void set_format(const char *fmt) throw(BadFormatString);

        /**
            \brief Log a message.

            This method is thread safe.  Users should normally call logger::log
            and add instances of this target to the logger instead of calling
            this method directly.

            \param logger_name  The name of the logger calling this method
            \param log_level    The logging level for this message.
            \param msg          Log message

            \throw std::bad_alloc  If the log target implementation attempts to
                                     cache a log message, and there is not enough
                                     memory to cache the message.
         */
        void log(const char *logger_name, log_level_t log_level, const char *msg) throw(std::bad_alloc);

        /**
            \brief Opaque pointer to implementation class

            Users may use this pointer to interact directly with the log target
            implementation, provided they know which class is which.
        */
        TargetImpl *impl;

    ITC_LOGGER_PRIVATE:
        friend class Logger;
        void added_to_logger(Logger *logger);
        void removed_from_logger(Logger *logger);
        
        std::string id;
        std::string format;
		boost::mutex mutex;
    };
}

#endif /* ITC_LOGGER_TARGET_HPP */
