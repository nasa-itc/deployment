/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_LOGGER_TYPES_HPP
#define ITC_LOGGER_TYPES_HPP

#include <exception>
#include <string>
#include <map>

#include <boost/shared_ptr.hpp>

#include <itc_visibility.hpp>

#include <ItcLogger/BadConfFile.hpp>
#include <ItcLogger/BadFormatString.hpp>
#include <ItcLogger/ConfFileNotFound.hpp>
#include <ItcLogger/InvalidArguments.hpp>
#include <ItcLogger/LibNotFound.hpp>
#include <ItcLogger/LibNotValid.hpp>

// privacy macros allow for white-box unit testing; users of this
// library should not override
#ifndef ITC_LOGGER_PRIVATE
#define ITC_LOGGER_PRIVATE private
#endif

namespace ItcLogger
{
    // forward decl

    class GlobalLogger;
    class Logger;
    class LoggerOutputStream;
    class Target;
    class TargetImpl;

    // shared pointer decl

    typedef boost::shared_ptr< Target > TargetPtr;

    /**
         \brief Map for options used when creating log targets.
    */
    typedef std::map< std::string, std::string > LogArguments;

    /**
        \brief Enumeration of all available logging levels.
    */
    enum log_level_t
    {
        LOGGER_OFF,       //!< The highest possible rank and is intended to turn off logging
        LOGGER_FATAL,     //!< Severe errors that cause premature termination. Expect these to be immediately visible on a status console
        LOGGER_ERROR,     //!< Other runtime errors or unexpected conditions. Expect these to be immediately visible on a status console
        LOGGER_WARNING,   //!< Use of deprecated APIs, poor use of API, 'almost' errors, other runtime situations that are undesirable or unexpected, but not necessarily "wrong". Expect these to be immediately visible on a status console
        LOGGER_INFO,      //!< Interesting runtime events (startup/shutdown). Expect these to be immediately visible on a console, so be conservative and keep to a minimum
        LOGGER_DEBUG,     //!< Detailed information on the flow through the system. Expect these to be written to logs only
        LOGGER_TRACE,     //!< More detailed information. Expect these to be written to logs only
        LOGGER_INVALID    //!< Invalid level used for run-time checking of log levels
    };

    /**
        \brief Converts a human-readable string to a \ref log_level_t.

        \param level  Level to convert

        \return The appropriate \ref log_level_t instance, or \ref LOGGER_INVALID
        if the string does not represent a valid logging level
    */
    DLL_PUBLIC log_level_t String2Level(const char *level);

    DLL_PUBLIC const char *Level2String(ItcLogger::log_level_t log_level);
}

#endif /* ITC_LOGGER_TYPES_HPP */
