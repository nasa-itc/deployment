/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_LOGGER_LOGGER_HPP
#define ITC_LOGGER_LOGGER_HPP

#include <cstdarg>
#include <list>
#include <string>

#include <boost/noncopyable.hpp>

#include <ItcUtil/NamedObjectCache.hpp>
#include <itc_visibility.hpp>

#include <ItcLogger/Target.hpp>
#include <ItcLogger/Types.hpp>
#include <ItcLogger/LoggerOutputStream.hpp>

namespace ItcLogger
{
    /**
        \brief Primary class users of the itc_logger framework will interact with.

        Loggers should be used solely for logging human-readable information.

        This library should not be used by the following itc libraries as they are
        used internally by this library:
            - ItcLoader
    */
    class DLL_PUBLIC Logger : public boost::noncopyable
    {
    public:
        typedef std::list< TargetPtr > TargetList;   //!< List of targets
        typedef std::list< Logger * > LoggerList;    //!< List of loggers


        /**
            \brief Retrieves a specific logger instance.

            Each logger is created/looked up by a unique name assigned by the user of the library,
            either through configuration files or passed as parameters.  This method will cache
            and return previously-returned instances.  For example, the first call to get("log1")
            will return a newly-created instance of a logger, while subsequent calls to get("log1")
            will return a cached version.

            Logger names can be thought of as a tree structure delimited by periods.  For example,
            "log1" is a 'root logger', while "log1.child1" is a 'child logger' of the "log1"
            logger.  A child logger acts in the exact same way as a normal logger, save one feature:
            a child logger will pass log messages up to its parent (provided it wasn't culled by
            the child's logging level).

            Callers of this method must not delete the returned pointer.  It is managed by the
            library.

            \param name  Unique name of the logger

            \return Pointer to a logger
        */
        static Logger *get(const char *name);

        /**
            \brief Allow the library to clean up a logger.

            Typically, an application will call get() during initialization and never let go of the
            returned pointer.  However, if an application does not need a particular logger instance
            any more, they can use one of the remove() functions to free memory allocated by the
            logger, its targets, and target implementations.  The target implementation library
            will be unloaded if no other target implementations are using it.

            This method is not thread safe.

            This method will invalidate all logger pointers previously retrieved by \ref Logger::get
            to this logger \b and all child loggers.

            \param name  Unique name of the logger.  May not be NULL
        */
        static void remove(const char *name);

        /**
            \brief Allow the library to clean up a logger

            See remarks on remove(const char*) function.

            WARNING: the passed pointer and all children are invalidated during this call.  Once this
            function returns, any previously pointers returned from \ref Logger::get MUST NOT be used!

            \param log  Logger to remove.  This pointer is invalidated by this call.  May
                          not be NULL.
        */
        static void remove(Logger *log);

        /**
            \brief Configure loggers and targets from a configuration file.

            For convenience, it is possible to create a configuration file describing all
            loggers and their configuration.  This method will create all logger instances
            and targets defined in the configuration file.  Each logger instance may be
            retrieved at any time (even before calling configure()) by calling the get()
            method.

            If an exception is thrown by this method, all loggers defined in the configuration
            file before the parse error ocurred will be instantiated and have their log
            level set.  While log targets may be created while parsing the file, they will
            only be added to loggers if the function is successful.

            This method will catch all thrown exceptions and log an appropriate error to
            STDERR.  BadConfFile will be thrown.

            \param filename  Configuration filename to parse

            \throw BadConfFile  The configuration file is invalid.  There are several
                                    possible reasons for throwing this exception:
                                       1. the named configuration file could not be found
                                       2. failed schema check
                                       3. a log target implementation plugin library
                                          could not be loaded or is invalid
                                       4. a target is missing parameters or one or more
                                          parameters are invalid
        */
        static void configure(const char *filename) throw(BadConfFile);


        /**
            \brief Public destructor
        */
        ~Logger();

        /**
            \brief Adds a target to the logger

            This method is thread safe.

            \param tgt  Target to add
        */
        void add_target(const TargetPtr &tgt) throw();

        /**
            \brief Removes a target from the logger

            If a target has been removed from all loggers, and the user no longer holds
            a pointer to the target, the target will be deallocated.  Once all targets
            from a library have been unloaded, the target implementation library (if
            one is in use) may be unloaded as well.

            This method is thread safe.

            \param tgt  Target to add
        */
        void remove_target(const TargetPtr &tgt) throw();

        /**
            \brief Get a value indicating if the taget is attached to this
            logger or a parent.

            \return TRUE if the target is attached
        */
        bool has_target(const TargetPtr &tgt);
        
        /**
            \brief Get a value indicating if a taget with the id is attached
            to this logger or a parent.

            \return TRUE if the target is attached
        */
        bool has_target(const char* id);

        /**
            \brief Retrieve a list of targets attached to this logger instance.

            Note that this returns the list of targets at the moment this method is called.
            Another thread may modify the target list anytime after this method returns.
        */
        const TargetList get_targets() throw();

        /**
            \brief Retrieve a list of targets attached to this logger instance and all
            parent logger instances.

            Note that this returns the list of targets at the moment this method is called.
            Another thread may modify the target list anytime after this method returns.
        */
        const TargetList get_all_targets() throw();

        /**
            \brief Retrieve a child logger.

            This is a convenience method to retrieve a child logger from an existing
            logger instance.  It is functionally equivalent to:

            logger::get(inst->name+"."+child_name);

            \param child_name  Name of the child logger to retrieve

            \return Child logger instance
        */
        Logger *get_child_logger(const char *child_name);

        /**
            \brief Determines if a log level is enabled or not.

            A log level is considered enabled if the current log level is set equal to or
            lower than the provided level.  For example, if the current log level is set
            to INFO, is_level_enabled(DEBUG) will return FALSE, while is_level_enabled(ERROR)
            will return TRUE.

            If this instance is a child logger that has not had a level explicitly set,
            then the parent logger's level is queried; the deferral continues up the tree
            of loggers until one with an explicitly set level is found.  This process is
            guaranteed to end because root logger always have an explicitly-set level.

            This method is thread safe, but no mutex locking is done to ensure perfect
            synchronization if another thread changes the log level during a call to this
            method.  Locking a mutex is considered too much overhead for too little gain.

            \param log_level Log level to check

            \return TRUE if the log level is enabled
            \return FALSE if the log level is disabled
        */
        bool is_level_enabled(log_level_t log_level) throw();

        /**
            \brief Explicitly sets the log level

            The default log level is LOGGER_INFO for root loggers, and is inherited
            for child loggers.

            This method will recursively set the log level for all child loggers
            that have not had an explicit level set.

            This method is thread safe, but no mutex locking is done to ensure perfect
            synchronization if another thread changes the log level during a call to this
            method.  Locking a mutex is considered too much overhead for too little gain.

            \param new_level  New log level
        */
        void set_level(log_level_t new_level) throw();

        /**
            \brief Resets the log level to the default value.

            The default log level is LOGGER_INFO for root loggers, and is inherited
            for child loggers.
        */
        void reset_level() throw();

        /**
            \brief Retrieve the log level

            This method is thread safe, but no mutex locking is done to ensure perfect
            synchronization if another thread changes the log level during a call to this
            method.  Locking a mutex is considered too much overhead for too little gain.

            \return Current log level
        */
        log_level_t get_level() throw();

        /**
            \brief Log a message.

            If the log message is pruned due to level constraints, this function returns
            immediately.  Otherwise, the variatic arguments are used to build the actual
            log message.  The actual log message is passed to each target's log method.

            In order to build the string containing variatic arguments, a buffer is kept
            internally.  If the buffer is too small, it will be expanded until it is
            large enough.  Once the buffer has grown, it will not be reduced in size
            except through an explicit call to \ref set_buffer_size.

            This method is thread safe.  If multiple calls are made to this method
            on the same instance at the same time, the second (third, fourth, etc)
            calls will block until the previous call (from another thread) completes.
            This design is to ensure correct ordering of log messages, not necessarily
            the highest performance.

            \param log_level  The logging level for this message.
            \param str        The logging message formatted C-style. (printf, etc.)

            \throw std::bad_alloc  My be thrown under two situations:
                                     1. When expanding the varargs, if the expanded
                                          string is longer than the currently allocated
                                          internal buffer, and no more space can be
                                          allocated for the buffer
                                     2. If a log target implementation attempts to
                                          cache a log message, and there is not enough
                                          memory to cache the message.
         */
        void log(log_level_t log_level, const char *str, ...) throw(std::bad_alloc)
#ifdef __GNUC__
        __attribute__((format(printf, 3, 4)))  // 3, 4 because 'this' pointer is first arg
#endif
        ;
        
        /**
             \brief va_list version of \ref log(LOGGER_TRACE, ...)
        */
        void vlog(log_level_t log_level, const char *str, std::va_list &ap) throw(std::bad_alloc);

        /**
             \brief Equivalent to \ref log(LOGGER_TRACE, ...)
        */
        void trace(const char *str, ...) throw(std::bad_alloc)
#ifdef __GNUC__
        __attribute__((format(printf, 2, 3)))
#endif
        ;

        /**
             \brief Equivalent to \ref log(LOGGER_DEBUG, ...)
        */
        void debug(const char *str, ...) throw(std::bad_alloc)
#ifdef __GNUC__
        __attribute__((format(printf, 2, 3)))
#endif
        ;

        /**
             \brief Equivalent to \ref log(LOGGER_INFO, ...)
        */
        void info(const char *str, ...) throw(std::bad_alloc)
#ifdef __GNUC__
        __attribute__((format(printf, 2, 3)))
#endif
        ;

        /**
             \brief Equivalent to \ref log(LOGGER_WARNING, ...)
        */
        void warning(const char *str, ...) throw(std::bad_alloc)
#ifdef __GNUC__
        __attribute__((format(printf, 2, 3)))
#endif
        ;

        /**
             \brief Equivalent to \ref log(LOGGER_ERROR, ...)
        */
        void error(const char *str, ...) throw(std::bad_alloc)
#ifdef __GNUC__
        __attribute__((format(printf, 2, 3)))
#endif
        ;

        /**
             \brief Equivalent to \ref log(LOGGER_FATAL, ...)
        */
        void fatal(const char *str, ...) throw(std::bad_alloc)
#ifdef __GNUC__
        __attribute__((format(printf, 2, 3)))
#endif
        ;

        /**
            \brief Output stream for logging message(s).
            
            Using std::endl will log what is currently in the buffer.
            When the stream is destroyed anything left in the buffer is logged.
            
            \param log_level The logging level for this stream.
            
            \return Output stream.
        */
        LoggerOutputStream log(const log_level_t &log_level);

        /**
            \brief Equivalent to \ref log(LOGGER_TRACE)

            \return Output stream.
        */
        LoggerOutputStream trace();
        
        /**
            \brief Equivalent to \ref log(LOGGER_DEBUG)

            \return Output stream.
        */
        LoggerOutputStream debug();
        
        /**
            \brief Equivalent to \ref log(LOGGER_INFO)

            \return Output stream.
        */
        LoggerOutputStream info();
        
        /**
            \brief Equivalent to \ref log(LOGGER_WARNING)

            \return Output stream.
        */
        LoggerOutputStream warning();
        
        /**
            \brief Equivalent to \ref log(LOGGER_ERROR)

            \return Output stream.
        */
        LoggerOutputStream error();
        
        /**
            \brief Equivalent to \ref log(LOGGER_FATAL)

            \return Output stream.
        */
        LoggerOutputStream fatal();

        /**
            \brief Sets a new buffer size.

            The default buffer size is 256 bytes.

            \param new_size  New size of the buffer, in bytes.  If 0, no new buffer will
                             be allocated until the next \ref log call.

            \throw std::bad_alloc  A new internal buffer could not be allocated
        */
        void set_buffer_size(unsigned int new_size) throw(std::bad_alloc);

        /**
            \brief Retrieves the current buffer size.

            \return Current buffer size.
        */
        unsigned int get_buffer_size() throw();

        const std::string name;   //!< Unique logger name

    private:
        friend class LoggerAllocator;

        static ItcUtil::NamedObjectCache< Logger > &get_log_cache();

        /**
            \brief Private constructor

            \param name  Unique name of the logger
        */
        Logger(const char *name);
        bool internal_has_target(Target *tgt, std::string id);
        TargetList internal_get_all_targets() throw();
        void internal_set_buffer_size(unsigned int new_size) throw(std::bad_alloc);
        void internal_set_level(log_level_t log_level);
        void internal_handle_log(log_level_t log_level, const char *msg, std::va_list &ap) throw(std::bad_alloc);
        void internal_log(log_level_t log_level, const char *logger_name, const char *str) throw(std::bad_alloc);
        void post_init();
        void add_child(Logger *child);
        void remove_child(Logger *child);

        TargetList targets;      //!< List of all attached targets
		boost::mutex mutex;      //!< Logging mutex
        log_level_t log_level;   //!< Current log level
        bool explicit_log_level; //!< Whether or not the log level has explicitly been set
        char *buff;              //!< Internal buffer for building log messages
        unsigned int buff_size;  //!< Current buffer size
        LoggerList children;     //!< List of child loggers
        Logger *parent;          //!< Parent logger
        bool requires_post_init; //!< Post init flag
    };
}

#endif /* ITC_LOGGER_LOGGER_HPP */
