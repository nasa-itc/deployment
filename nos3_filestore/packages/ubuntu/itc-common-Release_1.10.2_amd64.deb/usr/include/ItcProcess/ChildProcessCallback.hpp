/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_PROCESS_CHILD_PROCESS_CALLBACK_HPP
#define ITC_PROCESS_CHILD_PROCESS_CALLBACK_HPP

#include <boost/noncopyable.hpp>

namespace ItcProcess
{
    /**
        \brief User-implemented callback type

        Subclass this class to receive notification of your process terminating.
    */
    class DLL_PUBLIC ChildProcessCallback : private boost::noncopyable
    {
    public:
        /**
            \brief Notifies the user of a program's exit code
        */
        union ExitCode
        {
            int return_code;  //!< Return code, in the event of normal termination
            int signal;       //!< Signal, in the event of death by signal
        };

        /**
            \brief Empty constructor
        */
        ChildProcessCallback()
        {}

        /**
            \brief Empty destructor
        */
        virtual ~ChildProcessCallback()
        {}

        /**
            \brief Called when the subprocess terminates

            If \ref sig==true, then the program terminated due to being signaled.  The
            reason for using a union here is because:
                 1) signals are ANSI C and are ints
                 2) it assures the user has to tell the difference between a return
                      code and a signal

            Other callbacks need this thread! Do not block here.

            \param return_code  Return code from the subprocess
            \param sig          If true, the subprocess died by signal.  Otherwise
                                  the subprocess exited normally
        */
        virtual void terminated(ExitCode return_code, bool sig) throw() = 0;
    };
}

#endif /* ITC_PROCESS_CHILD_PROCESS_CALLBACK_HPP */
