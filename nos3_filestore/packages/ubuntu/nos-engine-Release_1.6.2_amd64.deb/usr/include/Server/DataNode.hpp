/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_DATA_NODE_HPP
#define NOS_ENGINE_SERVER_DATA_NODE_HPP

#include <vector>

#include <Common/Bus/BusProtocol.hpp>

#include <Server/Types.hpp>
#include <Server/IDataNode.hpp>
#include <Server/Node.hpp>

namespace NosEngine
{
    namespace Server
    {
        ///
        /// \copydoc IDataNode
        ///
        class NOS_ENGINE_SERVER_API_PUBLIC DataNode :
            public IDataNode,
            public Node 
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Instantiate a data node.
            ///
            /// \param name    name of the node
            /// \param id      unique node ID
            /// \param sender  send operator to send messages to the client-side node
            ///
            DataNode(const std::string& name, const Common::NodeID id, Common::WeakSendOperator sender);

        private:
            DataNode(const DataNode&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the DataNode class.
            /// 
            virtual ~DataNode();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            DataNode& operator=(const DataNode&); //!< Disable the copy assignment operator.
            
        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IDataNode implementation
            // ------------------------------------------------------------------------------------

            virtual Common::BusProtocol::NodeType get_type() const;

            virtual void add_interceptor(InterceptorNode* const to_add, const Common::BusProtocol::InterceptorDirection& direction);

            virtual void remove_interceptor(InterceptorNode* const to_remove, const Common::BusProtocol::InterceptorDirection& direction);

            virtual std::vector<Node*> get_outgoing_interceptors() const;

            virtual std::vector<Node*> get_incoming_interceptors() const;
            
        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            std::vector<InterceptorNode*> incoming_interceptors;
            std::vector<InterceptorNode*> outgoing_interceptors;
        };           
    }
}

#endif