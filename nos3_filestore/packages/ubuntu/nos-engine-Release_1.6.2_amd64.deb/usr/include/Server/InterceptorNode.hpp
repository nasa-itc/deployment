/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_INTERCEPTOR_NODE_HPP
#define NOS_ENGINE_SERVER_INTERCEPTOR_NODE_HPP

#include <Common/Bus/BusProtocol.hpp>

#include <Server/Types.hpp>
#include <Server/IInterceptorNode.hpp>
#include <Server/Node.hpp>

namespace NosEngine
{
    namespace Server
    {
        ///
        /// \copydoc IInterceptorNode
        ///
        class NOS_ENGINE_SERVER_API_PUBLIC InterceptorNode :
            public IInterceptorNode,
            public Node 
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Instantiate an interceptor node.
            ///
            /// \param name       name of the interceptor
            /// \param id         unique node ID
            /// \param target     name of target node
            /// \param direction  direction of interception (Outgoing or Incoming)
            /// \param sender     send operator to send messages to the client-side interceptor
            ///
            InterceptorNode(const std::string& name,
                            const Common::NodeID id,
                            const std::string& target,
                            Common::BusProtocol::InterceptorDirection direction,
                            Common::WeakSendOperator sender);

        private:
            InterceptorNode(const InterceptorNode&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the InterceptorNode class.
            /// 
            virtual ~InterceptorNode();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            InterceptorNode& operator=(const InterceptorNode&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IInterceptorNode implementation
            // ------------------------------------------------------------------------------------

            virtual Common::BusProtocol::NodeType get_type() const;

            virtual std::string get_target_name() const;

            virtual Common::BusProtocol::InterceptorDirection get_direction() const;
            
            virtual void add_filter(MessageFilterFunc to_add);

            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            const std::string target_node;                              //!< name of target node
            const Common::BusProtocol::InterceptorDirection direction;  //!< interception direction (Outgoing or Incoming)
        };           
    }
}

#endif
