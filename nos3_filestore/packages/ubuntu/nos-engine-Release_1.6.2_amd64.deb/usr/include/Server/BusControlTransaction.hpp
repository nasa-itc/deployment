/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_BUS_CONTROL_TRANSACTION_HPP
#define NOS_ENGINE_SERVER_BUS_CONTROL_TRANSACTION_HPP

#include <Server/Types.hpp>
#include <Common/Transaction.hpp>

namespace NosEngine
{
	namespace Server
	{
		class NOS_ENGINE_SERVER_API_PUBLIC BusControlTransaction :
            public Common::Transaction 
		{
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the BusControlTransaction class.
            /// 
            BusControlTransaction(Bus* bus_reference, Common::WeakSendOperator);

        private:
            BusControlTransaction(const BusControlTransaction&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the BusControlTransaction class.
            /// 
            virtual ~BusControlTransaction();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            BusControlTransaction& operator=(const BusControlTransaction&); //!< Disable the copy assignment operator.

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            virtual bool work_complete(bool result, const Common::Message& original, Common::Message result_message);

		private:
            ///
            /// \brief Handles DataNode registration control messages.
            ///
            /// \param message  The control message.
            /// \param response The response to the control message.
            ///
			void register_data_node(Common::Message& message, Common::Message& response);

            ///
            /// \brief Handles InterceptorNode registration control messages.
            ///
            /// \param message  The control message.
            /// \param response The response to the control message.
            ///
			void register_interceptor_node(Common::Message& message, Common::Message& response);

            ///
            /// \brief Handles TimeClient/TimeServer registration control messages.
            ///
            /// \param message  The control message.
            /// \param response The response to the control message.
            ///
            void register_time_node(Common::Message& message, Common::Message& response);

        protected:
            // ------------------------------------------------------------------------------------
            // Transaction implementation
            // ------------------------------------------------------------------------------------

            virtual Common::TransactionWorkResult work(std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

			Bus* const bus_reference;
			const Common::WeakSendOperator sender;
		};
	}
}

#endif