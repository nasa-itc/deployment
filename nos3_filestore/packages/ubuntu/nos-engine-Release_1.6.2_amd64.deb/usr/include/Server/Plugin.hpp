/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/
#ifndef NOS_ENGINE_SERVER_PLUGIN_HPP
#define NOS_ENGINE_SERVER_PLUGIN_HPP

#include <Server/Server.hpp>
#include <Server/Bus.hpp>
#include <Server/DataLogger.hpp>
#include <Server/PluginTypes.hpp>

#include <functional>

#define PLUGIN_LOAD_FUNCTION_NAME "PluginInit"

#define STD_FUNCTION(Name, returnVal, ...) typedef std::function<returnVal(__VA_ARGS__)> Name;
#define FUNCTION_POINTER(Name, returnVal, ...) typedef returnVal (*Name ##_C)(__VA_ARGS__);

#define PLUGIN_INIT_FUNCTION(Name, returnType, ...) \
    STD_FUNCTION(Name, returnType, __VA_ARGS__)\
    FUNCTION_POINTER(Name, returnType, __VA_ARGS__)

namespace NosEngine
{
	namespace Server
	{
        //typedef std::function<void(const NosEngine::Server::PluginConfigObject&)> PluginInitFunction;
        PLUGIN_INIT_FUNCTION(PluginInitFunction, void, const NosEngine::Server::PluginConfigObject&)
    }
}

#endif
