/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_STATES_CANCELABLE_HPP
#define NOS_ENGINE_UTILITY_STATES_CANCELABLE_HPP

#include <mutex>
#include <condition_variable>

#include <Utility/Types.hpp>
#include <Utility/States/ICancelable.hpp>
#include <Utility/Events/OnCanceling.hpp>
#include <Utility/Events/OnCanceled.hpp>

namespace NosEngine
{
    namespace Utility
    {
        namespace States
        {
            ///
            /// \copydoc ICancelable
            ///
            class NOS_ENGINE_UTILITY_API_PUBLIC Cancelable :
                public virtual ICancelable,
                public Events::OnCanceling<Cancelable>,
                public Events::OnCanceled<Cancelable>
            {
            public:
                // ================================================================================
                // Life cycle
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Destructor for an instance of the Cancelable class.
                /// 
                virtual ~Cancelable() {}

                // ================================================================================
                // Public API
                // --------------------------------------------------------------------------------

                // --------------------------------------------------------------------------------
                // ICancelable implementation
                // --------------------------------------------------------------------------------

                virtual void cancel();

            protected:
                // ================================================================================
                // Internal API
                // --------------------------------------------------------------------------------

                ///
                /// \copydoc cancel()
                /// 
                /// \see cancel()
                /// 
                /// \param lock A lock that has acquired a lock of get_cancelable_mutex().
                ///
                virtual void cancel(std::unique_lock<std::mutex> &lock);

                ///
                /// \brief Get the mutex to use for cancel related operations.
                /// 
                /// \return The mutex.
                ///
                virtual std::mutex &get_cancelable_mutex() const;

                ///
                /// \copydoc cancel()
                /// 
                /// \see cancel(std::unique_lock<std::mutex> &)
                /// 
                /// \param lock A lock that has acquired a lock of get_cancelable_mutex().
                ///
                virtual void process_cancel(std::unique_lock<std::mutex> &lock) = 0;
            };
        }
    }
}

#endif // NOS_ENGINE_UTILITY_STATES_CANCELABLE_HPP