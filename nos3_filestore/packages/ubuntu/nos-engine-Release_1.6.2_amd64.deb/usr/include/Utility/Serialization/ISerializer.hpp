/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_SERIALIZATION_ISERIALIZER_HPP
#define NOS_ENGINE_UTILITY_SERIALIZATION_ISERIALIZER_HPP

#include <Utility/Types.hpp>
#include <Utility/Serialization/ISerializable.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \brief Provides serialization capabilities for a buffer.
        ///
        class ISerializer
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the ISerializer class.
            /// 
            virtual ~ISerializer() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief serialize a boolean
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_bool(bool val) = 0;

            ///
            /// \brief serialize a character
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_char(char val) = 0;

            ///
            /// \brief serialize an 8-bit integer
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_int8(int8_t val) = 0;

            ///
            /// \brief serialize an 8-bit unsigned integer
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_uint8(uint8_t val) = 0;

            ///
            /// \brief serialize a 16-bit integer
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_int16(int16_t val) = 0;

            ///
            /// \brief serialize a 16-bit unsigned integer
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_uint16(uint16_t val) = 0;

            ///
            /// \brief serialize a 32-bit integer
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_int32(int32_t val) = 0;

            ///
            /// \brief serialize a 32-bit unsigned integer
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_uint32(uint32_t val) = 0;

            ///
            /// \brief serialize a 64-bit integer
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_int64(int64_t val) = 0;

            ///
            /// \brief serialize a 64-bit unsigned integer
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_uint64(uint64_t val) = 0;

            ///
            /// \brief serialize a float
            ///
            /// \param val value to serialize
            /// 
            /// \throw FormatStringFailed   failed to format the float into a string
            /// \throw BufferOverflow       there is not enough space left in the buffer
            ///
            virtual void serialize_float(float val) = 0;

            ///
            /// \brief serialize a double
            ///
            /// \param val value to serialize
            /// 
            /// \throw FormatStringFailed   failed to format the double into a string
            /// \throw BufferOverflow       there is not enough space left in the buffer
            ///
            virtual void serialize_double(double val) = 0;

            ///
            /// \brief serialize a string
            ///
            /// \param val value to serialize
            /// 
            /// \throw InvalidArgument  string length exceeds the maximum permitted or val is null
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_string(const char * const val) = 0;

            ///
            /// \brief serialize a string
            ///
            /// \param val value to serialize
            /// 
            /// \throw InvalidArgument  string length exceeds the maximum permitted
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_string(const std::string &val) = 0;

            ///
            /// \brief serialize raw data
            ///
            /// \param val       pointer to raw data to serialize
            /// \param val_size  length of data to serialize
            /// 
            /// \throw InvalidArgument  data length exceeds the maximum permitted or val is null
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_binary(const void * const val, size_t val_size) = 0;

            ///
            /// \brief serialize raw data
            ///
            /// \param val buffer containing raw data
            /// 
            /// \throw InvalidArgument  data length exceeds the maximum permitted or val is null
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_binary(const IBuffer &val) = 0;

            ///
            /// \brief serialize an object which implements ISerializable
            ///
            /// \param val object to serialize
            /// 
            /// \throw InvalidArgument  data length exceeds the maximum permitted
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize(const ISerializable &val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_bool(bool)
            ///
            /// \copydetails serialize_bool(bool)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(bool val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_char(char)
            ///
            /// \copydetails serialize_char(char)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(char val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_int8(int8_t)
            ///
            /// \copydetails serialize_int8(int8_t)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(int8_t val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_uint8(uint8_t)
            ///
            /// \copydetails serialize_uint8(uint8_t)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(uint8_t val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_int16(int16_t)
            ///
            /// \copydetails serialize_int16(int16_t)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(int16_t val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_uint16(uint16_t)
            ///
            /// \copydetails serialize_uint16(uint16_t)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(uint16_t val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_int32(int32_t)
            ///
            /// \copydetails serialize_int32(int32_t)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(int32_t val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_uint32(uint32_t)
            ///
            /// \copydetails serialize_uint32(uint32_t)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(uint32_t val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_int64(int64_t)
            ///
            /// \copydetails serialize_int64(int64_t)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(int64_t val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_uint64(uint64_t)
            ///
            /// \copydetails serialize_uint64(uint64_t)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(uint64_t val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_float(float)
            ///
            /// \copydetails serialize_float(float)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(float val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_double(double)
            ///
            /// \copydetails serialize_double(double)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(double val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_string(const char * const)
            ///
            /// \copydetails serialize_string(const char * const)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(const char * const val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_string(const std::string &)
            ///
            /// \copydetails serialize_string(const std::string &)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(const std::string &val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize_binary(const IBuffer &)
            ///
            /// \copydetails serialize_binary(const IBuffer &)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(const IBuffer &val) = 0;

            ///
            /// \brief Stream operator to \copybrief serialize(const ISerializable &)
            ///
            /// \copydetails serialize(const ISerializable &)
            ///
            /// \return reference to this ISerializer
            ///
            virtual ISerializer& operator<<(const ISerializable &val) = 0;

            ///
            /// \brief return a pointer to the buffer
            ///
            /// \return pointer to buffer
            ///
            virtual IBuffer *get_buffer() = 0;

            ///
            /// \brief Reset the internal buffer.
            ///
            /// This will reset the length of the buffer to zero. It does not overwrite or free any data (capacity remains the same).
            ///
            virtual void reset() = 0;
        };
    }
}

#endif // NOS_ENGINE_UTILITY_SERIALIZATION_ISERIALIZER_HPP