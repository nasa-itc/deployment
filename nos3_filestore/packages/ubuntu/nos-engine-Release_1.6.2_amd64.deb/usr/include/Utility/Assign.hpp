/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_ASSIGN_HPP
#define NOS_ENGINE_UTILITY_ASSIGN_HPP

#include <vector>
#include <list>
#include <map>
#include <functional>

namespace NosEngine
{
    namespace Utility
    {
        namespace Assign
        {
            template<class T1, class T2>
            class ListAssigner : public T1
            {
            public:
                // ================================================================================
                // Life cycle
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Construct an instance of the ListAssigner class.
                /// 
                /// \param value The first value to add to the list.
                /// 
                ListAssigner(const T2 &value);

                // ================================================================================
                // Operators
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Add a value to the list.
                /// 
                /// \param value The value to add to the list.
                /// 
                ListAssigner& operator()(const T2 &value);
            };

            template<class T1, class T2>
            class MapAssigner : public std::map<T1, T2>
            {
            public:
                // ================================================================================
                // Life cycle
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Construct an instance of the MapAssigner class.
                /// 
                /// \param key      The key for the first key-value-pair to add to the map.
                /// \param value    The value for the first key-value-pair to add to the map.
                /// 
                MapAssigner(const T1 &key, const T2 &value);

                // ================================================================================
                // Operators
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Add a key-value-pair to the map.
                /// 
                /// \param key      The key for the key-value-pair to add to the map.
                /// \param value    The value for the key-value-pair to add to the map.
                /// 
                MapAssigner& operator()(const T1 &key, const T2 &value);
            };

            /// 
            /// \brief Create a vector containing values of the specified type.
            /// 
            /// Example:
            /// \code
            /// std::vector<std::string> strings = vector_of<std::string>("A")("B")("C");
            /// \endcode
            /// 
            /// \return Assigner for adding additional values to the vector.
            /// 
            template<class T>
            static ListAssigner<std::vector<T>, T> vector_of(T value);
            
            /// 
            /// \brief Create a list containing values of the specified type.
            /// 
            /// Example:
            /// \code
            /// std::list<std::string> strings = list_of<std::string>("A")("B")("C");
            /// \endcode
            /// 
            /// \return Assigner for adding additional values to the list.
            /// 
            template<class T>
            static ListAssigner<std::list<T>, T> list_of(T value);
            
            /// 
            /// \brief Create a map containing key/value pairs of the specified types.
            /// 
            /// Example:
            /// \code
            /// std::map<int, std::string> int_to_string = map_of<int, std::string>(1, "A")(2, "B")(3, "C");
            /// \endcode
            /// 
            /// \return Assigner for adding additional key/value pairs to the map.
            /// 
            template<class T1, class T2>
            static MapAssigner<T1, T2> map_of(T1 key, T2 value);
        }
    }
}

#include <Utility/Assign.ipp>

#endif