/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_WORK_CHAIN_HPP
#define NOS_ENGINE_UTILITY_WORK_CHAIN_HPP

#include <functional>
#include <deque>
#include <thread>
#include <condition_variable>

#include <Utility/Types.hpp>
#include <Utility/Globals.hpp>
#include <Utility/IWorkChain.hpp>
#include <Utility/WorkChainWorkWrapper.hpp>
#include <Utility/Events/OnDestroy.hpp>
#include <Utility/Events/OnError.hpp>
#include <Utility/States/Pauseable.hpp>
#include <Utility/States/Cancelable.hpp>
#include <Utility/States/Stoppable.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \copydoc IWorkChain
        ///
        class NOS_ENGINE_UTILITY_API_PUBLIC WorkChain :
            public IWorkChain,
            public Events::OnDestroy,
            public Events::OnError<WorkChain>,
            public States::Pauseable,
            public States::Cancelable,
            public States::Stoppable
        {
        private:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            typedef std::deque<CancelableWork> WorkChainQueue;

            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the WorkChainWorkWrapper class.
            /// 
            /// \param work_hub The work hub which this chain is associated with.
            /// 
            WorkChain(IWorkHub &work_hub);

            WorkChain(const WorkChain &other);  //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the WorkChain class.
            /// 
            virtual ~WorkChain();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            WorkChain &operator=(const WorkChain &); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IWorkChain implementation
            // ------------------------------------------------------------------------------------

			virtual bool in_chain_thread() const;

			virtual void wait_for_callbacks(const Timeout &timeout = INFINITE_TIMEOUT);

			virtual void wait_for_callbacks(const TimeoutClock::time_point &timeout);

			virtual void wait_current_work(const Timeout &timeout = INFINITE_TIMEOUT);

			virtual void wait_current_work(const TimeoutClock::time_point &timeout);

            virtual void post_work(CancelableWork work);

            virtual void post_work(IWorkChainWorkWrapper &work);

            virtual void post_work(IWorkChainWorkWrapper &&work);

			virtual size_t get_work_queued_count() const;

			virtual size_t get_work_started_count() const;

			virtual size_t get_work_completed_count() const;

			virtual size_t get_work_queued_or_inprogress_count() const;

			virtual size_t get_callback_count() const;

			virtual size_t get_callback_completed_count() const;

			virtual bool is_waiting_on_callback() const;

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Post a work item to the work hub associated with the chain which executes
            /// the current work posted to the chain.
            ///
            /// The work item posted calls perform_work().
            /// 
            /// \param lock A lock of the appropriate mutex for posting work.
            /// 
            void post_queued_work(std::unique_lock<std::mutex> &lock);

            /// 
            /// \brief Executes the current work posted to the chain.
            /// 
            void perform_work();

            /// 
            /// \brief Wait for the work chain to change to a not working state (ie not executing
            /// work).
            /// 
            /// \param lock A lock of the appropriate mutex used for posting work.
            /// 
            void wait_for_not_working(std::unique_lock<std::mutex> &lock);

            /// 
            /// \copydoc wait_for_callbacks()
            /// 
            /// \param lock A lock of the appropriate mutex used for posting work.
            /// 
            void wait_for_callbacks(std::unique_lock<std::mutex> &lock);

            /// 
            /// \copydoc wait_for_callbacks(const bool &, const TimeoutClock::time_point &)
            /// 
            /// \param lock A lock of the appropriate mutex used for posting work.
            /// 
            void wait_for_callbacks(const bool &timeout,
                                    const TimeoutClock::time_point &timeout_time,
                                    std::unique_lock<std::mutex> &lock);

            /// 
            /// \copydoc wait_current_work()
            /// 
            /// \param lock A lock of the appropriate mutex used for posting work.
            /// 
            void wait_current_work(std::unique_lock<std::mutex> &lock);

            /// 
            /// \copydoc wait_current_work(const bool &, const TimeoutClock::time_point &)
            /// 
            /// \param lock A lock of the appropriate mutex used for posting work.
            /// 
			void wait_current_work(const bool &timeout,
                                   const TimeoutClock::time_point &timeout_time,
                                   std::unique_lock<std::mutex> &lock);

            ///
            /// \copydoc post_work(CancelableWork, const bool &)
            ///
            /// \param lock A lock of the appropriate mutex for posting work.
            ///
            /// \see post_work(CancelableWork, const bool &)
            ///
            void post_work(CancelableWork work, const bool &has_callback, std::unique_lock<std::mutex> &lock);

        protected:
            // ------------------------------------------------------------------------------------
            // IWorkChain implementation
            // ------------------------------------------------------------------------------------

            virtual void post_work(CancelableWork work, const bool &has_callback);
            virtual CallbackId pre_execute_work_with_callback();
            virtual void pre_execute_work_callback(const CallbackId &callback_id);
            virtual void post_execute_work_callback();

            // ------------------------------------------------------------------------------------
            // IWorkChain (IEngineThreadSafeObjectWithCV) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

            virtual std::condition_variable &get_cv() const;

            // ------------------------------------------------------------------------------------
            // Pauseable implementation
            // ------------------------------------------------------------------------------------

            virtual const bool &is_paused_no_lock() const;
            virtual void set_paused_no_lock(const bool &paused);
            virtual void process_pause(std::unique_lock<std::mutex> &lock, const bool &pause);

            // ------------------------------------------------------------------------------------
            // Cancelable implementation
            // ------------------------------------------------------------------------------------

            virtual void process_cancel(std::unique_lock<std::mutex> &lock);

            // ------------------------------------------------------------------------------------
            // Stoppable implementation
            // ------------------------------------------------------------------------------------

            virtual bool is_stopping_no_lock() const;

            virtual void set_stopping_no_lock(const bool &stopping);

            virtual bool is_stopped_no_lock() const;

            virtual void set_stopped_no_lock(const bool &stopped);

            virtual void process_stop(std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------
            
            // ---- work hub association ----
            IWorkHub &work_hub;

            // ---- thread syncronization ----
            mutable std::mutex mutex;
            mutable std::condition_variable cond;

            // ---- queue / queue processing ----
            WorkChainQueue work_chain;
            Work perform_work_func;

            // ---- counters ----
			size_t work_count;
            size_t work_complete_count;
            size_t callback_count;
            size_t callback_pending_count;

            // ---- status ----
			std::thread::id work_thread_id;
            bool working;
            bool waiting_on_callback;
            bool stopping;
            bool stopped;
            bool paused;

            // friend WorkHub because it is a factory for work chains so it needs access to
            // WorkChain constructors
            friend class WorkHub;
        };
    }
}

#endif