/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_TIMER_QUEUE_HPP
#define NOS_ENGINE_UTILITY_TIMER_QUEUE_HPP

#include <functional>
#include <chrono>
#include <mutex>

#include <Utility/Types.hpp>
#include <Utility/ITimerQueue.hpp>
#include <Utility/Globals.hpp>
#include <Utility/Events/OnError.hpp>
#include <Utility/States/Cancelable.hpp>
#include <Utility/States/Stoppable.hpp>

namespace NosEngine
{
    namespace Utility
    {
        /// 
        /// \copydoc ITimerQueue
        /// 
        class NOS_ENGINE_UTILITY_API_PUBLIC TimerQueue :
            public ITimerQueue,
            public Events::OnError<TimerQueue>,
            public States::Cancelable,
            public States::Stoppable
        {
        private:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            class TimerQueueImpl; //!< Represents private implementation of a TimerQueue.
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

        	/// 
        	/// \brief Construct and instance of the TimerQueue class.
        	/// 
            TimerQueue();

        private:
            TimerQueue(const TimerQueue &); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the TimerQueue class.
            /// 
            virtual ~TimerQueue();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            TimerQueue& operator=(const TimerQueue &); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // ITimerQueue implementation
            // ------------------------------------------------------------------------------------

            using States::Cancelable::cancel;
			
            virtual void cancel(const TimerId &id);
            
            virtual TimerId add(const std::chrono::nanoseconds delay, const TimerQueueCallback callback);

            virtual TimerId add(const std::chrono::microseconds delay, const TimerQueueCallback callback);

            virtual TimerId add(const std::chrono::milliseconds delay, const TimerQueueCallback callback);

            virtual TimerId add(const std::chrono::seconds delay, const TimerQueueCallback callback);

            virtual TimerId add(const std::chrono::minutes delay, const TimerQueueCallback callback);

            virtual TimerId add(const std::chrono::hours delay, const TimerQueueCallback callback);

            virtual TimerId add(const TimerQueueTimepoint time, const TimerQueueCallback callback);

        protected:
            // ============================================================================================
            // Internal API
            // --------------------------------------------------------------------------------------------

            // --------------------------------------------------------------------------------------------
            // ITimerQueue (IEngineThreadSafeObjectWithCV) implementation
            // --------------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

            virtual std::condition_variable &get_cv() const;

            // ------------------------------------------------------------------------------------
            // Cancelable implementation
            // ------------------------------------------------------------------------------------

            virtual void process_cancel(std::unique_lock<std::mutex> &lock);

            // ------------------------------------------------------------------------------------
            // Stoppable implementation
            // ------------------------------------------------------------------------------------

            virtual bool is_stopping_no_lock() const;

            virtual void set_stopping_no_lock(const bool &stopping);

            virtual bool is_stopped_no_lock() const;

            virtual void set_stopped_no_lock(const bool &stopped);

            virtual void process_stop(std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            TimerQueueImpl *pimpl; //!< Private implementation instance of a TimerQueue instance.
        };
    }
}

#endif // NOS_ENGINE_UTILITY_TIMER_QUEUE_HPP
