/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_BUFFER_OVERLAY_HPP
#define NOS_ENGINE_UTILITY_BUFFER_OVERLAY_HPP

#include <Utility/Types.hpp>
#include <Utility/Buffer.hpp>
#include <Utility/IBufferOverlay.hpp>
#include <Utility/ReadOnlyBufferOverlay.hpp>

namespace NosEngine
{
	namespace Utility
    {
        ///
        /// \copydoc IBufferOverlay
        ///
		class NOS_ENGINE_UTILITY_API_PUBLIC BufferOverlay :
            public IBufferOverlay
		{
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the BufferOverlay class.
            ///
            /// \param to_overlay The buffer which this is overlaying.
            /// 
			BufferOverlay(Utility::Buffer &to_overlay);

            /// 
            /// \brief Construct an instance of the BufferOverlay class.
            ///
            /// \param offset       Offset into the buffer which this overlays.
            /// \param to_overlay   The buffer which this is overlaying.
            /// 
            BufferOverlay(size_t offset, Utility::Buffer &to_overlay);

            ///
            /// \brief Copy constructor
            ///
            BufferOverlay(const BufferOverlay &other);

            ///
            /// \brief Move constructor
            ///
            BufferOverlay(BufferOverlay&& other);

        public:
            /// 
            /// \brief Destructor for an instance of the BufferOverlay class.
            /// 
            virtual ~BufferOverlay();

            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Copy assignment operator
            ///
            BufferOverlay& operator=(const BufferOverlay &other);

            ///
            /// \brief Move assignment operator
            ///
            BufferOverlay& operator=(BufferOverlay &&other);

            ///
            /// \brief Conversion operator to ReadOnlyBufferOverlay
            ///
            virtual operator ReadOnlyBufferOverlay() const;

        public:
            // ------------------------------------------------------------------------------------
            // IBufferOverlay implementation
            // ------------------------------------------------------------------------------------

            virtual bool operator==(const IBuffer &other) const;

            virtual bool operator!=(const IBuffer &other) const;

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IBufferOverlay implementation
            // ------------------------------------------------------------------------------------

            virtual void reset();

            virtual void clear(const bool &free = true);

            virtual size_t get_size() const;

            virtual void set_size(const size_t &new_size, bool clip = false, bool free = true);

            virtual size_t get_length() const;

            virtual void set_length(const size_t &new_len);

            virtual char *get_data() const;

            virtual void add(size_t add_len, const char *add_data);

            virtual void grow(size_t grow_size);

			virtual void append(size_t append_len, const char *append_data, size_t grow_size = 0);

			virtual void append(size_t offset, size_t append_len, const char *append_data, size_t grow_size = 0);

            virtual const std::string to_string(size_t offset = 0) const;

            NE_FORMAT_GUARD(2,0)
            virtual void vprintf(const char *fmt, va_list ap);
            
            NE_FORMAT_GUARD(2,3)
            virtual void printf(const char *fmt, ...);

            virtual const IBuffer *get_parent() const;

            virtual size_t get_offset() const;

			virtual void sync();

        public:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- attributes ----
            size_t size;    //!< the size of the window into the buffer (overlay size)
            size_t len;     //!< the length of the window into the buffer (overlay length)
            char* data;     //!< the data window (overlay data)

        private:
            // ---- attributes ----
            size_t base_offset;         //!< offset into buffer which this overlays
            Utility::Buffer* buffer;    //!< reference to the buffer which this overlays
		};
	}
}

#endif
