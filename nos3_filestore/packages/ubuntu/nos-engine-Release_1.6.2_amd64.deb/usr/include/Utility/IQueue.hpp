/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_IQUEUE_HPP
#define NOS_ENGINE_UTILITY_IQUEUE_HPP

#include <Utility/Types.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \brief A thread-safe, template-base first-in first-out (FIFO) queue.
        ///
        /// Managed items:
        /// - Queues manage items of arbitrary type - objects, structs, scalar values.
        /// - Items are stored by value in a list.
        ///
        /// Item ownership:
        /// - A Queue takes ownership of items pushed onto it.
        ///   + If items are present on the queue when it is destructed, they are destructed when the list
        ///     is destructed.
        ///   + If the items are raw pointers, the pointed-to objects /are not/ destructed.
        ///   + To ensure destruction with raw pointer-based queues, use std::unique_ptr instead of raw
        ///     pointers.
        ///
        template <class T>
        class IQueue : public virtual IEngineThreadSafeObjectWithCV
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IQueue class.
            /// 
            virtual ~IQueue() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Add an item to the tail of the queue.
            ///
            /// The queue takes over ownership of the item while it is in the queue.
            ///
            /// \param t Item to place on queue
            ///
            virtual void push(T t) = 0;

            ///
            /// \brief Add an item to the head of the queue.
            ///
            /// The queue takes over ownership of the item while it is in the queue.
            ///
            /// \note This operation bypasses the normal queue item ordering, and should only be used in
            /// special situations.
            ///
            /// \param t Item to place on queue
            ///
            virtual void push_front(T t) = 0;

            ///
            /// \brief Remove and return the item at the head of the queue.
            ///
            /// If the queue is empty, the method blocks until an item is available to return.
            ///
            /// \return pointer to item
            ///
            /// \throw Error::Shutdown Conditional wait interrupted due to shutdown
            ///
            virtual T pop() = 0;

            ///
            /// \brief Remove and return the item at the head of the queue, but do not block if the queue is
            /// empty.
            ///
            /// \return Pointer to item
            ///
            /// \throw Error::CollectionEmpty Queue is empty
            ///
            virtual T pop_nowait() = 0;

            ///
            /// \brief Get the number of items on the queue.
            ///
            virtual size_t length() = 0;

            ///
            /// \brief Clears all items from the queue.
            ///
            virtual void clear() = 0;

            ///
            /// \brief Shut down the queue. Interrupt any threads waiting on the queue.
            ///
            /// This call can be used to release any threads that are waiting for an item from the queue
            /// (pending on pop()). An Error::Shutdown exception will be raised on each waiting thread.
            ///
            virtual void shutdown() = 0;
        };
    }
}

#endif