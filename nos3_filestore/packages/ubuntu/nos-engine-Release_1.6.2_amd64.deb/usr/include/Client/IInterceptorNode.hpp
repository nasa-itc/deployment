/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_IINTERCEPTOR_NODE_HPP
#define NOS_ENGINE_CLIENT_IINTERCEPTOR_NODE_HPP

#include <string>

#include <Client/types.hpp>
#include <Client/INode.hpp>

namespace NosEngine
{
    namespace Client
    {
        ///
        /// \brief An interceptor node is capable of intercepting messages in-route.
        ///
        /// In NOS Engine, interception can be performed in one of two directions:
        ///     1) messages outgoing from a node, or
        ///     2) messages incoming to a node
        ///
        /// An interceptor can perform one of the following actions when a message
        /// is captured in-transit:
        ///     1) Pass:   Pass the original message as-is (no-op)
        ///     2) Block:  Discard the message, thus preventing the message from being sent/received
        ///     3) Modify: Alter the original message and pass on the modified content instead
        ///
        class IInterceptorNode :
            public virtual INode
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Destructor for an instance of the InterceptorNode class.
            ///
            virtual ~IInterceptorNode() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the name of the target node.
            ///
            /// \return The target node's name.
            ///
            virtual std::string get_target_name() const = 0;

            ///
            /// \brief Set the callback function for interception.
            ///
            /// This callback will be called whenever a message has been captured for the interceptor.
            ///
            /// \param function interceptor callback
            ///
            virtual void set_interceptor_function(const InterceptorFunction function) = 0;
                
            ///
            /// \brief Get the callback function for interception.
            ///
            /// \return The callback function for interception.
            ///
            virtual InterceptorFunction get_interceptor_function() const = 0;

            ///
            /// \brief Pass operation: allow the original message to propagate as normal
            ///
            /// \param original the original message
            ///
            virtual void send_pass_response(const Common::Message& original) const = 0;

            ///
            /// \brief Block operation: discard the message from the system
            ///
            /// \param original the original message
            ///
            virtual void send_block_response(const Common::Message& original) const = 0;

            ///
            /// \brief Modify operation: allow the message to propagate but with altered data
            ///
            /// \param original       the original message
            /// \param length         length of modified data
            /// \param modified_data  pointer to replacement data
            ///
            virtual void send_modified_response(const Common::Message& original, size_t length, const char * const modified_data) = 0;

            ///
            /// \brief Mimic operation: do not allow the message to propagate and send a "stand in" response message
            /// which is treated as the offical response
            ///
            /// The mimic operation can only be performed on request/reply messages
            /// The mimic operation can not be performed on a message which is already a response (ie target outgoing / source incoming interceptor)
            ///
            /// \param original       the original message
            /// \param length         length of mimic data
            /// \param mimic_data     pointer to mimic response data
            ///
            /// \throw runtime_error  the original message is not for a request/reply or is already a response
            ///
            virtual void send_mimic_response(const Common::Message& original, size_t length, const char * const mimic_data) = 0;
        };           
    }
}


#endif
