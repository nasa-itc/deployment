/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_QUERY_HPP
#define NOS_ENGINE_CLIENT_QUERY_HPP

#include <Transport/TransportHub.hpp>

#include <Common/Query/QueryProtocol.hpp>
#include <Common/IMessageConnection.hpp>

#include <Client/types.hpp>
#include <Client/Globals.hpp>
#include <Client/IQuery.hpp>

namespace NosEngine
{
    namespace Client
    {
        ///
        /// \copydoc IQuery
        ///
        class NOS_ENGINE_CLIENT_API_PUBLIC Query :
            public IQuery
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Instantiate a query object for performing management of the remote server.
            ///
            /// \param server_uri  Query URI
            ///
            Query(const std::string& server_uri,
                  const size_t num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);

            ///
            /// \brief Instantiate a query object for performing management of the remote server.
            ///
            /// \param server_uri  Query URI
            ///
            Query(Transport::TransportHub &transport_hub, const std::string& server_uri);

        private:
            Query(const Query&); //!< Disable the copy constructor.

        public:
            ///
            /// \brief Destructor for an instance of the Query class.
            ///
            virtual ~Query();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            Query& operator=(const Query&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            virtual std::vector<std::string> query_buses(
                const size_t timeout = SEND_INFINITE_TIMEOUT) const;

            virtual std::vector<Common::QueryProtocol::NodeInformation> query_data_nodes(
                const std::string& bus_name,
                const size_t timeout = SEND_INFINITE_TIMEOUT) const;
            
            virtual Common::Message query_protocol(
                const std::string& bus_name, Utility::Buffer query,
                const size_t timeout = SEND_INFINITE_TIMEOUT) const;
                
        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            void init();

            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- configuration ----
            Transport::TransportHub *transport_hub;
            bool owns_transport_hub;
            std::string server_uri;

            // ---- transport ----
            std::shared_ptr<Common::IMessageConnection> message_connection;
            std::shared_ptr<Common::ISendOperator> sender;
            Common::ReceiveOperator* receiver;

            // ---- transactions ----
            Common::ITransactionManager* manager;

            // ---- message routing ----
            Common::IMessageRouter* router;
        };
    }
}

#endif
