/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CAN_C_INTERFACE
#define NOS_ENGINE_CAN_C_INTERFACE

#include <Can/visibility.hpp>
#include <stdint.h>
#include <stddef.h>

#include <Client/CInterface.h>

/*
 * \brief Invalid CAN identifier representation
*/
#define CAN_INVALID_IDENTIFIER UINT32_MAX

/*
 * \brief Opaque CAN device handle
 */
#ifdef __cplusplus
    #include <Can/Client/CanDevice.hpp>
    typedef NosEngine::Can::CanDevice NE_CanHandle;
#else
    typedef struct NE_CanHandle NE_CanHandle;
#endif

#ifdef __cplusplus
extern "C"
{
#endif

/*
 * \brief CAN status codes
 */
typedef enum
{
    NE_CAN_SUCCESS = 0,
    NE_CAN_FAILURE
} NE_CanStatus;

/*
 * \brief CAN transaction direction
 */
typedef enum
{
    NE_CAN_WRITE = 0,
    NE_CAN_READ
} NE_CanDirection;

/*
 * \brief CAN device data callback function
 *
 * The CAN slave device is responsible for checking the transaction direction and
 * taking the appropriate action with the buffer and returning the number of bytes
 * read/written.
 */
typedef size_t(*NE_CanDataCallback)(NE_CanDirection dir, uint8_t *buf, size_t len);

/*
 * \brief Initialize CAN master device on the named bus
 *
 * \param identifier CAN device base identifier
 * \param connection NOS connection string
 * \param bus CAN bus name
 *
 * \return CAN device handle or NULL on error
 */
extern NOS_ENGINE_CAN_API_PUBLIC
NE_CanHandle* NE_can_init_master(uint32_t identifier, const char *connection, const char *bus);

/*
 * \brief Initialize CAN master device on the named bus
 *
 * \param identifier CAN device base identifier
 * \param connection NOS connection string
 * \param bus CAN bus name
 * \param num_service_threads The number of service threads that should be created
 *
 * \return CAN device handle or NULL on error
 */
extern NOS_ENGINE_CAN_API_PUBLIC
NE_CanHandle* NE_can_init_master2(uint32_t identifier, const char *connection, const char *bus, const size_t num_service_threads);

/*
 * \brief Initialize CAN master device on the named bus
 *
 * \param transport_hub Existing transport hub to use
 * \param identifier CAN device base identifier
 * \param connection NOS connection string
 * \param bus CAN bus name
 *
 * \return CAN device handle or NULL on error
 */
extern NOS_ENGINE_CAN_API_PUBLIC
NE_CanHandle* NE_can_init_master3(NE_TransportHub *transport_hub, uint32_t identifier, const char *connection, const char *bus);

/*
 * \brief Initialize CAN slave device on the named bus
 *
 * \param identifier CAN device base identifier
 * \param connection NOS connection string
 * \param bus CAN bus name
 * \param cb CAN transaction callback
 *
 * \return CAN device handle or NULL on error
 */
extern NOS_ENGINE_CAN_API_PUBLIC
NE_CanHandle* NE_can_init_slave(uint32_t identifier, const char *connection, const char *bus, NE_CanDataCallback cb);

/*
 * \brief Initialize CAN slave device on the named bus
 *
 * \param identifier CAN device base identifier
 * \param connection NOS connection string
 * \param bus CAN bus name
 * \param cb CAN transaction callback
 * \param num_service_threads The number of service threads that should be created
 *
 * \return CAN device handle or NULL on error
 */
extern NOS_ENGINE_CAN_API_PUBLIC
NE_CanHandle* NE_can_init_slave2(uint32_t identifier, const char *connection, const char *bus, NE_CanDataCallback cb, const size_t num_service_threads);

/*
 * \brief Initialize CAN slave device on the named bus
 *
 * \param transport_hub Existing transport hub to use
 * \param identifier CAN device base identifier
 * \param connection NOS connection string
 * \param bus CAN bus name
 * \param cb CAN transaction callback
 *
 * \return CAN device handle or NULL on error
 */
extern NOS_ENGINE_CAN_API_PUBLIC
NE_CanHandle* NE_can_init_slave3(NE_TransportHub *transport_hub, uint32_t identifier, const char *connection, const char *bus, NE_CanDataCallback cb);

/**
 * \brief Get the transport hub of the CAN device.
 * 
 * If the device owns the hub (ie hub was not provided to the init function) then use
 * the hub returned with caution.  When this device is closed the hub it owns
 * will be destroyed as well.
 * 
 * \return The tranport hub of the CAN device.
*/
extern NOS_ENGINE_CAN_API_PUBLIC
NE_TransportHub* NE_can_get_transport_hub(NE_CanHandle *can);

/*
 * \brief Close CAN device handle
 *
 * \param can CAN device handle
 */
extern NOS_ENGINE_CAN_API_PUBLIC
void NE_can_close(NE_CanHandle **can);

/*
 * \brief Get CAN device identifier
 *
 * \param can CAN device handle
 *
 * \return CAN device identifier or CAN_INVALID_IDENTIFIER on error
 */
extern NOS_ENGINE_CAN_API_PUBLIC
uint32_t NE_can_get_identifier(NE_CanHandle *can);
 
/*
 * \brief CAN master read
 *
 * \param can CAN device handle
 * \param identifier CAN slave device base identifier
 * \param rbuf Read data buffer
 * \param rlen Read data buffer length
 *
 * \return Status code
 */
extern NOS_ENGINE_CAN_API_PUBLIC
NE_CanStatus NE_can_read(NE_CanHandle *can, uint32_t identifier, uint8_t *rbuf, size_t rlen);
 
/*
 * \brief CAN master write
 *
 * \param can CAN device handle
 * \param identifier CAN slave device base identifier
 * \param wbuf Write data buffer
 * \param wlen Write data buffer length
 *
 * \return Status code
 */
extern NOS_ENGINE_CAN_API_PUBLIC
NE_CanStatus NE_can_write(NE_CanHandle *can, uint32_t identifier, const uint8_t *wbuf, size_t wlen);
 
/*
 * \brief CAN master transaction (write/read operation)
 *
 * \param can CAN device handle
 * \param identifier CAN slave device base identifier
 * \param wbuf Write data buffer
 * \param wlen Write data buffer length
 * \param rbuf Read data buffer
 * \param rlen Read data buffer length
 *
 * \return Status code
 */
extern NOS_ENGINE_CAN_API_PUBLIC
NE_CanStatus NE_can_transaction(NE_CanHandle *can, uint32_t identifier, const uint8_t *wbuf, size_t wlen, uint8_t* rbuf, size_t rlen);

#ifdef __cplusplus
}
#endif

#endif

