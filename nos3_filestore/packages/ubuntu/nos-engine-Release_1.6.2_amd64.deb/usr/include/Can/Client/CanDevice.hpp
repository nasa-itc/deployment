/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CAN_DEVICE_HPP
#define NOS_ENGINE_CAN_DEVICE_HPP

#include <Can/visibility.hpp>
#include <Can/Types.hpp>
#include <Client/Bus.hpp>
#include <Client/DataNode.hpp>
#include <Transport/TransportHub.hpp>
#include <string>

namespace NosEngine
{
    namespace Can
    {
        /*
         * \brief Base CAN device
         *
         * This CAN device base class provides common NOS engine connection code and is not meant
         * to be used directly.
         */
        class NOS_ENGINE_CAN_API_PUBLIC CanDevice
        {
        public:
            /*
             * \brief Create CAN device on the named bus
             *
             * \param mode CAN device mode
             * \param identifier CAN base identifier
             * \param connection NOS connection string
             * \param bus CAN bus name
             * \param num_service_threads The number of service threads that should be created
             */
            CanDevice(
                Mode mode,
                CanIdentifier identifier,
                const std::string& connection,
                const std::string& bus = "can",
                const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);
            
            /*
             * \brief Create CAN device on the named bus
             *
             * \param transport_hub Existing transport hub to use
             * \param mode CAN device mode
             * \param identifier CAN base identifier
             * \param connection NOS connection string
             * \param bus CAN bus name
             */
            CanDevice(
                Transport::TransportHub &transport_hub,
                Mode mode,
                CanIdentifier identifier,
                const std::string& connection,
                const std::string& bus = "can");

            /*
             * \brief Destructor
             */
            virtual ~CanDevice();

            /**
             * \brief Get the transport hub used by this instance.
             * 
             * If the instance owns the hub (ie hub was not provided to the constructor) then use
             * the hub returned with caution.  When this instance is destroyed the hub it owns
             * will be destroyed as well.
             * 
             * \return The tranport hub of this instance.
             */
            Transport::TransportHub &get_transport_hub() const;

            /*
             * \brief Get CAN device mode
             *
             * \return CAN device mode
             */
            Mode get_mode() const;

            /*
             * \brief Get CAN device base identifier
             *
             * \return CAN device base identifier
             */
            CanIdentifier get_identifier() const;

        protected:
            Client::Bus bus; //!< NOS engine CAN bus
            Client::DataNode *node; //!< NOS engine CAN data node
            Mode mode; //!< CAN device mode
            CanIdentifier identifier; //!< CAN device base identifier

        private:
            void init();
        };
    }
}

#endif

