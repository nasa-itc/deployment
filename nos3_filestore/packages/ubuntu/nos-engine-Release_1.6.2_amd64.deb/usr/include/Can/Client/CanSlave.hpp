/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CAN_SLAVE_HPP
#define NOS_ENGINE_CAN_SLAVE_HPP

#include <Can/visibility.hpp>
#include <Can/Client/CanDevice.hpp>
#include <Can/Types.hpp>
#include <cstdint>
#include <string>

namespace NosEngine
{
    namespace Common
    {
        class Message;
    }

    namespace Can
    {
        /*
         * \brief Abstract client side CAN slave device
         *
         */
        class NOS_ENGINE_CAN_API_PUBLIC CanSlave : public CanDevice
        {
        public:
            /*
             * \brief Create CAN slave device on the named bus
             *
             * \param identifier CAN slave device base identifier
             * \param connection NOS connection string
             * \param bus CAN bus name
             * \param num_service_threads The number of service threads that should be created
             */
            CanSlave(
                CanIdentifier identifier,
                const std::string& connection,
                const std::string& bus = "can",
                const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);
            
            /*
             * \brief Create CAN slave device on the named bus
             *
             * \param transport_hub Existing transport hub to use
             * \param identifier CAN slave device base identifier
             * \param connection NOS connection string
             * \param bus CAN bus name
             */
            CanSlave(
                Transport::TransportHub &transport_hub,
                CanIdentifier identifier,
                const std::string& connection,
                const std::string& bus = "can");

            /*
             * \brief Destructor
             */
            virtual ~CanSlave();

            /*
             * \brief CAN master read
             *
             * \param rbuf Read data buffer
             * \param rlen Read data buffer length
             *
             * \return Number of bytes read
             */
            virtual size_t can_read(uint8_t* rbuf, size_t rlen) = 0;

            /*
             * \brief CAN master write
             *
             * \param wbuf Write data buffer
             * \param wlen Write data buffer length
             *
             * \return Number of bytes written
             */
            virtual size_t can_write(const uint8_t *wbuf, size_t wlen) = 0;

        private:
            void init();

            /*
             * \brief On new message callback
             *
             * \param message New received message
             */
            void on_message(const Common::Message& message);
        };
    }
}

#endif

