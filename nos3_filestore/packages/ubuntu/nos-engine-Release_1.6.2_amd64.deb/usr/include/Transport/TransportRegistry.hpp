/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_REGISTRY_HPP
#define NOS_ENGINE_TRANSPORT_REGISTRY_HPP

#include <string>
#include <map>

#include <Utility/IWorkHub.hpp>

#include <Transport/Types.hpp>
#include <Transport/ITransportRegistry.hpp>
#include <Transport/ITransportRegistration.hpp>
#include <Transport/Acceptor.hpp>
#include <Transport/Connector.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \copydoc ITransportRegistry
        ///
        /// \note This class is a Singleton.
        ///
        class NOS_ENGINE_TRANSPORT_API_PUBLIC TransportRegistry :
            public ITransportRegistry
        {
        private:
            typedef std::map<std::string, ITransportRegistration*> SchemeToRegistration;

        protected:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct and instance of the TransportRegistry class.
            /// 
            TransportRegistry();

        private:
            TransportRegistry(const TransportRegistry&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the TransportRegistry class.
            /// 
            virtual ~TransportRegistry();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            TransportRegistry& operator=(const TransportRegistry&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // ITransportRegistry implementation
            // ------------------------------------------------------------------------------------

            static TransportRegistry &get();

            void add(const std::string &scheme, ITransportRegistration &registration);

            void remove(const std::string &scheme);

            virtual ITransportRegistration &get_registration(const std::string &scheme) const;

            virtual Acceptor *make_acceptor(const URI &uri, Utility::IWorkHub &work_hub) const;

            virtual Connector *make_connector(const URI &uri, Utility::IWorkHub &work_hub) const;

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \copydoc get_registration(const std::string &) const
            ///
            /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
            ///
            ITransportRegistration &get_registration_nolock(const std::string &scheme) const;

        protected:
            // ------------------------------------------------------------------------------------
            // ITransportRegistry (IEngineThreadSafeObject) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- thread syncronization ----
            static std::mutex mutex;
            mutable std::mutex registration_mutex;

            // ---- collections ----
            SchemeToRegistration registrations; //!< Collection which maps a scheme to a transport registration
        };
    }
}

#endif

