/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_EVENTS_ION_DISCONNECTED_HPP
#define NOS_ENGINE_TRANSPORT_EVENTS_ION_DISCONNECTED_HPP

#include <functional>
#include <Transport/Types.hpp>

namespace NosEngine
{
    namespace Transport
    {
        namespace Events
        {
            ///
            /// \brief Represents a class that has a list of on disconnected callbacks which are
            /// executed when the transport classes disconnects.
            ///
            class IOnDisconnected
            {
            public:
                // ================================================================================
                // Types
                // --------------------------------------------------------------------------------

                typedef std::function<void()> OnDisconnectedCallback;

                // ================================================================================
                // Life cycle
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Destructor for an instance of the IOnDisconnected class.
                /// 
                virtual ~IOnDisconnected() {}

                // ================================================================================
                // Public API
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Add an on disconnected callback.
                /// 
                /// \param callback The callback to add.
                /// \param removeable A value indicating if the callback can be removed from the list
                /// by calls to remove_on_disconnected_callback(CallbackId).
                /// 
                /// \return The id of the callback.
                /// 
                virtual Utility::CallbackId add_on_disconnected_callback(OnDisconnectedCallback callback, const bool &removable = true) = 0;

                /// 
                /// \brief Remove an on disconnected callback.
                /// 
                /// \param id The id of the callback to remove.
                ///
                virtual void remove_on_disconnected_callback(const Utility::CallbackId &id) = 0;
            };
        }
    }
}

#endif // NOS_ENGINE_TRANSPORT_EVENTS_ION_DISCONNECTED_HPP