/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_ITRANSACTION_HPP
#define NOS_ENGINE_COMMON_ITRANSACTION_HPP

#include <Common/types.hpp>
#include <Common/Message.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \brief Result values that can be returned by a Transaction process_message/work call.
        ///
        enum class TransactionWorkResult
        {
            TRANSACTION_STATUS_START = 0,
            Pending,                        //!< Initial status
            InProgress,                     //!< Transaction's work is not finished
            Completed,                      //!< Transaction's work is completed and the transaction should be deleted/removed
            CompletedAndRemoved,            //!< Transaction's work is completed and the transaction should be deleted (but has already been removed)
            CompletedDoNotDelete,           //!< Transaction's work is completed and the transaction should be removed (but should not be deleted)
            TRANSACTION_STATUS_END
        };

        ///
        /// \brief Values that represent the state of a Transaction.
        ///
        enum class TransactionState
        {
            TRANSACTION_STATE_START = 0,
            InActive,                       //!< The transaction is not performing any work and is not queued
            Queued,                         //!< The transaction has been queued, by a transaction manager, to perform work
            Active,                         //!< The transaction is currently performing work
            Completed,                      //!< The transaction has completed all work
            CompletedDoNotDelete,           //!< The transaction has completed and the manager should not delete it
            Canceled,                       //!< The transaction was canceled before it could complete all work
            TRANSACTION_STATE_END
        };

        ///
        /// \brief A class that abstracts the processing of messages related to
        /// any type of transaction.
        ///
        /// NOS Engine supports many types of operations: bus/node registration,
        /// multiple types of send operations, query operations, etc. The processing
        /// for any one of these operations is contained in a Transaction. This design 
        /// cleanly separates logic for different types of operations, thus avoiding
        /// monolithic functions.
        ///
        /// All messages that pertain to a particular transaction (i.e., operation) will carry 
        /// the same Transaction ID. Incoming messages will be passed to the appropriate
        /// transaction for handling.
        ///
        class NOS_ENGINE_COMMON_API_PUBLIC ITransaction :
            public virtual Utility::IEngineThreadSafeObjectWithCV
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the ITransaction class.
            /// 
            virtual ~ITransaction() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Call to notify the transaction that a node was removed.
            ///
            /// \param node The node that was removed.
            ///
            virtual void node_removed(INode* node) = 0;

            ///
            /// \brief Set the message to be processed.
            ///
            /// \param to_process The message to process.
            ///
            virtual void set_message(Message &to_process) = 0;
                
            ///
            /// \brief Set the message to be processed.
            ///
            /// \param to_process The message to process.
            ///
            virtual void set_message(Message &&to_process) = 0;

            ///
            /// \brief Processes the current message.
            ///
            virtual TransactionWorkResult process_message() = 0;

            ///
            /// \brief Get a value indicating if the tranaction is done.
            ///
            /// The transaction is considered done if the state is Completed or Canceled.
            ///
            /// \return A value indicating if the tranaction is done.
            ///
            virtual bool is_done() const = 0;

            ///
            /// \brief Get the current state of the transaction.
            ///
            /// \return The current state.
            ///
            virtual TransactionState get_state() const = 0;

            ///
            /// \brief Wait for the transaction to be done.
            ///
            /// \param timeout An amount of time (in milliseconds) to wait (0 to wait forever).
            ///
            /// \return true if timeout was not hit.
            ///
            virtual bool wait(const Utility::Timeout &timeout = 0) = 0;

            ///
            /// \brief Wait for the transaction to be inactive.
            ///
            /// \param timeout An amount of time (in milliseconds) to wait (0 to wait forever).
            ///
            /// \return true if timeout was not hit.
            ///
            virtual bool wait_for_inactive(const Utility::Timeout &timeout = 0) = 0;

            ///
            /// \brief Wait for the transaction to transition to a desired state.
            /// 
            /// \param state The desired state.
            /// \param timeout An amount of time (in milliseconds) to wait (0 to wait forever).
            ///
            /// \return true if timeout was not hit.
            ///
            virtual bool wait_for_state(const TransactionState &state, const Utility::Timeout &timeout = 0) = 0;

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Set the current state of the transaction.
            ///
            /// \param state The current state.
            ///
            virtual void set_state(const TransactionState &state) = 0;

            friend class TransactionManager;
        };           
    }
}

#endif