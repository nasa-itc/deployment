/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_IMESSAGE_CONNECTION_HPP
#define NOS_ENGINE_COMMON_IMESSAGE_CONNECTION_HPP

#include <memory>

#include <Utility/States/IStoppable.hpp>

#include <Transport/Events/IOnDisconnected.hpp>

#include <Common/types.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \brief Represents a connection between a client and server that is used to send/receive
        /// Message objects.
        ///
        /// \see Transport::Connection
        ///
        class IMessageConnection :
            public virtual Utility::IEngineThreadSafeObjectWithCV,
            public virtual Transport::Events::IOnDisconnected,
            public virtual Utility::States::IStoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IMessageConnection class.
            /// 
            virtual ~IMessageConnection() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief For derived classes which must derive from
            /// enable_shared_from_this<IMessageConnection>.
            ///
            virtual std::shared_ptr<IMessageConnection> get_shared_ptr() = 0;

            ///
            /// \brief Get a value indicating if the connection is still established.
            ///
            /// \return true if the connection is still established.
            ///
            virtual bool is_connected() = 0;

            /// 
            /// \brief Get the transport ID.
            ///
            /// \return The ID.
            ///
            virtual TransportID get_id() const = 0;

            /// 
            /// \brief Get the logical transport ID.
            ///
            /// \return The logical ID.
            ///
            virtual TransportID get_logical_id() const = 0;

            /// 
            /// \brief Get the underlying transport connection.
            ///
            /// \return The connection.
            ///
            virtual Transport::Connection *get_connection() const = 0;

            /// 
            /// \brief Get the URI for this end of the connection.
            ///
            /// \return The URI.
            ///
            virtual const std::string &get_local_uri() const = 0;

            /// 
            /// \brief Get the URI for the other end of the connection.
            ///
            /// \return The URI.
            ///
            virtual const std::string &get_remote_uri() const = 0;

            ///
            /// \brief Syncronously (blocking) send a message.
            ///
            /// \param message The message to send.
            ///
            /// \return An error code for the send.
            ///
            virtual void send_message_blocking(Message message) = 0;

            ///
            /// \brief Asyncronously (non-blocking) send a message.
            ///
            /// \param message The message to send.
            /// \param callback The callback to execute when the send operation is completed
            /// (or an error occurs).
            ///
            virtual void send_message_async(Message message, Transport::SendCallback callback) = 0;

            ///
            /// \brief Syncronously (blocking) receive a message.
            ///
            /// \return The message that was received.
            ///
            virtual Message receive_message_blocking() = 0;

            ///
            /// \brief Asyncronously (non-blocking) receive a message.
            ///
            /// \param callback The callback to execute when a message is received
            /// (or an error occurs).
            ///
            virtual void receive_message_async(ReceiveMessageCallback callback) = 0;
        };
    }
}

#endif

