/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_SEND_OPERATOR_HPP
#define NOS_ENGINE_COMMON_SEND_OPERATOR_HPP

#include <thread>
#include <mutex>
#include <atomic>

#include <Utility/Queue.hpp>

#include <Common/types.hpp>
#include <Common/ISendOperator.hpp>
#include <Common/IMessageConnection.hpp>
#include <Utility/States/Stoppable.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \copydoc ISendOperator
        ///
        class NOS_ENGINE_COMMON_API_PUBLIC SendOperator :
            public ISendOperator,
            public Utility::States::Stoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the SendOperator class.
            ///
            /// \param message_connection  Message connection where messages will be sent.
            ///
			SendOperator(std::shared_ptr<IMessageConnection> message_connection);
            
        private:
            SendOperator(const SendOperator&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the SendOperator class.
            /// 
            virtual ~SendOperator();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            SendOperator& operator=(const SendOperator&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // ISendOperator implementation
            // ------------------------------------------------------------------------------------

            virtual TransportID get_transport_id() const;

            virtual size_t get_send_count() const;

            virtual size_t get_send_completed_count() const;

            virtual void send_message(Message message);

            virtual TransactionID send_message_with_id(Message message);

            virtual TransactionID send_message(Message message, ITransaction* to_add, ITransactionManager& manager);

            virtual TransactionID process_transaction(Message message, ITransaction* to_process, ITransactionManager& manager);

            // --------------------------------------------------------------------------------
            // IOnDisconnected implementation
            // --------------------------------------------------------------------------------

            virtual Utility::CallbackId add_on_disconnected_callback(OnDisconnectedCallback callback, const bool &removable = true);

            virtual void remove_on_disconnected_callback(const Utility::CallbackId &id);

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief A hook that is called directly before the message is sent out on the message connection.
            ///
            /// Default implementation is a no-op, but can be overriden in a derived class.
            ///
            virtual void pre_send_message_hook(const Message& msg);

            ///
            /// \brief A hook that is called directly after the message is sent out on the message connection (if the send succeeded).
            ///
            /// Default implementation is a no-op, but can be overriden in a derived class.
            ///
            virtual void post_send_message_hook(bool send_succeeded);

        private:
            ///
            /// \brief Get the next transaction ID to use for sending a message and/or processing
            /// a transaction.
            ///
            /// \return The transaction ID.
            ///
			TransactionID get_next_id();

            ///
            /// \brief Common send method called by public send methods.
            ///
            /// \param message The message to send.
            ///
			void inner_send(Message message);

            ///
            /// \brief Callback method that is executed when a message is sent or an error
            /// occurs during a sending.
            ///
            /// \param error An error which occured during sending (or success error).
            ///
            void post_send_message(const Utility::Error::Error &error);

        protected:
            // ------------------------------------------------------------------------------------
            // ISendOperator (IEngineThreadSafeObjectWithCV) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

            virtual std::condition_variable &get_cv() const;

            // ------------------------------------------------------------------------------------
            // Stoppable implementation
            // ------------------------------------------------------------------------------------

            virtual bool is_stopping_no_lock() const;

            virtual void set_stopping_no_lock(const bool &stopping);

            virtual bool is_stopped_no_lock() const;

            virtual void set_stopped_no_lock(const bool &stopped);

            ///
            /// \copydoc ISendOperator::process_stop(std::unique_lock<std::mutex> &)
            ///
            /// \note Derived classes should call stop() in their destructor if they implment the
            /// pre/post send message hook methods.
            ///
            virtual void process_stop(std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- thread syncronization ----
            mutable std::mutex mutex;
            mutable std::condition_variable cond;

            // ---- configuration ----
            std::shared_ptr<IMessageConnection> message_connection; //!< connection where messages will be sent

            // ---- callbacks ----
            Transport::SendCallback send_callback;                  //!< \see post_send_message(const Utility::Error::Error &)

            // ---- counters ----
            std::atomic<TransactionCount> counter;                  //!< used to generate transaction IDs
            size_t send_count;                                      //!< number of send operations initiated
            size_t send_complete_count;                             //!< number of send operations completed

            // ---- status ----
            bool stopping;                                          //!< value indicating if this operator is stopping
            bool stopped;                                           //!< value indicating if this operator is stopped
        };
    }
}

#endif
