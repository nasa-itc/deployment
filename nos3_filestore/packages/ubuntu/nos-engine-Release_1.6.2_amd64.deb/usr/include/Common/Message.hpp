/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_MESSAGE_HPP
#define NOS_ENGINE_COMMON_MESSAGE_HPP

#include <Utility/Buffer.hpp>
#include <Utility/Serializer.hpp>

#include <Common/types.hpp>
#include <Common/Globals.hpp>
#include <Common/IMessage.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \copydoc IMessage
        ///
        class NOS_ENGINE_COMMON_API_PUBLIC Message :
            public IMessage
        {
		public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Instantiates a message with default field values.
            ///
            /// \param transaction_id  Transaction ID to assign to message (optional)
            /// \param buffer_size     Size of message buffer (optional)
            ///
			Message(const TransactionID transaction_id = INVALID_TRANSACTION_ID, const size_t buffer_size = DEFAULT_BUFFER_SIZE);

        private:
            Message(const Message&); //!< Disable the copy constructor.

        public:
            ///
            /// \brief Move constructor.
            ///
            /// The newly constructed Message takes the values from the other Message.
            /// When the call is complete, the other Message is modified but still technically valid.
            ///
            Message(Message&& other);

            /// 
            /// \brief Destructor for an instance of the Message class.
            /// 
            ~Message();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            Message &operator=(const Message&); //!< Disable the copy assignment operator.

        public:
            ///
            /// \brief Move assignment operator.
            ///
			Message& operator=(Message&& other);

            ///
            /// \brief Compares against another message to see if they have equal fields.d
            ///
            /// This comparison will return true if *this == other, or if *this != other but the fields
            /// all match.
            ///
            /// \param other Reference to Message to compare against.
            ///
            /// \return false if Messages have different values for any field
            /// \return true if Messages have same values for all fields
            ///
            bool operator==(const Message& other) const;

            ///
            /// \brief The not-equals version of comparison operator. see Message::operator==(const Message&) const
            ///
            bool operator!=(const Message& other) const;

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

			Message clone() const;

            // ------------------------------------------------------------------------------------
            // IMessage implementation
            // ------------------------------------------------------------------------------------

            virtual TransactionID get_transaction_id() const;

            virtual void set_transaction_id(const TransactionID id);

            virtual size_t get_serialized_size() const;

            virtual Utility::Buffer serialize() const;

            virtual void serialize(Utility::Buffer *message_buffer) const;

            virtual void deserialize(const Utility::Buffer * const message_buffer, const Utility::Endian::Endian local_endian, const Utility::Endian::Endian remote_endian);

            static Message deserialize_from(const Utility::Buffer *const message_buffer, const Utility::Endian::Endian local_endian, const Utility::Endian::Endian remote_endian);

            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            static const size_t DEFAULT_BUFFER_SIZE;

			std::string destination;   //!< Destination of the Message
			std::string source;        //!< Source of the Message
			std::string bus_name;      //!< Bus associated with the Message
            std::string protocol;      //!< Protocol type the message is associated with
			bool duplex;               //!< Indicates if a reply is expected
			bool confirm;              //!< Indicates if this Message is confirmed or not
			MessageType message_type;  //!< Type of the Message

			Utility::Buffer buffer;    //!< Stores secondary header and payload information

		private:
			TransactionID transaction_id;
        };
    }
}

#endif
