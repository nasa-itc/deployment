/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/
#ifndef NOS_ENGINE_MS1553_CLIENT_REMOTE_TERMINAL
#define NOS_ENGINE_MS1553_CLIENT_REMOTE_TERMINAL

#include <Transport/TransportHub.hpp>
#include <MS1553/visibility.hpp>
#include <MS1553/types.hpp>
#include <map>
#include <set>

namespace NosEngine
{
    namespace MS1553
    {
        namespace Client
        {
            //Should these only be used for a single RT at a time? They are really only
            //facades to finish transactions.
            
            /*
             * \brief Facade objects used to finalize transactions
             * \note Not intended for user creation
             */
            class NOS_ENGINE_MS1553_API_PUBLIC RemoteTerminal
            {
            public:
                /*
                 * \brief Constructor for a Remote Terminal
                 *
                 * \param address Address of the terminal
                 */
                RemoteTerminal(const RTAddress& address);
                
                /*
                 * \brief Class destructor
                 */
                virtual ~RemoteTerminal();
                
                /*
                 * \brief Returns the given status word to the BC
                 *
                 * \param status_word StatusWord to return
                 */
                virtual void send_status(const StatusWord& status_word) = 0;
                
                /*
                 * \brief Returns the given status word and data to the BC
                 * \param status_word StatusWord to return
                 * \param data Data to be sent
                 */
                virtual void send_status(const StatusWord& status_word, MS1553Word data[]) = 0;
               
                /*
                 * \brief Instructs the bus to act as if a transaction was not received
                 */
                virtual void ignore() = 0;

                /*
                 * \brief Address of the RT
                 */
                const RTAddress address;
			private:
				RemoteTerminal& operator=(const RemoteTerminal&);
            };

            typedef std::function<void(RemoteTerminal* const, const CommandWord&, const MS1553Word* const)> DataReceivedCallback;

            /*
             * \brief Remote Terminal Hub to be connected to the bus
             */
            class NOS_ENGINE_MS1553_API_PUBLIC RemoteTerminalHub
            {
            public:
                /*
                 * \brief Creates a Remote Terminal Hub on the bus
                 *
                 * \param hubName Name of the hub
                 * \param busName Name of the 1553 Bus
                 * \param server_uri Connection string to be used to connect to the server
                 * \param num_service_threads The number of service threads that should be created
                 */
                RemoteTerminalHub(const std::string& hubName, const std::string& busName, const std::string& server_uri, const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);

                /*
                 * \brief Creates a Remote Terminal Hub on the bus
                 *
                 * \param transport_hub Existing transport hub to use
                 * \param hubName Name of the hub
                 * \param busName Name of the 1553 Bus
                 * \param server_uri Connection string to be used to connect to the server
                 */
                RemoteTerminalHub(NosEngine::Transport::TransportHub &transport_hub, const std::string& hubName, const std::string& busName, const std::string& server_uri);
                
                /*
                 * \brief Class destructor
                 */
                ~RemoteTerminalHub();

                /**
                 * \brief Get the transport hub used by this instance.
                 * 
                 * If the instance owns the hub (ie hub was not provided to the constructor) then use
                 * the hub returned with caution.  When this instance is destroyed the hub it owns
                 * will be destroyed as well.
                 * 
                 * \return The tranport hub of this instance.
                 */
                Transport::TransportHub &get_transport_hub() const;

                /*
                 * \brief Requests that the given address be associated with the hub
                 *
                 * \param address Address to be assoicated with the bus
                 * \param callback Callback to be called when a transaction occurs on the bus for the RT
                 */
                void add_remote_terminal(const RTAddress& address, DataReceivedCallback callback);
                
                /*
                 * \brief Requests that a given address no longer be associated with the hub
                 *
                 * \param address The address to be removed
                 */ 
                void remove_remote_terminal(const RTAddress& address);

            private:
                class RemoteTerminalHubPimpl* pimpl;
            };
        }
    }
}

#endif
