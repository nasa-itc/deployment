/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_IDATA_NODE_HPP
#define NOS_ENGINE_CLIENT_IDATA_NODE_HPP

#include <Client/types.hpp>
#include <Client/INode.hpp>

namespace NosEngine
{
    namespace Client
    {
        class IDataNode :
            public virtual INode
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Destructor for an instance of the IDataNode class.
            ///
            virtual ~IDataNode() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // The following methods are defined in INode
            using INode::send_non_confirmed_message_async;
            using INode::send_confirmed_message_blocking;
            using INode::send_confirmed_message_async;
            using INode::send_request_message_blocking;
            using INode::send_request_message_async;
            using INode::send_reply_message_async;
            using INode::receive_message_blocking;

            ///
            /// \brief Send a message to multiple nodes.
            ///
            /// This will make a best-effort attempt to deliver data to multiple nodes.
            ///
            /// \warning Currently only supports broadcast. Use "*" as the destination name.
            ///
            /// \param destinations  destination nodes
            /// \param length        length of data
            /// \param data          pointer to data
            ///
            virtual void send_non_confirmed_multicast_message_async(const std::string& destinations, size_t length, const char * const data) const = 0;

            ///
            /// \brief Send data to multiple nodes with confirmation.
            ///
            /// This will deliver the data to multiple nodes and wait for confirmation of receipt for each.
            ///
            /// \warning Currently only supports broadcast. Use "*" as the destination name.
            ///
            /// \param destinations  destination nodes
            /// \param length        length of data
            /// \param data          pointer to data
            /// \param timeout       timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            virtual void send_confirmed_multicast_message_blocking(const std::string& destinations, size_t length, const char * const data, const size_t timeout = SEND_INFINITE_TIMEOUT) const = 0;
        };
    }
}

#endif
