/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_TCP_CONNECTOR_HPP
#define NOS_ENGINE_TRANSPORT_TCP_CONNECTOR_HPP

#include <boost/asio.hpp>
#include <boost/asio/ip/tcp.hpp>
using namespace boost::asio::ip;

#include <Utility/IWorkHub.hpp>

#include <Transport/Types.hpp>
#include <Transport/Connector.hpp>
#include <Transport/Transport/TCPTransport.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \brief Represents a client which makes connection requests to a server for
        /// the TCP transport.
        ///
        /// \see TCPAcceptor
        /// \see TCPConnection
        ///
        class NOS_ENGINE_TRANSPORT_API_PUBLIC TCPConnector :
            public Connector,
            public TCPTransport
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct and instance of the TCPConnector class.
            /// 
            /// \param uri      The URI which the Connector will connect to.
            /// \param work_hub The work hub to use for performing asyncronous work.
            /// 
            TCPConnector(const URI &uri, Utility::IWorkHub &work_hub);

        private:
            TCPConnector(const TCPConnector&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the TCPConnector class.
            /// 
            virtual ~TCPConnector();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            TCPConnector& operator=(const TCPConnector&); //!< Disable the copy assignment operator.

            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Handle stopping while connect operation is in-progress.
            ///
            /// \param socket The socket for the in-progress connect.
            ///
            void handle_stopping(tcp::socket *socket);

            ///
            /// \brief Handle failure for connect operation in-progress.
            ///
            /// \param socket The socket for the in-progress connect.
            ///
            void handle_failure(tcp::socket *socket);

            ///
            /// \brief Remove socket from collection.
            ///
            /// \param socket The socket to remove.
            ///
            void remove_socket(tcp::socket *socket);

            ///
            /// \brief Remove socket from collection and close it.
            ///
            /// \param socket The socket to remove and close.
            ///
            void remove_and_close_socket(tcp::socket *socket);

        protected:
            // ------------------------------------------------------------------------------------
            // Connector overrides
            // ------------------------------------------------------------------------------------

            virtual void process_connector_stop(std::unique_lock<std::mutex> &lock);

			virtual void process_connect(const size_t attempt_timeout, std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- sockets ----
            std::vector<tcp::socket *> connecting_sockets;  //!< collection of connecting sockets

            // ---- timeouts ----
            boost::asio::deadline_timer timeout_timer;      //!< for timing out connect operation attempts
            bool timed_out;                                 //!< indicates if the current connect attempt timed out
        };
    }
}

#endif