/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SPACEWIRE_SPACEWIRE_OVERLAY_HPP
#define NOS_ENGINE_SPACEWIRE_SPACEWIRE_OVERLAY_HPP

#include <Utility/BufferOverlay.hpp>
#include <Utility/ReadOnlyBufferOverlay.hpp>

#include <Common/Message.hpp>

#include <SpaceWire/visibility.hpp>
#include <SpaceWire/types.hpp>

namespace NosEngine
{
    namespace SpaceWire
    {
        /*
        * \brief A specialized buffer overlay
        *
        * A specialized buffer overlay designed to be used for the SpaceWire protocol
        */
        class NOS_ENGINE_SPACEWIRE_API_PUBLIC SpaceWireOverlay : public Utility::BufferOverlay
        {
        public:
            /* \brief Creates a new overlay based on a message object.
            *
            * Creates a new overlway based on a raw Message object. The overlay
            * will be based on Message::buffer at the Protocol::USER_DATA_START offset.
            *
            * \param message Message to base the overlay on.
            */
            SpaceWireOverlay(Common::Message& message);

            /* \brief Creates a new overlay around a buffer object.
            *
            * The created overlay will assume the default 0 offset location.
            *
            * \param buffer Buffer to be used as the base object.
            */
            SpaceWireOverlay(Utility::Buffer& buffer);

            /*
            * \brief Class destructor
            */
            virtual ~SpaceWireOverlay();
        };

        /*
        * \brief A specialized read only buffer overlay
        *
        * A specialized read only buffer overlay designed to be used for the SpaceWire protocol
        */
        class NOS_ENGINE_SPACEWIRE_API_PUBLIC ReadOnlySpaceWireOverlay : public Utility::ReadOnlyBufferOverlay
        {
        public:
            /* \brief Creates a new overlay based on a message object.
            *
            * Creates a new overlway based on a raw Message object. The overlay
            * will be based on Message::buffer at the Protocol::USER_DATA_START offset.
            *
            * \param message Message to base the overlay on.
            */
            ReadOnlySpaceWireOverlay(Common::Message& message);

            /* \brief Creates a new overlay around a buffer object.
            *
            * The created overlay will assume the default 0 offset location.
            *
            * \param buffer Buffer to be used as the base object.
            */
            ReadOnlySpaceWireOverlay(Utility::Buffer& buffer);

            /*
            * \brief Class destructor
            */
            virtual ~ReadOnlySpaceWireOverlay();
        };
    }
}

#endif /* NOS_ENGINE_SPACEWIRE_SPACEWIRE_OVERLAY_HPP */
