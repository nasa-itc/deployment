/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/
#ifndef NOS_ENGINE_MS1553_SERVER_BUS_PROTOCOL_CONTROL_TRANSACTION_HPP
#define NOS_ENGINE_MS1553_SERVER_BUS_PROTOCOL_CONTROL_TRANSACTION_HPP

#include <MS1553/visibility.hpp>
#include <Common/Transaction.hpp>
#include <Common/ISendOperator.hpp>
#include <Common/Message.hpp>

namespace NosEngine
{
	namespace MS1553
	{
		class MS1553Bus;

        /*
         * \brief Peroforms protocol specific transaction work
         */
		class BusProtocolControlTransaction : public Common::Transaction
		{
		public:
			/*
             * \brief Creates a protocol transaction
             *
             * \param bus Bus associated with the transaction
             * \param send_interface Send interface assoicated with the transaction
             */
            BusProtocolControlTransaction(MS1553Bus* bus, Common::WeakSendOperator send_interface);
			
            /*
             * \brief Class destructor
             */
            virtual ~BusProtocolControlTransaction();
			
            /*
             * \brief Performs the associated work for the Transaction
             *
             * \param message The message to work on
             * \return If the transaction is complete 
             */
            virtual Common::TransactionWorkResult work(std::unique_lock<std::mutex> &lock);
		private:
			MS1553Bus* const bus;
			Common::WeakSendOperator sender;
		};
	}
}

#endif 
