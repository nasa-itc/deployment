/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/
#ifndef NOS_ENGINE_MS1553_PROTOCOL_HPP
#define NOS_ENGINE_MS1553_PROTOCOL_HPP

#include <Common/Fwd.hpp>
#include <MS1553/types.hpp>
#include <MS1553/visibility.hpp>
#include <string>
#include <cstddef>

namespace NosEngine
{
    namespace MS1553
    {
        enum class BusCommands : uint8_t
        {
            AddRemoteTerminal,
            RemoveRemoteTerminal,
            COMMAND_INVALID
        };

        /*
         * \brief Get the protocol command from an overlay
         *
         * \param overlay overlay to get a command from
         * \return Protocol command
         */
		NOS_ENGINE_MS1553_API_PUBLIC BusCommands get_command(const Utility::ReadOnlyBufferOverlay* const overlay);
		
        /*
         * \brief write a protocol command to an overlay
         *
         * \param overlay overlay to write to
         * \param command protocol command to write
         */
        NOS_ENGINE_MS1553_API_PUBLIC void set_command(Utility::BufferOverlay* overlay, const BusCommands& command);

        /*
         * \brief Get an RT address from an overlay
         *
         * \param overlay Overlay to get the address from
         *
         * \return RTAddress 
         */
		NOS_ENGINE_MS1553_API_PUBLIC RTAddress get_rt(const Utility::ReadOnlyBufferOverlay* const overlay);
		
        /*
         * \brief Write an RTAdress to an overlay
         *
         * \param overlay Overlay to write to
         * \param address RTAddress to write
         */
        NOS_ENGINE_MS1553_API_PUBLIC void set_rt(Utility::BufferOverlay* overlay, const RTAddress& address);

        /*
         * \brief Get a hub name from an overlay
         *
         * \param overlay Overlay to read from
         *
         * \return Hub name
         */
		NOS_ENGINE_MS1553_API_PUBLIC std::string get_hub_name(const Utility::ReadOnlyBufferOverlay* const overlay);
		
        /*
         * \brief Write a hub name to an overlay
         *
         * \param overlay Overlay to write to
         * \param name Hub name to write
         */
        NOS_ENGINE_MS1553_API_PUBLIC void set_hub_name(Utility::BufferOverlay* overlay, const std::string& name);
        
        /*
         * \brief Get a command word from an overlay
         *
         * \param overlay Overlay to read from
         *
         * \return CommandWord
         */
		NOS_ENGINE_MS1553_API_PUBLIC CommandWord get_command_word(const Utility::ReadOnlyBufferOverlay* const overlay);
		
        /*
         * \brief Write a command word to an overlay
         *
         * \param overlay Overlay to write to
         * \param command CommandWord to write
         */
        NOS_ENGINE_MS1553_API_PUBLIC void set_command_word(Utility::BufferOverlay* const overlay, const CommandWord& command);

        /*
         * \brief Get an error code from an overlay
         *
         * \param overlay Overlay to read from
         *
         * \return ErrorCode
         */
        NOS_ENGINE_MS1553_API_PUBLIC ErrorCodes get_error_codes(const Utility::ReadOnlyBufferOverlay* const overlay);
		
        /*
         * \brief Write an error code to an overlay
         *
         * \param overlay Overlay to write to
         * \param error ErrorCode to write
         */
        NOS_ENGINE_MS1553_API_PUBLIC void set_error_codes(Utility::BufferOverlay* const overlay, const ErrorCodes& error);

		/*
         * \brief Get a status word from an overlay
         *
         * \param overlay Overlay to read from
         *
         * \return StatusWord
         */
		NOS_ENGINE_MS1553_API_PUBLIC StatusWord get_status_word(const Utility::ReadOnlyBufferOverlay* const overlay);
		
        /*
         * \brief Write a status word to an overlay
         *
         * \param overlay Overlay to write to
         * \param status StatusWord to write
         */
        NOS_ENGINE_MS1553_API_PUBLIC void set_status_word(Utility::BufferOverlay* overlay, const StatusWord& status);

		/*
         * \brief Get a word count from an overlay
         *
         * \param overlay Overlay to read from
         *
         * \return WordCount
         */
		NOS_ENGINE_MS1553_API_PUBLIC WordCount get_word_count(const Utility::ReadOnlyBufferOverlay* const overlay);
		
        /*
         * \brief Write a word count to an overlay
         *
         * \param overlay Overlay to write to
         * \param count WordCount to write
         */
        NOS_ENGINE_MS1553_API_PUBLIC void set_word_count(Utility::BufferOverlay* overlay, const WordCount& count);

        /*
        * \brief Get a 1553 data from an overlay
        *
        * \param overlay Overlay to read from
        * \param data Data to write
        * \param size size of the data to write
        */
        NOS_ENGINE_MS1553_API_PUBLIC void get_data(const Utility::ReadOnlyBufferOverlay* const overlay, MS1553Word * data, const WordCount &size);
		
        /*
         * \brief Write 1553 data to an overlay
         *
         * \param overlay Overlay to write to
         * \param data Data to write
         * \param size Size of data
         */
        NOS_ENGINE_MS1553_API_PUBLIC void set_data(Utility::BufferOverlay* overlay, const MS1553Word* const data, const WordCount &size);

		//Utility Methods for base layer operations

        /*
         * \brief Creates a generated RT string name
         *
         * \param address RTAddress to use for the name
         *
         * \return Generated RT name
         */
		NOS_ENGINE_MS1553_API_PUBLIC std::string create_rt_name(const RTAddress& address);
		
        /*
         * \brief Attempts to read an RTAddress from a string
         *
         * Reads the RTAddress from a string generated by create_rt_name
         *
         * \param name String to read from
         *
         * \return The RTAddress
         */
        NOS_ENGINE_MS1553_API_PUBLIC RTAddress get_rt_address_from_name(const std::string& name);
    }
}
#endif
