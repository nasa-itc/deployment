/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_IWORK_HUB_HPP
#define NOS_ENGINE_UTILITY_IWORK_HUB_HPP

#include <Utility/Types.hpp>
#include <Utility/Globals.hpp>
#include <Utility/Events/IOnError.hpp>
#include <Utility/States/IStoppable.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \brief Represents a collection of threads that are used to execute work items posted
        /// to a work queue.
        ///
        class IWorkHub :
            public virtual IEngineThreadSafeObjectWithCV,
            public virtual Events::IOnError,
            public virtual States::IStoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IWorkHub class.
            /// 
            virtual ~IWorkHub() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get a value indicating if the current thread is a service thread belonging
            /// the work hub.
            /// 
            /// \return A value indicating if the current thread is a service thread.
            /// 
            virtual bool in_service_thread() = 0;

            ///
            /// \brief When called replaces the current service thread with a new one.
            /// 
            /// When the current thread is replaced, then calls to
            /// IWorkHub::wait_current_work(const Timeout &) or
            /// IWorkHub::wait_current_work(const TimeoutClock::time_point &)
            /// will not wait on the work being executed by the current thread.
            /// 
            /// A thread is only replace if the current thread is a service thread belonging
            /// to the work hub.
            /// 
            virtual void replace_current_thread() = 0;

            ///
            /// \brief Wait for currently posted/executing work to finish.
            /// 
            /// - The default for the timeout parameter is INFINITE_TIMEOUT.
            ///   + Passing in INFINITE_TIMEOUT for the timeout parameter waits forever.
            /// 
            /// - Work posted while this method is being called will be posted to a
            /// defered work queue instead of the main queue.
            /// - Each call to this method creates a new defered work queue.
            /// 
            /// \param timeout The amount of time to wait for the work to finish.
            /// 
            /// \throw Error::OperationTimedout if the work did not finish before the timeout was hit.
            /// 
            virtual void wait_current_work(const Timeout &timeout = INFINITE_TIMEOUT) = 0;

            ///
            /// \brief Wait for currently posted/executing work to finish.
            /// 
            /// - Work posted while this method is being called will be posted to a
            /// defered work queue instead of the main queue.
            /// - Each call to this method creates a new defered work queue.
            /// 
            /// \param timeout An absolute time to wait to for the work to finish.
            /// 
            /// \throw Error::OperationTimedout if the work did not finish before the timeout was hit.
            /// 
            virtual void wait_current_work(const TimeoutClock::time_point &timeout) = 0;

            ///
            /// \brief Post a work item to the work hub's queue to be executed by
            /// one of the hub's service threads.
            /// 
            /// \note Work functions should return quickly; they must not block.
            /// They may post more work, or results.
            /// 
            /// \param work The work item to post.
            /// 
            /// \throw Error::Shutdown if called after IWorkHub::stop() was called.
            /// 
            virtual void post_work(Work work) = 0;

            ///
            /// \brief Post a work item to the work hub's queue, after the specified delay,
            /// to be executed by one of the hub's service threads.
            /// 
            /// \note Work functions should return quickly; they must not block.
            /// They may post more work, or results.
            /// 
            /// \param delay    The amount of time (in milliseconds) to delay before posting the work.
            /// \param work     The work item to post after the delay.
            /// 
            /// \throw Error::Shutdown if called after IWorkHub::stop() was called.
            /// 
            virtual void post_work_after(const std::chrono::milliseconds &delay, Work work) = 0;

            ///
            /// \brief Post a work item to the work hub's queue, after the specified time is reached,
            /// to be executed by one of the hub's service threads.
            /// 
            /// \note Work functions should return quickly; they must not block.
            /// They may post more work, or results.
            /// 
            /// \param time The time to wait to before posting the work.
            /// \param work The work item to post after the delay.
            /// 
            /// \throw Error::Shutdown if called after IWorkHub::stop() was called.
            /// 
            virtual void post_work_at(const TimerQueueTimepoint &time, Work work) = 0;

            ///
            /// \brief Immediately execute some blocking work.
            /// 
            /// - When called a check is performed to determine if the current thread is a
            /// service thread belonging to the hub.
            /// - If the current thread is a service thread, then it is replaced with a new
            /// thread so that the blocking work will not hold up a service thread
            /// for a long period of time (which could prevent the hub from performing other
            /// work).
            /// 
            /// \note This method exists to help with deadlock avoidance.
            /// 
            /// \note Only pass in true for the wait_ignore argument if you are certain
            /// that the current work being performed should not hold up wait_current_work
            /// calls.
            /// 
            /// \param work the     Blocking work to execute.
            /// \param wait_ignore  If true then ensures that calls to
            /// IWorkHub::wait_current_work(const Timeout &) or
            /// IWorkHub::wait_current_work(const TimeoutClock::time_point &)
            /// will not wait on the work being executed by the current thread
            /// (USE WITH CAUTION !!!).
            /// 
            virtual void execute_blocking_work(Work work, const bool &wait_ignore = false) = 0;

            ///
            /// \brief Get the number of work items currently queued.
            /// 
            /// \note For statistics/debugging.
            /// 
            /// Includes defered work items in the count.
            /// 
            /// \return The number of work items.
            /// 
            virtual size_t get_work_queued_count() = 0;

            ///
            /// \brief Get the number of work items currently that are currently defered.
            /// 
            /// \note For statistics/debugging.
            /// 
            /// Work items are defered when they are posted while either
            /// IWorkHub::wait_current_work(const Timeout &) or
            /// IWorkHub::wait_current_work(const TimeoutClock::time_point &)
            /// methods is being called.
            /// 
            /// \return The number of work items.
            /// 
            virtual size_t get_work_defered_count() = 0;

            ///
            /// \brief Get the number of defered work queues that currently exist.
            /// 
            /// \note For statistics/debugging.
            /// 
            /// A new defered work queue is created whenever
            /// IWorkHub::wait_current_work(const Timeout &) or
            /// IWorkHub::wait_current_work(const TimeoutClock::time_point &)
            /// methods are called, and destroyed before those method calls return.
            /// 
            /// \return The number of work items.
            /// 
            virtual size_t get_defered_queue_count() = 0;

            ///
            /// \brief Get the number of work items which have started (and potentially
            /// finsihed) executing via a service thread belong to the hub.
            /// 
            /// \note For statistics/debugging.
            /// 
            /// \return The number of work items.
            /// 
            virtual size_t get_work_started_count() = 0;

            ///
            /// \brief Get the number of work items which have finished being executed
            /// by a service thread belong to the hub.
            /// 
            /// \note For statistics/debugging.
            /// 
            /// \return The number of work items.
            /// 
            virtual size_t get_work_completed_count() = 0;

            ///
            /// \brief Get the number of work items which are currently queued or being
            /// executed.
            ///
            /// \note For statistics/debugging.
            /// 
            /// inprogress = queued + (started - completed)
            /// 
            /// \return The number of work items.
            /// 
            virtual size_t get_work_queued_or_inprogress_count() = 0;

            ///
            /// \brief Get the timer queue which belongs to the work hub.
            /// 
            /// The TimerQueue returned can be used to execute any generic timer.
            /// 
            /// \return The timer queue belonging to the hub.
            /// 
            /// \throw Error::Shutdown if called after IWorkHub::stop() was called.
            /// 
            virtual ITimerQueue &get_timer_queue() = 0;

            ///
            /// \brief Create a work chain for this work hub.
            /// 
            /// A WorkChain allows for serial execution of work even when the hub has
            /// multiple service threads.
            /// 
            /// \return The new work chain.
            /// 
            /// \throw Error::Shutdown if called after IWorkHub::stop() was called.
            /// 
            virtual WorkChain *create_work_chain() = 0;
        };
    }
}

#endif // NOS_ENGINE_UTILITY_IWORK_HUB_HPP