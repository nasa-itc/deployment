/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_CALLBACK_LIST_HPP
#define NOS_ENGINE_UTILITY_CALLBACK_LIST_HPP

#include <cstdint>
#include <functional>
#include <mutex>
#include <map>
#include <algorithm>

#include <Utility/Types.hpp>
#include <Utility/Error/CallbackRemovalFailed.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \brief Represents a list of callbacks.
        ///
        template<typename OWNER_TYPE,
            typename T1, typename T2, typename T3, typename T4, typename T5,
            typename T6, typename T7, typename T8, typename T9, typename T10,
            typename TINVALID>
        class CallbackList
        {
        private:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            CallbackList(); //!< Disable the default constructor.
        };
    }
}

#define NE_CALLBACK_LIST_EXPAND_TYPES(macro) 
#define NE_CALLBACK_LIST_EXPAND_TYPES_ALL(macro) macro(OWNER_TYPE)
#include <Utility/CallbackList.ipp>
#undef NE_CALLBACK_LIST_EXPAND_TYPES
#undef NE_CALLBACK_LIST_EXPAND_TYPES_ALL

#define NE_CALLBACK_LIST_EXPAND_TYPES_ALL(macro) macro(OWNER_TYPE), NE_CALLBACK_LIST_EXPAND_TYPES(macro)

#define NE_CALLBACK_LIST_EXPAND_TYPES(macro) macro(T1)
#include <Utility/CallbackList.ipp>
#undef NE_CALLBACK_LIST_EXPAND_TYPES

#define NE_CALLBACK_LIST_EXPAND_TYPES(macro) macro(T1), macro(T2)
#include <Utility/CallbackList.ipp>
#undef NE_CALLBACK_LIST_EXPAND_TYPES

#define NE_CALLBACK_LIST_EXPAND_TYPES(macro) macro(T1), macro(T2), macro(T3)
#include <Utility/CallbackList.ipp>
#undef NE_CALLBACK_LIST_EXPAND_TYPES

#define NE_CALLBACK_LIST_EXPAND_TYPES(macro) macro(T1), macro(T2), macro(T3), macro(T4)
#include <Utility/CallbackList.ipp>
#undef NE_CALLBACK_LIST_EXPAND_TYPES

#define NE_CALLBACK_LIST_EXPAND_TYPES(macro) macro(T1), macro(T2), macro(T3), macro(T4), macro(T5)
#include <Utility/CallbackList.ipp>
#undef NE_CALLBACK_LIST_EXPAND_TYPES

#define NE_CALLBACK_LIST_EXPAND_TYPES(macro) macro(T1), macro(T2), macro(T3), macro(T4), macro(T5),\
                                             macro(T6)
#include <Utility/CallbackList.ipp>
#undef NE_CALLBACK_LIST_EXPAND_TYPES

#define NE_CALLBACK_LIST_EXPAND_TYPES(macro) macro(T1), macro(T2), macro(T3), macro(T4), macro(T5),\
                                             macro(T6), macro(T7)
#include <Utility/CallbackList.ipp>
#undef NE_CALLBACK_LIST_EXPAND_TYPES

#define NE_CALLBACK_LIST_EXPAND_TYPES(macro) macro(T1), macro(T2), macro(T3), macro(T4), macro(T5),\
                                             macro(T6), macro(T7), macro(T8)
#include <Utility/CallbackList.ipp>
#undef NE_CALLBACK_LIST_EXPAND_TYPES

#define NE_CALLBACK_LIST_EXPAND_TYPES(macro) macro(T1), macro(T2), macro(T3), macro(T4), macro(T5),\
                                             macro(T6), macro(T7), macro(T8), macro(T9)
#include <Utility/CallbackList.ipp>
#undef NE_CALLBACK_LIST_EXPAND_TYPES

#define NE_CALLBACK_LIST_EXPAND_TYPES(macro) macro(T1), macro(T2), macro(T3), macro(T4), macro(T5),\
                                             macro(T6), macro(T7), macro(T8), macro(T9), macro(T10)
#include <Utility/CallbackList.ipp>
#undef NE_CALLBACK_LIST_EXPAND_TYPES

#undef NE_CALLBACK_LIST_EXPAND_TYPES_ALL

#endif