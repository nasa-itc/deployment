/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_FWD_HPP
#define NOS_ENGINE_UTILITY_FWD_HPP

#include <Utility/Error/Fwd.hpp>

namespace NosEngine
{
    namespace Utility
    {
        namespace Error
        {
            namespace Base
            {
                class IErrorBase;
                class IErrorType;
            }

            namespace Detail
            {
                class IErrorDetails;
                class ErrorDetails;

                class ErrorTrace;
                class NoErrorDetails;
            }

            namespace Implementation
            {
                class IErrorImpl;
            }
        }

        namespace Events
        {
            class IOnCanceled;
            template<class C>
            class OnCanceled;

            class IOnCanceling;
            template<class C>
            class OnCanceling;

            class IOnDestroy;
            class OnDestroy;

            class IOnError;
            template<class C, class ERROR_TYPE = Utility::Error::Error>
            class OnError;

            class IOnPauseChanged;
            template<class C>
            class OnPauseChanged;

            class IOnStopped;
            template<class C>
            class OnStopped;

            class IOnStopping;
            template<class C>
            class OnStopping;
        }

        class IDeserializer;
        class Deserializer;
        class ISerializer;
        class Serializer;

        namespace States
        {
            class ICancelable;
            class Cancelable;

            class IPauseable;
            class Pauseable;

            class IStoppable;
            class Stoppable;
        }

        class IBuffer;
        class Buffer;

        class IBufferOverlay;
        class BufferOverlay;

        template<typename OWNER_TYPE,
            typename T1 = void, typename T2 = void, typename T3 = void, typename T4 = void, typename T5 = void,
            typename T6 = void, typename T7 = void, typename T8 = void, typename T9 = void, typename T10 = void,
            typename TINVALID = void>
        class CallbackList;

        class IEngineObject;
        class EngineObject;

        class IEngineThreadSafeObject;
        class EngineThreadSafeObject;

        class Logger;

        template<class T>
        class IQueue;
        template<class T>
        class Queue;

        class IReadOnlyBufferOverlay;
        class ReadOnlyBufferOverlay;

        class ITimerQueue;
        class TimerQueue;

        class IWorkChain;
        class WorkChain;

        class IWorkChainWorkWrapper;
        class WorkChainWorkWrapper;

        struct WorkHubServiceThread;
        class IWorkHub;
        class WorkHub;
    }
}

#endif

