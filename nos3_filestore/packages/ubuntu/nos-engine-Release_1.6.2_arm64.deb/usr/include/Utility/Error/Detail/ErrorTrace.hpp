/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
any warranty that the software will be error free.

In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
documentation or services provided hereunder.

ITC Team
NASA IV&V
ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_ERROR_ERROR_TRACE_HPP
#define NOS_ENGINE_UTILITY_ERROR_ERROR_TRACE_HPP

#include <list>
#include <cstdint>

#include <Utility/Types.hpp>

namespace NosEngine
{
    namespace Utility
    {
        namespace Error
        {
            namespace Detail
            {
                /// 
                /// \brief Represents error single entry in an error backtrace.
                /// 
                struct NOS_ENGINE_UTILITY_API_PUBLIC ErrorTraceEntry
                {
                    // ============================================================================
                    // Life cycle
                    // ----------------------------------------------------------------------------

                    /// 
                    /// \brief Construct an instance of the ErrorTraceEntry struct.
                    /// 
                    /// \param file Source file name.
                    /// \param function Name of function or class method in the source file.
                    /// \param line Source file line number.
                    /// 
                    ErrorTraceEntry(const std::string &file, const std::string &function, const uint32_t &line);

                    // ============================================================================
                    // Data members
                    // ----------------------------------------------------------------------------

                    std::string file;       //!< source file
                    std::string function;   //!< function or clas method name
                    uint32_t line;          //!< line number
                };

                typedef std::list<ErrorTraceEntry> ErrorTraceEntrys;

                /// 
                /// \brief Represents a NOS generated partial backtrace for an error.
                /// 
                class NOS_ENGINE_UTILITY_API_PUBLIC ErrorTrace
                {
                public:
                    // ============================================================================
                    // Life cycle
                    // ----------------------------------------------------------------------------

                    /// 
                    /// \brief Construct an instance of the ErrorTrace class.
                    /// 
                    ErrorTrace();

                    // ============================================================================
                    // Public API
                    // ----------------------------------------------------------------------------

                    /// 
                    /// \brief Append an entry to the backtrace.
                    /// 
                    /// \param file Source file name.
                    /// \param function Name of function or class method in the source file.
                    /// \param line Source file line number.
                    /// 
                    void append(const std::string &file, const std::string &function, const uint32_t &line);

                    /// 
                    /// \brief Get string representation of the NOS generated partial backtrace.
                    /// 
                    /// \param multiline True to generate a multiline backtrace (defaults to single line).
                    /// 
                    /// \return The partial backtrace as a string.
                    /// 
                    const std::string to_string(const bool &multiline = false) const;

                private:
                    // ============================================================================
                    // Data members
                    // ----------------------------------------------------------------------------

                    ErrorTraceEntrys entries; //!< list of trace entries
                };
            }
        }
    }
}

#endif