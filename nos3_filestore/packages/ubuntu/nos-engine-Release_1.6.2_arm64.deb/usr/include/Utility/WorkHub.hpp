/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_WORK_HUB_HPP
#define NOS_ENGINE_UTILITY_WORK_HUB_HPP

#include <cstdio>
#include <list>
#include <vector>
#include <map>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <chrono>

#include <Utility/Types.hpp>
#include <Utility/Globals.hpp>
#include <Utility/IWorkHub.hpp>
#include <Utility/States/Stoppable.hpp>
#include <Utility/Queue.hpp>
#include <Utility/TimerQueue.hpp>
#include <Utility/WorkChain.hpp>
#include <Utility/Events/OnError.hpp>

namespace NosEngine {
namespace Utility {

///
/// \copydoc IWorkHub
///
class NOS_ENGINE_UTILITY_API_PUBLIC WorkHub :
    public IWorkHub,
    public Events::OnError<WorkHub>,
    public States::Stoppable {
protected:
    // ============================================================================================
    // Types
    // --------------------------------------------------------------------------------------------

    typedef std::list<WorkHub*> WorkHubs;
    typedef std::map<std::thread::id, WorkHub*> ThreadToWorkHubMap;
    typedef std::map<std::thread::id, WorkHubServiceThread*> WorkHubServiceThreadMap;
    typedef std::list<Work> WorkQueue;
    typedef std::list<WorkQueue> WorkQueues;
    typedef std::list<WorkChain*> WorkChains;

public:
    // ============================================================================================
    // Life cycle
    // --------------------------------------------------------------------------------------------

    /// 
    /// \brief Construct and instance of the WorkHub class.
    /// 
    /// \param num_service_threads The number of service threads the work hub should create.
    /// 
    WorkHub(size_t num_service_threads = WORK_HUB_DEFAULT_SERVICE_THREADS);

private:
    WorkHub(const WorkHub &); //!< Disable the copy constructor.

public:
    /// 
    /// \brief Destructor for an instance of the TimerQueue class.
    /// 
    virtual ~WorkHub();

private:
    // ============================================================================================
    // Operators
    // --------------------------------------------------------------------------------------------

    WorkHub& operator=(const WorkHub &); //!< Disable the copy assignment operator.

public:
    // ============================================================================================
    // Public API
    // --------------------------------------------------------------------------------------------

    ///
    /// \brief Get the work hub which the current thread belongs to.
    /// 
    /// \return The work hub (or nullptr if the current thread does not belong to a hub).
    ///
    static WorkHub *get_current_thread_hub();

    ///
    /// \brief Get the total number of work.
    /// 
    /// \return The number of service threads.
    ///
    static size_t get_global_hub_count();

    ///
    /// \brief Get the total number of active service threads that belong to work hubs.
    /// 
    /// \return The number of active service threads.
    ///
    static size_t get_global_service_thread_count();

    // --------------------------------------------------------------------------------------------
    // IWorkHub implementation
    // --------------------------------------------------------------------------------------------

    virtual bool in_service_thread();

    virtual void replace_current_thread();

    virtual void wait_current_work(const Timeout &timeout = INFINITE_TIMEOUT);

	virtual void wait_current_work(const TimeoutClock::time_point &timeout);

    virtual void post_work(Work work);

    virtual void post_work_after(const std::chrono::milliseconds &delay, Work work);

    virtual void post_work_at(const TimerQueueTimepoint &time, Work work);

    virtual void execute_blocking_work(Work work, const bool &wait_ignore = false);

    virtual size_t get_work_queued_count();

    virtual size_t get_work_defered_count();

    virtual size_t get_defered_queue_count();

    virtual size_t get_work_started_count();

    virtual size_t get_work_completed_count();

    virtual size_t get_work_queued_or_inprogress_count();

    virtual ITimerQueue& get_timer_queue();

    virtual WorkChain *create_work_chain();

protected:
    // ============================================================================================
    // Internal API
    // --------------------------------------------------------------------------------------------

    ///
    /// \brief Pops work times from the queue and executes them using WorkHub::run_work(Work &).
    /// 
    /// Executed by service threads.
    /// Does not return until WorkHub::stop() is called.
    /// 
    /// \param lock A lock that has acquired a lock of WorkHub::mutex.
    ///
    virtual void run(std::unique_lock<std::mutex> &lock);

    ///
    /// \brief Executes the work item.
    /// 
    /// \note Lock on a mutex is NOT held while executing the work item.
    /// 
    /// Exceptions thrown by the work item are caught and passed to
    /// any on error callbacks currently associated with the hub.
    /// Exceptions thrown by an on error callback are printed to stderr.
    /// 
    /// \param work The work item to execute.
    ///
    virtual void run_work(Work &work);

private:
    ///
    /// \brief Create a new service thread and associate it with the hub.
    ///
    void create_service_thread();

    ///
    /// \brief Create a new service thread and associate it with the hub.
    ///
    /// \param lock A lock that has acquired a lock of WorkHub::mutex.
    ///
    void create_service_thread(std::unique_lock<std::mutex> &lock);

    ///
    /// \brief Get the service thread instance for the specified thread id.
    /// 
    /// \return The service thread instance (or nullptr if not found).
    ///
    WorkHubServiceThread* get_service_thread(const std::thread::id &thread_id);

    ///
    /// \brief Get the service thread instance for the specified thread id.
    ///
    /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
    /// 
    /// \return The service thread instance (or nullptr if not found).
    ///
    WorkHubServiceThread* get_service_thread_no_lock(const std::thread::id &thread_id);

    ///
    /// \brief Join all service threads that are currently flagged as stopped.
    /// 
    /// \param lock A lock that has acquired a lock of WorkHub::mutex.
    ///
    void join_stopped_service_threads(std::unique_lock<std::mutex> &lock);

    ///
    /// \brief Check if the thread is a service thread.
    /// 
    /// \param thread_id The id of the thread to check for being a service thread.
    ///
    bool in_service_thread(const std::thread::id &thread_id);

    ///
    /// \brief See WorkHub::in_service_thread(const std::thread::id &).
    /// 
    /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
    ///
    bool in_service_thread_no_lock(const std::thread::id &thread_id);

    ///
    /// \brief See WorkHub::replace_current_thread().
    ///
    /// \param lock A lock that has acquired a lock of WorkHub::mutex.
    ///
    void replace_current_thread(std::unique_lock<std::mutex> &lock, const bool &wait_ignore = false);

    ///
    /// \brief See WorkHub::wait_current_work(const Timeout &) and
    /// WorkHub::wait_current_work(const TimeoutClock::time_point &).
    /// 
    /// \param lock A lock that has acquired a lock of WorkHub::mutex.
    ///
    void wait_current_work(std::unique_lock<std::mutex> &lock);

    ///
    /// \brief See WorkHub::wait_current_work(const Timeout &) and
    /// WorkHub::wait_current_work(const TimeoutClock::time_point &).
    /// 
    /// \param timeout      A value indicating if a timeout was provided (false to wait forever).
    /// \param timeout_time An absolute time to wait to for the work to finish.
    /// \param lock         A lock that has acquired a lock of WorkHub::mutex.
    ///
    void wait_current_work(const bool &timeout, const TimeoutClock::time_point &timeout_time, std::unique_lock<std::mutex> &lock);

    ///
    /// \brief Post all of the work from the defered work queue to the main queue.
    ///
    /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
    /// 
    /// \param defered_work_q The defered work queue.
    ///
    void post_defered_work_no_lock(WorkQueue &defered_work_q);

    ///
    /// \brief Transfers work items from the defered work queue to another work queue.
    ///
    /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
    /// 
    /// \param defered_work_q   The defered work queue.
    /// \param target           The work queue to transfer the work items to.
    ///
    void transfer_defered_work_no_lock(WorkQueue &defered_work_q, WorkQueue &target);

    ///
    /// \brief See WorkHub::get_work_defered_count().
    ///
    /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
    ///
    size_t get_work_defered_count_no_lock();

protected:
    // --------------------------------------------------------------------------------------------
    // IWorkHub (IEngineThreadSafeObjectWithCV) implementation
    // --------------------------------------------------------------------------------------------

    virtual std::mutex &get_mutex() const;

    virtual std::condition_variable &get_cv() const;

    // ------------------------------------------------------------------------------------
    // Stoppable implementation
    // ------------------------------------------------------------------------------------

    virtual bool is_stopping_no_lock() const;

    virtual void set_stopping_no_lock(const bool &stopping);

    virtual bool is_stopped_no_lock() const;

    virtual void set_stopped_no_lock(const bool &stopped);

    ///
    /// \copydoc States::Stoppable::process_stop(std::unique_lock<std::mutex> &)
    /// 
    /// - The hub is put into a state which prevents further work from being posted.
    /// - Methods will throw an Error::Shutdown exception if called after this method
    /// is called.
    /// - The timer queue belonging to the hub is stopped.
    /// - Any work chain created by calling WorkHub::create_work_chain() will be stoppped.
    /// - If there is any work that is currently in-progress, this method will wait
    /// for that work to finish.
    /// - All service threads will be joined and destroyed.
    ///
    virtual void process_stop(std::unique_lock<std::mutex> &);

protected:
    // ============================================================================================
    // Data members
    // --------------------------------------------------------------------------------------------

    // ---- global work hub tracking ----
    static std::mutex work_hubs_mutex;
    static WorkHubs work_hubs;
    static ThreadToWorkHubMap work_hubs_threads;

    // ---- queues ----
    WorkQueue work_q;                                       //!< Work item queue.
    WorkQueues defered_work_qs;                             //!< Defered work item queue(s).
    TimerQueue timer_q;                                     //!< A timer queue owned by the hub and used for post_work_after/post_work_at.

    // ---- collections ----
    WorkChains work_chains;                                 //!< Work chains for the hub, created by WorkHub::create_work_chain().

    // ---- threads ----
    WorkHubServiceThreadMap service_thread_map;             //!< Maps thread id(s) to active service thread instances.
    WorkHubServiceThreadMap stopping_service_thread_map;    //!< Maps thread id(s) th stopping/inactive service thread instances.

    // ---- thread syncronization ----
    mutable std::mutex mutex;
    mutable std::condition_variable cond;
    mutable std::condition_variable work_q_cond;            //!< For posting work to the queue.
    mutable std::condition_variable wait_work_cond;         //!< For waiting on current work to complete.

    // ---- startup/shutdown status ----
    size_t threads_started;                                 //!< The number of service threads started.
    size_t threads_stopped;                                 //!< The number of service threads stopped.
    bool stopping;
    bool stopped;

    // ---- counters ----
    size_t num_service_threads;                             //!< The current number of service threads that belong to the hub.
    size_t work_count;                                      //!< The total count of work items that have started execution (never decremented)
    size_t work_completed_count;                            //!< The total count of work items that have completed execution (never decremented)
    size_t wait_ignore_work_count;                          //!< Count of executing work items to be ignored by wait_current_work calls.
};

}}

#endif

