/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_READ_ONLY_BUFFER_OVERLAY_HPP
#define NOS_ENGINE_UTILITY_READ_ONLY_BUFFER_OVERLAY_HPP

#include <Utility/Types.hpp>
#include <Utility/Buffer.hpp>
#include <Utility/IReadOnlyBufferOverlay.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \copydoc IReadOnlyBufferOverlay
        ///
        class NOS_ENGINE_UTILITY_API_PUBLIC ReadOnlyBufferOverlay :
            public IReadOnlyBufferOverlay
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the ReadOnlyBufferOverlay class.
            ///
            /// \param to_overlay The buffer which this is overlaying.
            /// 
            ReadOnlyBufferOverlay(const Utility::Buffer &to_overlay);

            /// 
            /// \brief Construct an instance of the ReadOnlyBufferOverlay class.
            ///
            /// \param offset       Offset into the buffer which this overlays.
            /// \param to_overlay   The buffer which this is overlaying.
            /// 
            ReadOnlyBufferOverlay(const size_t &offset, const Utility::Buffer &to_overlay);

            /// 
            /// \brief Copy constructor.
            ///
            ReadOnlyBufferOverlay(const ReadOnlyBufferOverlay &other);

            /// 
            /// \brief Destructor for an instance of the ReadOnlyBufferOverlay class.
            /// 
            virtual ~ReadOnlyBufferOverlay();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            ReadOnlyBufferOverlay operator=(const ReadOnlyBufferOverlay &); //!< Disable the copy assignment operator.

        public:
            // ------------------------------------------------------------------------------------
            // IReadOnlyBufferOverlay implementation
            // ------------------------------------------------------------------------------------

            operator const Utility::IBuffer*() const;

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IReadOnlyBufferOverlay implementation
            // ------------------------------------------------------------------------------------

            virtual size_t get_length() const;

            virtual size_t get_size() const;

            virtual const char* get_data() const;

        public:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            const size_t len;   //!< the length of the window into the buffer (overlay length)
            const size_t size;  //!< the size of the window into the buffer (overlay size)
            const char* data;   //!< the data window (overlay data)

        private:
            Utility::Buffer conversion; //!< for conversion into a const Buffer
        };
    }
}

#endif