/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_SERIALIZATION_BUFFER_UTILS_HPP
#define NOS_ENGINE_UTILITY_SERIALIZATION_BUFFER_UTILS_HPP

#include <Utility/Types.hpp>
#include <Utility/Serialization/Endian.hpp>

namespace NosEngine {
namespace Utility {
namespace Serialize {

///
/// \brief Append data to the end of a buffer
///
/// The returned buffer is heap-allocated and must be freed by the caller when finished.
///
/// \param buf  destination buffer
/// \param data pointer to data
/// \param n    length of data to buffer
///
/// \throw InvalidArgument  buf is null or data is null
/// \throw BufferOverflow   there is not enough space left in the buffer
///
void NOS_ENGINE_UTILITY_API_PUBLIC buffer_data(IBuffer *buf, const char * const data, size_t n);

///
/// \brief Copy data out of a buffer
///
/// \param buf     source buffer
/// \param offset  offset into buffer
/// \param data    pointer to destination array
/// \param n       length of data to copy
/// 
/// \throw InvalidArgument  buf is null or data is null
/// \throw BufferUnderflow  there is not enough data in the buffer
///
void NOS_ENGINE_UTILITY_API_PUBLIC unbuffer_data(const IBuffer * const buf, size_t &offset, char *data, const size_t n);

}}}

#endif // NOS_ENGINE_UTILITY_SERIALIZATION_BUFFER_UTILS_HPP