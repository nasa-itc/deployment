/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_SERIALIZATION_IDESERIALIZER_HPP
#define NOS_ENGINE_UTILITY_SERIALIZATION_IDESERIALIZER_HPP

#include <Utility/Types.hpp>
#include <Utility/Serialization/ISerializable.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \brief Provides deserialization capabilities for a buffer.
        ///
        class IDeserializer
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IDeserializer class.
            /// 
            virtual ~IDeserializer() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief de-serialize a boolean
            /// 
            /// \throw BufferUnderflow  there is not enough data in the buffer to deserialize a boolean
            ///
            /// \return de-serialized boolean value
            ///
            virtual bool deserialize_bool() = 0;

            ///
            /// \brief de-serialize a character
            /// 
            /// \throw BufferUnderflow  there is not enough data in the buffer to deserialize a char
            ///
            /// \return de-serialized character value
            ///
            virtual char deserialize_char() = 0;

            ///
            /// \brief de-serialize an 8-bit integer
            ///
            /// \throw BufferUnderflow  there is not enough data in the buffer to deserialize an 8-bit integer
            ///
            /// \return de-serialized 8-bit integer value
            ///
            virtual int8_t deserialize_int8() = 0;

            ///
            /// \brief de-serialize an 8-bit unsigned integer
            ///
            /// \throw BufferUnderflow  there is not enough data in the buffer to deserialize an 8-bit unsigned integer
            ///
            /// \return de-serialized 8-bit unsigned integer value
            ///
            virtual uint8_t deserialize_uint8() = 0;

            ///
            /// \brief de-serialize a 16-bit integer
            ///
            /// \throw BufferUnderflow  there is not enough data in the buffer to deserialize a 16-bit integer
            ///
            /// \return de-serialized 16-bit integer value
            ///
            virtual int16_t deserialize_int16() = 0;

            ///
            /// \brief de-serialize a 16-bit unsigned integer
            ///
            /// \throw BufferUnderflow  there is not enough data in the buffer to deserialize a 16-bit unsigned integer
            ///
            /// \return de-serialized 16-bit unsigned integer value
            ///
            virtual uint16_t deserialize_uint16() = 0;

            ///
            /// \brief de-serialize a 32-bit integer
            ///
            /// \throw BufferUnderflow  there is not enough data in the buffer to deserialize a 32-bit integer
            ///
            /// \return de-serialized 32-bit integer value
            ///
            virtual int32_t deserialize_int32() = 0;

            ///
            /// \brief de-serialize a 32-bit unsigned integer
            ///
            /// \throw BufferUnderflow  there is not enough data in the buffer to deserialize a 32-bit unsigned integer
            ///
            /// \return de-serialized 32-bit unsigned integer value
            ///
            virtual uint32_t deserialize_uint32() = 0;

            ///
            /// \brief de-serialize a 64-bit integer
            ///
            /// \throw BufferUnderflow  there is not enough data in the buffer to deserialize a 64-bit integer
            ///
            /// \return de-serialized 64-bit integer value
            ///
            virtual int64_t deserialize_int64() = 0;

            ///
            /// \brief de-serialize a 64-bit unsigned integer
            ///
            /// \throw BufferUnderflow  there is not enough data in the buffer to deserialize a 64-bit unsigned integer
            ///
            /// \return de-serialized 64-bit unsigned integer value
            ///
            virtual uint64_t deserialize_uint64() = 0;

            ///
            /// \brief de-serialize a float
            ///
            /// \throw InvalidArgument  the length (of the float) stored in the buffer is zero
            /// \throw BufferOverflow   the length of the float is larger than the maximum temporary buffer size
            /// \throw BufferUnderflow  there is not enough data in the buffer to deserialize the float
            /// \throw SystemError      string conversion to float failed
            ///
            /// \return de-serialized float value
            ///
            virtual float deserialize_float() = 0;

            ///
            /// \brief de-serialize a double
            ///
            /// \throw InvalidArgument  the length (of the double) stored in the buffer is zero
            /// \throw BufferOverflow   the length of the double is larger than the maximum temporary buffer size
            /// \throw BufferUnderflow  there is not enough data in the buffer to deserialize the double
            /// \throw SystemError      string conversion to double failed
            ///
            /// \return de-serialized double value
            ///
            virtual double deserialize_double() = 0;

            ///
            /// \brief de-serialize a string
            ///
            /// \throw BufferUnderflow  there is not enough data in the buffer to deserialize the string
            ///
            /// \return de-serialized string value
            ///
            virtual std::string deserialize_string() = 0;

            ///
            /// \brief de-serialize raw data
            ///
            /// \param val Buffer where deserialized binary data deserialized will be stored
            ///
            /// \throw BufferUnderflow  there is not enough data in the buffer
            ///
            virtual void deserialize_binary(IBuffer &val) = 0;

            ///
            /// \brief de-serialize raw data
            ///
            /// \throw BufferUnderflow  there is not enough data in the buffer
            ///
            /// \return data value in Buffer
            ///
            virtual Buffer deserialize_binary() = 0;

            ///
            /// \brief de-serialize an object which implements ISerializable
            ///
            /// \param val object to de-serialize into
            /// 
            /// \throw BufferUnderflow  there is not enough data in the buffer
            ///
            virtual void deserialize(ISerializable &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_bool()
            ///
            /// \copydetails deserialize_bool()
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(bool &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_char()
            ///
            /// \copydetails deserialize_char()
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(char &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_int8()
            ///
            /// \copydetails deserialize_int8()
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(int8_t &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_uint8()
            ///
            /// \copydetails deserialize_uint8()
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(uint8_t &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_int16()
            ///
            /// \copydetails deserialize_int16()
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(int16_t &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_uint16()
            ///
            /// \copydetails deserialize_uint16()
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(uint16_t &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_int32()
            ///
            /// \copydetails deserialize_int32()
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(int32_t &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_uint32()
            ///
            /// \copydetails deserialize_uint32()
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(uint32_t &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_int64()
            ///
            /// \copydetails deserialize_int64()
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(int64_t &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_uint64()
            ///
            /// \copydetails deserialize_uint64()
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(uint64_t &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_float()
            ///
            /// \copydetails deserialize_float()
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(float &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_double()
            ///
            /// \copydetails deserialize_double()
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(double &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_string()
            ///
            /// \copydetails deserialize_string()
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(std::string &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize_binary(IBuffer &)
            ///
            /// \copydetails deserialize_binary(IBuffer &)
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(IBuffer &val) = 0;

            ///
            /// \brief Stream operator to \copybrief deserialize(ISerializable &)
            ///
            /// \copydetails deserialize(ISerializable &)
            ///
            /// \return reference to this IDeserializer
            ///
            virtual IDeserializer& operator>>(ISerializable &val) = 0;

            ///
            /// \brief return a pointer to the buffer
            ///
            /// The returned buffer is heap-allocated and must be freed by the caller when finished.
            ///
            /// \return pointer to buffer
            ///
            virtual const IBuffer *get_buffer() const = 0;

            ///
            /// \brief Get the current offset
            ///
            /// \return current offset
            ///
            virtual size_t get_offset() const = 0;

            ///
            /// \brief Update the offset value for de-serialization
            ///
            /// \param new_offset  the new offset
            ///
            virtual void set_offset(const size_t new_offset) = 0;

            ///
            /// \brief Reset the deserializer offset value
            ///
            /// Reset the offset to zero. It does not overwrite or free any data (capacity remains the same).
            ///
            virtual void reset() = 0;
        };
    }
}

#endif // NOS_ENGINE_UTILITY_SERIALIZATION_IDESERIALIZER_HPP
