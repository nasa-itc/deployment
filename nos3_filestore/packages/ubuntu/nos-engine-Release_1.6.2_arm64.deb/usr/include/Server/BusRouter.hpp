/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_BUS_ROUTER_HPP
#define NOS_ENGINE_SERVER_BUS_ROUTER_HPP

#include <Server/Types.hpp>
#include <Common/MessageRouter.hpp>

namespace NosEngine
{
	namespace Server
	{
		class NOS_ENGINE_SERVER_API_PUBLIC BusRouter :
            public Common::MessageRouter
		{
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the BusRouter class.
            /// 
            BusRouter(Bus* const bus, Common::ITransactionManager* const manager);

        private:
            BusRouter(const BusRouter&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the BusRouter class.
            /// 
            virtual ~BusRouter();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            BusRouter& operator=(const BusRouter&); //!< Disable the copy assignment operator.

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // BusRouter implementation
            // ------------------------------------------------------------------------------------

            virtual bool validate_message(const Common::Message& to_validate) const;

            virtual bool for_transaction_manager(const Common::Message& to_check) const;

            virtual bool message_is_new_transaction(const Common::Message& to_check) const;

			virtual Common::ITransaction* create_new_transaction(Common::Message& message, Common::WeakSendOperator send_interface);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

			Bus* const associated_bus;
		};
	}
}

#endif