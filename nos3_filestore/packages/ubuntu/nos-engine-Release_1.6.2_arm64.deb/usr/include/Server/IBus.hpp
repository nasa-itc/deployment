/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_IBUS_HPP
#define NOS_ENGINE_SERVER_IBUS_HPP

#include <string>

#include <Utility/States/IStoppable.hpp>

#include <Common/Bus/BusProtocol.hpp>

#include <Server/Types.hpp>

namespace NosEngine
{
    namespace Server
    {
        ///
        /// \brief Server-side representation of a bus.
        ///
        class IBus :
            public virtual Utility::IEngineThreadSafeObjectWithCV,
            public virtual Utility::States::IStoppable
        {
        public:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            typedef std::list<DataNode*> DataNodes;
            typedef std::list<InterceptorNode*> InterceptorNodes;
            typedef std::list<TimeClient*> TimeClientNodes;

            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IBus class.
            /// 
            virtual ~IBus() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the name of the bus.
            ///
            /// \return The name.
            ///
            virtual std::string get_name() const = 0;

            ///
            /// \brief Attempt registration of a new client
            ///
            /// \param message Registration message
            /// \param to_add  send operator to a client-side bus
            ///
            /// \return any flags that should be reported to the client
            ///
            virtual Common::BusRegistrationFlags register_client(const Common::Message& message, Common::WeakSendOperator transport_to_add) = 0;
            
            ///
            /// \brief Add a data node to the bus.
            ///
            /// \param name    name of the data node
            /// \param sender  send operator to send messages to the client-side node
            ///
            /// \return unique node ID for the new node
            ///
            /// \throw runtime_error  node with name already exists 
            ///
            virtual Common::NodeID add_data_node(const std::string& name, Common::WeakSendOperator sender) = 0;
            
            ///
            /// \brief Remove a data node from the bus by name.
            ///
            /// \param name  name of node to remove
            ///
            virtual void remove_data_node(const std::string& name) = 0;

            ///
            /// \brief Remove a data node from the bus by ID.
            ///
            /// \param id  the unique node ID of the node to remove
            ///
            virtual void remove_data_node(const Common::NodeID& id) = 0;

            ///
            /// \brief Get the data node by name
            ///
            /// \param name  name of the node
            ///
            /// \return pointer to the data node.
            ///
            virtual DataNode* find_data_node(const std::string& name) const = 0;

            ///
            /// \brief Get a list of all the data nodes.
            ///
            /// \return vector of data nodes on the bus
            ///
            virtual DataNodes get_all_data_nodes() const = 0;
            
            ///
            /// \brief Add an interceptor to the bus.
            ///
            /// \param to_add     name of new interceptor to add
            /// \param target     name of the target node
            /// \param direction  direction of interception (Outgoing or Incoming)
            /// \param sender     send operator to send messages to the client-side interceptor
            ///
            /// \return unique node ID for the new interceptor
            ///
            virtual Common::NodeID add_interceptor_node(const std::string& to_add, const std::string& target, Common::BusProtocol::InterceptorDirection direction, Common::WeakSendOperator sender) = 0;
            
            ///
            /// \brief Remove interceptor by name from the bus.
            ///
            /// \param name  name of the interceptor to remove
            ///
            virtual void remove_interceptor_node(const std::string& name) = 0;

			///
			/// \brief Get the interceptor node by name
            ///
			/// \param name  name of the node
            ///
			/// \return pointer to the interceptor node.
			///
            virtual InterceptorNode* find_interceptor_node(const std::string& name) const = 0;
            
			///
            /// \brief Add time node to the bus.
            ///
            /// \param to_add		name of the time node to add
            /// \param time_type	they type of node (Sender or Client)
            /// \param sender		send operator to send messages to the client side node
            ///
            /// \return unique node ID for the new time node
			///
            virtual Common::NodeID add_time_node(const std::string& to_add, Common::BusProtocol::TimeNodeType time_type, Common::WeakSendOperator sender) = 0;

            ///
            /// \brief Remove time node by name from the bus.
            ///
            /// \param name         name of the time node to remove
            /// \param time_type    the expected type of the time node being removed.
            ///
            virtual void remove_time_node(const std::string& name, Common::BusProtocol::TimeNodeType time_type) = 0;

            ///
            /// \brief Remove time client by name from the bus.
            ///
            /// \param name name of the time client to remove
            ///
            virtual void remove_time_client(const std::string& name) = 0;

            ///
            /// \brief Remove time sender by name from the bus.
            ///
            /// \param name name of the time sender to remove
            ///
            virtual void remove_time_sender(const std::string& name) = 0;

            ///
            /// \brief Get a list of all the time clients.
            ///
            /// \return vector of time clients on the bus
            ///
            virtual TimeClientNodes get_all_time_clients() const = 0;

            ///
            /// \brief Get the time sender.
            ///
            /// \return the time sender for the bus
            ///
            virtual TimeSender* get_time_sender() const = 0;

			// TODO: Revisit these methods
            //virtual void send_message(Common::Message to_send) = 0;
            //virtual void broadcast_message(Common::Message to_broadcast) = 0;
            //virtual Common::SimTime get_time() = 0;

            ///
            /// \brief Get the message router for the bus.
            ///
            /// \return pointer to the bus message router. Bus retains ownership.
            ///
            virtual Common::IMessageRouter* get_router() const = 0;

            ///
            /// \brief Get the string representation of the bus.
            ///
            /// \return protocol in string form
            ///
            virtual std::string get_protocol() const = 0;

            ///
            /// \brief Process a protocol query.
            ///
            /// \param query    The Message which contains the query to process.
            /// \param response The response to the query.
            ///
            /// \throw Utility::Error::NotImplemented if base class implementation is called.
            ///
            virtual void process_query(const Common::Message& query, Common::Message& response) const = 0;
        };           
    }
}

#endif