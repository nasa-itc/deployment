/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_NODE_HPP
#define NOS_ENGINE_CLIENT_NODE_HPP

#include <string>
#include <stdint.h>

#include <Utility/Queue.hpp>
#include <Utility/States/Stoppable.hpp>

#include <Client/types.hpp>
#include <Client/Globals.hpp>
#include <Client/INode.hpp>

namespace NosEngine
{
    namespace Client
    {
        ///
        /// \copydoc INode
        ///
        class NOS_ENGINE_CLIENT_API_PUBLIC Node :
            public virtual INode,
            public Utility::States::Stoppable
        {
        private:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            typedef std::function<void(Common::Message, std::unique_lock<std::mutex> &)> MessageReceivedFunctionForQueue;
            typedef std::list<MessageReceivedFunctionForQueue> MessageReceivedCallbackQueue;
            typedef std::list<Common::Message> MessageReceivedQueue;

        protected:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Instantiate a node.
            ///
            /// \param name                name of the node
            /// \param bus                 bus the node belongs to
            /// \param id                  unique node ID
            /// \param transaction_manager transaction manager for handling node transactions
            /// \param weak_send_operator  weak_send_operator to send messages to server
            ///
            Node(const std::string& name,
                 IBus &bus,
                 const Common::NodeID &id,
                 Common::ITransactionManager *transaction_manager,
                 const Common::WeakSendOperator &weak_send_operator);

        private:
            Node(const Node&); //!< Disable the copy constructor.

        public:
            ///
            /// \brief Destructor for an instance of the Node class.
            ///
            virtual ~Node();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            Node& operator=(const Node&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // INode implementation
            // ------------------------------------------------------------------------------------

            virtual IBus &get_bus() const;

            virtual std::string get_name() const;

            virtual Common::NodeID get_id() const;

            virtual void set_message_received_callback(const MessageReceivedFunction callback);

            virtual MessageReceivedFunction get_message_received_callback() const;

        protected:
            virtual void send_non_confirmed_message_async(const std::string& destination, size_t length, const char * const data) const;

            virtual void send_confirmed_message_blocking(std::string destination, size_t length, const char * const data, const size_t timeout = SEND_INFINITE_TIMEOUT) const;

            virtual void send_complete_confirmed_message_blocking(Common::Message message, const size_t timeout = SEND_INFINITE_TIMEOUT) const;

            virtual Common::TransactionID send_confirmed_message_async(std::string destination, size_t length, const char * const data, const ConfirmationFunction confirm_callback) const;

            virtual Common::Message send_request_message_blocking(const std::string& destination, size_t length, const char * const data, const size_t timeout = SEND_INFINITE_TIMEOUT) const;

            virtual Common::TransactionID send_request_message_async(const std::string& destination, size_t length, const char * const data, const ReplyReceivedFunction reply_callback) const;

            virtual void send_reply_message_async(const Common::Message& original, size_t length, const char * const data) const;

            virtual void send_complete_reply_message_async(Common::Message message) const;

            virtual Common::Message receive_message_blocking(const size_t timeout = RECEIVE_INFINITE_TIMEOUT);

        public:
            virtual Common::SimTime get_time() const;

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Build a data message.
            ///
            /// \param destination  The name of the destination node.
            /// \param length       The length of the data.
            /// \param data         The data for the message.
            ///
            /// \return The data message.
            ///
            Common::Message build_message(const std::string& destination, size_t length, const char * const data) const;

        protected:
            ///
            /// \brief Called when a Message is received.
            ///
            /// \param message The message that was received.
            ///
            virtual void message_received(Common::Message message);

            // ------------------------------------------------------------------------------------
            // INode (IEngineThreadSafeObjectWithCV) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

            virtual std::condition_variable &get_cv() const;

            // ------------------------------------------------------------------------------------
            // Stoppable implementation
            // ------------------------------------------------------------------------------------

            virtual bool is_stopping_no_lock() const;

            virtual void set_stopping_no_lock(const bool &stopping);

            virtual bool is_stopped_no_lock() const;

            virtual void set_stopped_no_lock(const bool &stopped);

            virtual void process_stop(std::unique_lock<std::mutex> &lock);

        public:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- configuration ----
            const std::string name;  //!< The name of the Node.
            const Common::NodeID id; //!< The id of the Node.

        protected:
            // ---- thread syncronization ----
            mutable std::mutex mutex;
            mutable std::condition_variable cond;

            // ---- configuration ----
            IBus &bus;
            Common::ITransactionManager* const transaction_manager;
            const Common::WeakSendOperator weak_send_operator;

            // ---- status ----
            bool stopping;
            bool stopped;

        private:
            // ---- async receive ----
            MessageReceivedFunction user_message_received_callback;    //!< User message received callback; may be nullptr
            MessageReceivedFunctionForQueue message_received_callback; //!< Internal message received callback
            MessageReceivedCallbackQueue message_callback_queue;       //!< Incoming message callback queue

            // ---- receive ----
            MessageReceivedQueue message_queue;                        //!< Incoming message queue (used when callback isn't set)

            //TODO: Remove and formalize this
            friend class NodeTransaction;
        };
    }
}

#endif
