/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_RECEIVER_OPERATOR_HPP
#define NOS_ENGINE_COMMON_RECEIVER_OPERATOR_HPP

#include <thread>
#include <mutex>

#include <Common/types.hpp>
#include <Common/IReceiveOperator.hpp>
#include <Common/IMessageConnection.hpp>
#include <Utility/States/Stoppable.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \copydoc IReceiveOperator
        ///
        class NOS_ENGINE_COMMON_API_PUBLIC ReceiveOperator :
            public IReceiveOperator,
            public Utility::States::Stoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Instantiates a background thread to pull messages from the 
            /// message connection and run message routing.
            ///
            /// \param to_receive_on  message connection from which to pull messages
            /// \param router         where to route messages
            /// \param sender         complimentary sender to the to_receive_on message connection (passed to the router)
            ///
            ReceiveOperator(std::shared_ptr<IMessageConnection> to_receive_on, IMessageRouter& router, WeakSendOperator sender);

        private:
            ReceiveOperator(const ReceiveOperator&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the ReceiveOperator class.
            /// 
            ~ReceiveOperator();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            ReceiveOperator &operator=(const ReceiveOperator&); //!< Disable the copy assignment operator.

        public:
            // ------------------------------------------------------------------------------------
            // IReceiveOperator implementation
            // ------------------------------------------------------------------------------------

            virtual TransportID get_transport_id() const;

            virtual size_t get_receive_count() const;

            virtual size_t get_receive_completed_count() const;

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Check the underlying connection to see if it's still connected.
            ///
            /// When not connected internal counter(s) are updated so that a failed receive is
            /// accounted for.
            ///
            /// \return A value indicating if the connection is connected.
            ///
            bool check_connection();

            ///
            /// \brief Callback method that is executed when a message is received or an error
            /// occurs during a receive.
            ///
            /// \param message The message that was received.
            /// \param error An error which occured during receiving (or success error).
            ///
            void message_received(Common::Message &message, const Utility::Error::Error &error);

        protected:
            // ------------------------------------------------------------------------------------
            // IReceiveOperator (IEngineThreadSafeObjectWithCV) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

            virtual std::condition_variable &get_cv() const;

            // ------------------------------------------------------------------------------------
            // Stoppable implementation
            // ------------------------------------------------------------------------------------

            virtual bool is_stopping_no_lock() const;

            virtual void set_stopping_no_lock(const bool &stopping);

            virtual bool is_stopped_no_lock() const;

            virtual void set_stopped_no_lock(const bool &stopped);

            virtual void process_stop(std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- thread syncronization ----
            mutable std::mutex mutex;
            mutable std::condition_variable cond;

            // ---- callbacks ----
            ReceiveMessageCallback message_received_cb;             //!< \see message_received(Common::Message, const Utility::Error::Error &)

            // ---- configuration ----
            std::shared_ptr<IMessageConnection> message_connection; //!< message connection from which to pull messages
            IMessageRouter& router;                                 //!< message rounter to route receives message through
            WeakSendOperator sender;                                //!< send operator paired with this receive operator
            
            // ---- counters ----
            size_t receive_count;                                   //!< number of receive operations initiated
            size_t receive_complete_count;                          //!< number of receive operations completed

            // ---- status ----
            bool stopping;                                          //!< value indicating if this operator is stopping
            bool stopped;                                           //!< value indicating if this operator is stopped
        };
    }
}

#endif