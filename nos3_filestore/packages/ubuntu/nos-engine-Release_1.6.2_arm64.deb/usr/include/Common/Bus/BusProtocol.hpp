/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/
#ifndef NOS_ENGINE_COMMON_BUS_PROTOCOL_HPP
#define NOS_ENGINE_COMMON_BUS_PROTOCOL_HPP

#include <Utility/Buffer.hpp>

#include "Common/Protocol.hpp"
#include <Common/types.hpp>

namespace NosEngine
{
    namespace Common
    {
		namespace BusProtocol
		{

            ///
            /// \brief Available commands for bus operations
            ///
			enum class CommandType : uint8_t
			{
				Command_Invalid,  //!< Indicates invalid value
				BusRegister,      //!< Command to register a bus
				NodeRegister,     //!< Command to register a node
				NodeRemoval,      //!< Command to de-register a node
                Protocol,
				COMMAND_END       //!< Indicates end of enum
			};
			
            ///
            /// \brief Types of nodes that can be registered
            ///
            enum class NodeType : uint8_t
			{
				Node_Invalid,     //!< Indicates invalid value
				Data,             //!< A Data-type node
				Interceptor,      //!< An Interceptor-type node
                TimeSender,       //!< A TimeSender-type node
                TimeClient,       //!< A TimeClient-type node
				NODE_END          //!< Indicates end of enum
			};

            ///
            /// \brief Indicates whether interceptor captures outgoing or incoming messages
            ///
            enum class InterceptorDirection : uint8_t
			{
				Direction_Invalid, //!< Indicates invalid value
				Outgoing,          //!< capture outgoing messages
				Incoming,          //!< capture incoming messages
				DIRECTION_END      //!< Indicates end of enum
			};
            
            enum class TimeNodeType : uint8_t
            {
                TimeType_Invalid, //!< Indicates invalid value
                Sender,           //!< time sender
                Client,           //!< time client
                TIME_TYPE_END     //!< Indicates end of enum
            };

            ///
            /// \brief Indicates the return status of a command
            ///
            enum class CommandResult : uint8_t
			{
				Result_Invalid,   //!< Indicates invalid value
				Success,          //!< command succeeded
				Failure,          //!< command failed
				Result_END        //!< Indicates end of enum
			};

            enum RegistrationFlags
            {
                NoServerProtocol = 1,
                RegistrationFlags_END
            };
            
            extern const size_t NOS_ENGINE_COMMON_API_PUBLIC ProtocolDataStart;
            extern const size_t NOS_ENGINE_COMMON_API_PUBLIC ProtocolResponseStart;
			
            ///
            /// \brief Unpack the command field from a buffer.
            ///
            /// \param buffer  the source buffer
            ///
            /// \return the query command
            ///
			CommandType NOS_ENGINE_COMMON_API_PUBLIC get_command(const Utility::Buffer& buffer);

            ///
            /// \brief Pack a query command into a buffer.
            ///
            /// \param buffer   destination buffer
            /// \param command  command to pack into buffer
            ///
			void NOS_ENGINE_COMMON_API_PUBLIC set_command(Utility::Buffer& buffer, const CommandType& command);

            ///
            /// \brief Unpack the node type from a buffer
            ///
            /// \param buffer  source buffer
            ///
            /// \return node type
            ///
			NodeType NOS_ENGINE_COMMON_API_PUBLIC get_node_type(const Utility::Buffer& buffer);

            ///
            /// \brief Pack a node type into a buffer
            ///
            /// \param buffer     destination buffer
            /// \param node_type  type to pack into buffer
            ///
			void NOS_ENGINE_COMMON_API_PUBLIC set_node_type(Utility::Buffer& buffer, const NodeType& node_type);

            ///
            /// \brief Unpack the node target from a buffer
            ///
            /// \param buffer  source buffer
            ///
            /// \return node target name
            ///
			std::string NOS_ENGINE_COMMON_API_PUBLIC get_target(const Utility::Buffer& buffer);

            ///
            /// \brief Pack a node target name into a buffer
            ///
            /// \param buffer  destination buffer
            /// \param target  name of target node
            ///
			void NOS_ENGINE_COMMON_API_PUBLIC set_target(Utility::Buffer& buffer, const std::string& target);

            ///
            /// \brief Unpack the interceptor direction from a buffer
            ///
            /// \param buffer  source buffer
            ///
            /// \return the interceptor direction
            ///
			InterceptorDirection NOS_ENGINE_COMMON_API_PUBLIC get_interceptor_direction(const Utility::Buffer& buffer);
			
            ///
            /// \brief Pack the interceptor direction into a buffer
            ///
            /// \param buffer     destination buffer
            /// \param direction  interceptor direction
            ///
            void NOS_ENGINE_COMMON_API_PUBLIC set_interceptor_direction(Utility::Buffer& buffer, const InterceptorDirection& direction);
    	   
            TimeNodeType NOS_ENGINE_COMMON_API_PUBLIC get_time_type(const Utility::Buffer& buffer);
            
            void NOS_ENGINE_COMMON_API_PUBLIC set_time_type(Utility::Buffer& buffer, const TimeNodeType& time_type);

            ///
            /// \brief Unpack the command result from a buffer
            ///
            /// \param buffer  source buffer
            ///
            /// \return the command result
            ///
			CommandResult NOS_ENGINE_COMMON_API_PUBLIC get_command_result(const Utility::Buffer& buffer);

            ///
            /// \brief Pack the command result into a buffer
            ///
            /// \param buffer  destination buffer
            /// \param result  command result to pack into buffer
            ///
			void NOS_ENGINE_COMMON_API_PUBLIC set_command_result(Utility::Buffer& buffer, const CommandResult& result);

            ///
            /// \brief Unpack the node ID into a buffer
            ///
            /// \param buffer  source buffer
            ///
            /// \return the node ID
            ///
			NodeID NOS_ENGINE_COMMON_API_PUBLIC get_id_result(const Utility::Buffer& buffer);

            ///
            /// \brief Pack the node ID into a buffer
            ///
            /// \param buffer  destination buffer
            /// \param id      the node ID
            ///
			void NOS_ENGINE_COMMON_API_PUBLIC set_id_result(Utility::Buffer& buffer, const NodeID& id);

            ///
            /// \brief Unpack any required registration flags
            /// 
            /// \param buffer source buffer
            /// 
            /// \return the registration flags
            ///
            BusRegistrationFlags NOS_ENGINE_COMMON_API_PUBLIC  get_registration_flags(const Utility::Buffer& buffer);

            
            ///
            /// \brief Pack registration flags
            /// 
            /// \param destination buffer
            /// \param flags
            ///
            void NOS_ENGINE_COMMON_API_PUBLIC set_registration_flags(Utility::Buffer& buffer, const Common::BusRegistrationFlags& flags);
            
			///
            /// \brief Create the appropriate response Message.
            ///
            /// \param  original the initial Message
            /// \param  result the command result
            ///
            /// \return pre-filled response Message
			///
            Message NOS_ENGINE_COMMON_API_PUBLIC create_response(const Common::Message& original, const CommandResult &result);
		}
        
    }
}


#endif
