/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_IMESSAGE_HPP
#define NOS_ENGINE_COMMON_IMESSAGE_HPP

#include <Utility/Buffer.hpp>

#include <Common/types.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \brief Represents the fundamental data structure that is sent throughout NOS Engine
        ///
        /// The Message class contains header information needed for processing and routing messages,
        /// as well as the variable payload data specific to a particular type of message.
        ///
        /// To discourage wasteful copying, the copy constructor and assignment constructor have been
        /// disabled. Move semantics should be used as much as possible for sake of efficiency.
        /// If a duplicate is truly needed, the Message::clone() const function can be used.
        ///
        class IMessage :
            public virtual Utility::IEngineObject
        {
		public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the Message class.
            /// 
            ~IMessage() {}

        public:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            // TODO
            //virtual bool operator==(const IMessage& other) const = 0;
            //virtual bool operator!=(const IMessage& other) const = 0;

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // TODO
            //virtual void copy_from(const IMessage &message) = 0;

            ///
            /// \brief Get the TransactionID of the Message.
            ///
            /// \return TransactionID of the Message
            ///
            virtual TransactionID get_transaction_id() const = 0;

            ///
            /// \brief Set the TransactionID of the Message.
            ///
            /// \param id  new TransactionID value for the Message
            ///
            virtual void set_transaction_id(const TransactionID id) = 0;

            // TODO
            //virtual MessagePrimaryHeader &get_primary_header() = 0;
            //virtual void set_primary_header(const MessagePrimaryHeader &header) = 0;
            //virtual const MessagePrimaryHeader &get_primary_header() const = 0;
            //virtual Utility::Buffer &get_buffer() = 0;
            //virtual void set_buffer(const Utility::Buffer &buffer) = 0;
            //virtual const Utility::Buffer &get_buffer() const = 0;

            ///
            /// \brief Get the serialized size of the message.
            ///
            virtual size_t get_serialized_size() const = 0;

            ///
            /// \brief Serialize this Message into a Buffer.
            ///
            /// Per convention, the serialized message is not byte-swapped for send.
            ///
            /// \param local_endian  Local endianness
            /// \param remote_endian Remote endianness
            ///
            virtual Utility::Buffer serialize() const = 0;

            ///
            /// \brief Serialize this Message into a user provided Buffer.
            ///
            /// Per convention, the serialized message is not byte-swapped for send.
            ///
            /// The Buffer must be large enough to contain the serialized Message.
            ///
            /// \param message_buffer Destination buffer
            /// \param local_endian   Local endianness
            /// \param remote_endian  Remote endianness
            ///
            virtual void serialize(Utility::Buffer *message_buffer) const = 0;

            ///
            /// \brief Deserialize a Buffer into this Message.
            ///
            /// \param message_buffer Source buffer
            /// \param local_endian   Local endianness
            /// \param remote_endian  Remote endianness
            ///
            virtual void deserialize(const Utility::Buffer *const message_buffer, const Utility::Endian::Endian local_endian, const Utility::Endian::Endian remote_endian) = 0;
        };
    }
}

#endif
