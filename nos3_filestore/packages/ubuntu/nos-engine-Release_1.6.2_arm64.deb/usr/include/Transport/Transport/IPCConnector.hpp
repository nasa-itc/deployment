/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_IPC_CONNECTOR_HPP
#define NOS_ENGINE_TRANSPORT_IPC_CONNECTOR_HPP

#include <ItcIpc/MessageQueue/Client.hpp>

#include <Utility/IWorkHub.hpp>

#include <Transport/Types.hpp>
#include <Transport/Connector.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \brief Represents a client which makes connection requests to a server for
        /// the interprocess communication transport.
        ///
        /// \see IPCAcceptor
        /// \see IPCConnection
        ///
        class NOS_ENGINE_TRANSPORT_API_PUBLIC IPCConnector :
            public Connector
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct and instance of the IPCConnector class.
            /// 
            /// \param uri      The URI which the Connector will connect to.
            /// \param work_hub The work hub to use for performing asyncronous work.
            /// 
            IPCConnector(const URI &uri, Utility::IWorkHub &work_hub);

        private:
            IPCConnector(const IPCConnector&);  //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the CopyConnector class.
            /// 
            virtual ~IPCConnector();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            IPCConnector& operator=(const IPCConnector&); //!< Disable the copy assignment operator.

            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Called by IPC connect worker thread.
            ///
            void ipc_connect_work();

        protected:
            // ------------------------------------------------------------------------------------
            // Connector overrides
            // ------------------------------------------------------------------------------------

            virtual void process_connector_stop(std::unique_lock<std::mutex> &lock);

			virtual void process_connect(const size_t attempt_timeout, std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- threading ----
            std::thread ipc_connect_thread; //!< The connect worker thread.

            // ---- thread syncronization ----
            std::condition_variable ipc_cv;

            // ---- timeouts ----
			size_t attempt_timeout;         //!< The timeout for the current connect attempt.
        };
    }
}

#endif

