/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_LOGGER_GLOBAL_LOGGER_HPP
#define ITC_LOGGER_GLOBAL_LOGGER_HPP

#include <itc_common_config.hpp>
#include <itc_visibility.hpp>
#include <ItcUtil/ItcFormatGuard.hpp>

#include <ItcLogger/Types.hpp>
#include <ItcLogger/Logger.hpp>

namespace ItcLogger
{
    /**
        \brief Represents a logger instance that will be used globally.

        See \ref Logger.

        The GlobalLogger class was created because of loader lock issues encountered
        on some platforms (when using CXX11).  When loading, the std::mutex class isn't
        fully initialized; so a lock can't be obtained (ie deadlock occurs during load).
        This class solves this problem by defering initialization until it is used.
    */
    class DLL_PUBLIC GlobalLogger
    {
    public:
        /**
            \brief GlobalLogger constructor.

            See \ref Logger::Logger.
            See also \ref Logger::get.

            \param name  Unique name of the logger
        */
        GlobalLogger(const char *name);
        
        /**
            \brief Copy constructor.
        */
        GlobalLogger(const GlobalLogger &other);

        /**
            \brief GlobalLogger destructor.

            See \ref Logger::~Logger.
        */
        ~GlobalLogger();
        
        /**
            \brief Assignment operator.
        */
        GlobalLogger &operator=(const GlobalLogger &other);

#ifdef ITC_COMMON_CXX11

        /**
            \brief Move constructor.
        */
        GlobalLogger(GlobalLogger &&other);
            
        /**
            \brief Move operator.
        */
		GlobalLogger& operator=(GlobalLogger &&other);

#endif

        /**
            \brief See \ref Logger::configure.
        */
        static void configure(const char *filename) throw(BadConfFile);
        
        /**
            \brief See \ref Logger::add_target.
        */
        void add_target(const TargetPtr &tgt) throw();
        
        /**
            \brief See \ref Logger::remove_target.
        */
        void remove_target(const TargetPtr &tgt) throw();
        
        /**
            \brief See \ref Logger::get_targets.
        */
        const Logger::TargetList get_targets() throw();
        
        /**
            \brief See \ref Logger::get_all_targets.
        */
        const Logger::TargetList get_all_targets() throw();
        
        /**
            \brief See \ref Logger::get_child_logger.

            \return Child global logger instance
        */
        GlobalLogger get_child_logger(const char *child_name);
        
        /**
            \brief See \ref Logger::is_level_enabled.

            \return TRUE if the log level is enabled
            \return FALSE if the log level is disabled
        */
        bool is_level_enabled(const log_level_t &log_level) throw();
        
        /**
            \brief See \ref Logger::set_level.
        */
        void set_level(const log_level_t &new_level) throw();
        
        /**
            \brief See \ref Logger::reset_level.
        */
        void reset_level() throw();
        
        /**
            \brief See \ref Logger::get_level.
            
            \return Current log level
        */
        log_level_t get_level() throw();
        
        /**
            \brief See \ref Logger::log(const log_level_t &log_level, const char *fmt, ...).
        */
        ITC_FORMAT_GUARD(3,4)
        void log(const log_level_t &log_level, const char *fmt, ...);
        
        /**
            \brief See \ref Logger::trace(const char *fmt, ...).
        */
        ITC_FORMAT_GUARD(2,3)
        void trace(const char *fmt, ...);
        
        /**
            \brief See \ref Logger::debug(const char *fmt, ...).
        */
        ITC_FORMAT_GUARD(2,3)
        void debug(const char *fmt, ...);
        
        /**
            \brief See \ref Logger::info(const char *fmt, ...).
        */
        ITC_FORMAT_GUARD(2,3)
        void info(const char *fmt, ...);
        
        /**
            \brief See \ref Logger::warning(const char *fmt, ...).
        */
        ITC_FORMAT_GUARD(2,3)
        void warning(const char *fmt, ...);
        
        /**
            \brief See \ref Logger::error(const char *fmt, ...).
        */
        ITC_FORMAT_GUARD(2,3)
        void error(const char *fmt, ...);
        
        /**
            \brief See \ref Logger::fatal(const char *fmt, ...).
        */
        ITC_FORMAT_GUARD(2,3)
        void fatal(const char *fmt, ...);
        
        /**
            \brief See \ref Logger::log(const log_level_t &log_level).

            \return Output stream.
        */
        LoggerOutputStream log(const log_level_t &log_level);
        
        /**
            \brief See \ref Logger::trace().

            \return Output stream.
        */
        LoggerOutputStream trace();
        
        /**
            \brief See \ref Logger::debug().

            \return Output stream.
        */
        LoggerOutputStream debug();
        
        /**
            \brief See \ref Logger::info().

            \return Output stream.
        */
        LoggerOutputStream info();
        
        /**
            \brief See \ref Logger::warning().

            \return Output stream.
        */
        LoggerOutputStream warning();
        
        /**
            \brief See \ref Logger::error().

            \return Output stream.
        */
        LoggerOutputStream error();
        
        /**
            \brief See \ref Logger::fatal().

            \return Output stream.
        */
        LoggerOutputStream fatal();
        
        /**
            \brief See \ref Logger::set_buffer_size.
        */
        void set_buffer_size(const unsigned int &new_size) throw(std::bad_alloc);
        
        /**
            \brief See \ref Logger::get_buffer_size.
            
            \return Current buffer size.
        */
        unsigned int get_buffer_size() throw();
        
        /**
            \brief Get the underlying \ref Logger instance.
            
            \return The \ref Logger instance.
        */
        Logger *get_logger();

        /**
            \brief Get the unique name of the logger.

            \return Unique logger name.
        */
        const std::string &get_name() const;

    protected:
        /**
            \brief Initialize the underlying logger instance.
        */
        void init();
        
        boost::mutex mutex; //!< Logger init mutex
        std::string name;   //!< Unique logger name
        Logger *logger;     //!< Underlying logger instance
    };
}

#endif