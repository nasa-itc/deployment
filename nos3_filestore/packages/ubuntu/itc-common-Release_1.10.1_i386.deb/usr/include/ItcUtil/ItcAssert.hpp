/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef __itc_assert_HPP
#define __itc_assert_HPP

#include "ItcUtil/config.hpp"
#include <assert.h>
#include <exception>
#include <string>

#define ASSERTION_MESSAGE_LIMIT 4096

/* cost: relatively a lot! :) */
#define STRINGY(x) #x
#define _STRINGY(x) STRINGY(x)

#define itc_assert(cond, err_str, ...) do { if(!(cond)) ItcUtil::itc_assert_(__FILE__ ":" _STRINGY(__LINE__) " (" #cond ")", err_str, ##__VA_ARGS__); } while(0)
#define itc_assert0(cond, err_str) do { if(!(cond)) ItcUtil::itc_assert_(__FILE__ ":" _STRINGY(__LINE__) " (" #cond ")", err_str); } while(0)


namespace ItcUtil
{
    class DLL_PUBLIC FailedAssertionException
    {
    public:
        explicit FailedAssertionException();
        virtual const char *what() const throw();
        virtual ~FailedAssertionException() throw();

        char message[ASSERTION_MESSAGE_LIMIT];
    };

#ifdef NDEBUG
    ITC_NO_RETURN DLL_PUBLIC void itc_assert_(const char *cond_str, const char *str ...) throw(FailedAssertionException);
#else
	ITC_NO_RETURN DLL_PUBLIC void itc_assert_(const char *cond_str, const char *str ...);
#endif
}

#endif
