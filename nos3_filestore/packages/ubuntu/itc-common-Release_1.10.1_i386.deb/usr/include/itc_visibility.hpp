/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#include <itc_common_config.hpp>

#undef DLL_PUBLIC
#undef DLL_PRIVATE

#if defined(__BUILDING_ITC__)
#  if defined(WIN32) || defined(_WIN32) || defined(__WIN32) || defined(__WIN32__)
#    pragma deprecated ("__BUILDING_ITC__")
#  else
#    warning DEPRECATED: __BUILDING_ITC__ is now deprecated. Please use BUILDING__ITC__ instead.
#  endif
#endif

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) || defined(__WIN32__)
#  if defined(__BUILDING_ITC__) || defined(BUILDING__ITC__)
#    ifndef BUILDING__ITC__STATIC
#      ifdef __GNUC__
#        define DLL_PUBLIC __attribute__((dllexport))
#      else
#        define DLL_PUBLIC __declspec(dllexport)
#      endif
#    else
#        define DLL_PUBLIC
#    endif
#  else
#    ifndef BUILDING__ITC__STATIC
#      ifdef __GNUC__
#        define DLL_PUBLIC __attribute__((dllimport))
#      else
#        define DLL_PUBLIC __declspec(dllimport)
#      endif
#    else
#        define DLL_PUBLIC
#    endif
#  endif

#  define DLL_PRIVATE
#  define ITC_NO_RETURN __declspec(noreturn)
#elif defined(__GNUC__)
#    define ITC_NO_RETURN __attribute__((noreturn))

#    if __GNUC__ >= 4
#      define DLL_PUBLIC __attribute__((visibility("default")))
#      define DLL_PRIVATE __attribute__((visibility("hidden")))
#    else
#      define DLL_PUBLIC
#      define DLL_PRIVATE
#    endif
#else
  #error check me out
#endif
