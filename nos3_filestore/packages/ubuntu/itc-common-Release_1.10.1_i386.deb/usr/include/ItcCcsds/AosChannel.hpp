/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_CCSDS_AOS_CHANNEL_HPP
#define ITC_CCSDS_AOS_CHANNEL_HPP

#include <boost/noncopyable.hpp>

#include <itc_visibility.hpp>

#include <ItcCcsds/NoSuchTrailer.hpp>
#include <ItcCcsds/Types.hpp>

namespace ItcCcsds
{
    /**
        \brief Defines configurable parameters of an AOS channel

        According to the AOS specification, several parameters are established by
        management and will not change during the lifetime of a mission.  Such parameters
        include:
           - AOS frame size
           - Whether or not the AOS primary header contains an 'header error control' field
           - Whether or not an insert zone is used, and, if so, its size
           - The data type of the channel (M_PDU vs B_PDU)
           - Any data trailer(s)

        These parameters are provided by the user as parameters to the constructor of this
        class.
    */
    class DLL_PUBLIC AosChannel : private boost::noncopyable
    {
    public:
        /**
            \brief Instantiates an AOS channel.

            \param frameSize                   Size of each AOS frame
            \param containsHeaderErrorControl  Whether or not the primary header contains
                                                   the 'header error control' field
            \param insertZoneSize              Size of the insert zone, or 0 if not used
            \param dataType                    Data type contained in the AOS frame
            \param trailerType                 Trailer type(s)
        */
        AosChannel(unsigned int frameSize,
                   bool containsHeaderErrorControl,
                   unsigned int insertZoneSize,
                   TransferFrameType dataType,
                   TransferFrameTrailerType trailerType);

        /**
            \brief Default destructor
        */
        ~AosChannel();

        /**
            \brief Retrieve the size of the primary header

            \return Size of the primary header, in bytes
        */
        unsigned int get_header_size();

        /**
            \brief Retrieve the offset from the start of the frame to the
            start of the data field

            \return Offset from the start of the frame to the start of the data field
         */
        unsigned int get_data_field_offset();

        /**
            \brief Retrieve the size available for data in the AOS frame

            Note that this value does NOT include the size of the M_PDU or B_PDU
            header located at the start of the data field.

            \return Size of the transfer frame data field
        */
        unsigned int get_data_field_size();

        /**
            \brief Retrieve the offset from the start of the frame to the start
            of the operational control trailer.

            \return Offset from the start of the frame to the start of the
            operational control trailer

            \throw NoSuchTrailer if the AOS frame was not created with an operational
            control trailer enabled
         */
        unsigned int get_op_control_trailer_field_offset() throw(NoSuchTrailer);

        /**
            \brief Retrieve the offset from the start of the frame to the start
            of the error control trailer.

            \return Offset from the start of the frame to the start of the
            error control trailer

            \throw NoSuchTrailer if the AOS frame was not created with an error
            control trailer enabled
         */
        unsigned int get_error_control_trailer_field_offset() throw(NoSuchTrailer);

        const unsigned int frameSize;                //!< Frame size
        const bool containsHeaderErrorControl;       //!< Whether or not the primary header contains an error control field
        const unsigned int insertZoneSize;           //!< Size of the insert zone
        const TransferFrameType dataType;            //!< Data type for this channel
        const TransferFrameTrailerType trailerType;  //!< Trailer type for this channel
    };
}

#endif /* ITC_CCSDS_AOS_CHANNEL_HPP */
