/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_LOADER_HPP
#define ITC_LOADER_HPP

#include <map>

#include <itc_visibility.hpp>

#include <ItcLoader/Config.hpp>
#include <ItcLoader/CouldNotLoad.hpp>
#include <ItcLoader/NoSuchSymbol.hpp>

namespace ItcLoader
{
    struct LoaderData;  //!< Forward declaration of pimpl data structure

    /**
        \brief Platform-independent dynamic library loader.

        This class may be used to load functions and/or data from dynamically-
        loaded libraries.
    */
    class DLL_PUBLIC Loader
    {
    public:
        /**
            \brief Loads a dynamic library.

            Calls the appropriate OS library (LoadLibrary, dlopen, etc.).  Library
            names are prepended and appended platform-specific characters before
            passing to OS primitives.  For example, on Windows, the ".dll" string is
            appended, while on Linux, "lib" is prepended and ".so" is appended.  This
            allows users of this library to utilize a single common cross-platform
            library naming convention.

            After the library name is updated with platform-specific transformation,
            the string name is passed to OS calls for location of the library.  Each
            platform may use different methods to actually locate the library.

            \param libname  Platform-independent library name.  May not be NULL.

            \throw CouldNotLoad  Library couldn't be found, or one or more
            dependencies could not be satisfied when loading the library
         */
        Loader(const char *const libname) throw(CouldNotLoad);

        /**
            \brief Loads a dynamic library.

            Calls the appropriate OS library (LoadLibrary, dlopen, etc.).  Library
            names are prepended and appended platform-specific characters before
            passing to OS primitives.  For example, on Windows, the ".dll" string is
            appended, while on Linux, "lib" is prepended and ".so" is appended.  This
            allows users of this library to utilize a single common cross-platform
            library naming convention.

            After the library name is updated with platform-specific transformation,
            the string name is passed to OS calls for location of the library.  Each
            platform may use different methods to actually locate the library.

            \param path     Path to prepend to all platform-specific transformations
                               May not be NULL.
            \param libname  Platform-independent library name.  May not be NULL.

            \throw CouldNotLoad  Library couldn't be found, or one or more
            dependencies could not be satisfied when loading the library
         */
        Loader(const char *const path, const char *const libname) throw(CouldNotLoad);

        /**
            \brief Unloads a dynamic library.

            Calls the appropriate OS library (FreeLibrary, dlclose, etc.) to free
            the existing library.  Any OS errors are ignored.

            Any symbols previously found by this loader instance will be unloaded
            and may not be accessed safely anymore.
         */
        ~Loader();

        /**
            \brief Locates a function in the library.

            This function is provided for typecasting safety, and may be equivalent
            to the find_data method on some platforms (e.g., POSIX).

            \param symbol  Name of the function in the library.  No name demangling
                              will be done on this name, so it is recommended to
                              use 'extern "C"' linkage where appropriate.

            \return Location of the function, as casted to the Fn type

            \throw NoSuchSymbol  Function could not be located
         */
        template< typename Fn >
        Fn find_function(const char *const symbol) throw(NoSuchSymbol)
        {
            return reinterpret_cast< Fn >(find_function(symbol));
        }

        /**
            \brief Locates a function in the library.

            This function is provided for typecasting safety, and may be equivalent
            to the find_data method on some platforms (e.g., POSIX).

            \param symbol  Name of the function in the library.  No name demangling
                              will be done on this name, so it is recommended to
                              use 'extern "C"' linkage where appropriate.

            \return Location of the function, as casted to the Fn type

            \throw NoSuchSymbol  Function could not be located
         */
        void (*find_function(const char *const symbol))() throw(NoSuchSymbol);

        /**
            \brief Locates a data symbol in the library.

            This function is provided for typecasting safety, and may be equivalent
            to the find_data method on some platforms (e.g., POSIX).

            \param symbol  Name of the symbol in the library.  No name demangling
                              will be done on this symbol, so it is recommended to
                              use 'extern "C"' linkage where appropriate.

            \return Location of the symbol, as casted to the Fn type

            \throw NoSuchSymbol  Named symbol could not be located
         */
        template< typename Fn >
        Fn find_data(const char *const symbol) throw(NoSuchSymbol)
        {
            return reinterpret_cast< Fn >(find_data(symbol));
        }

        /**
            \brief Locates a data symbol in the library.

            This function is provided for typecasting safety, and may be equivalent
            to the find_data method on some platforms (e.g., POSIX).

            \param symbol  Name of the symbol in the library.  No name demangling
                              will be done on this symbol, so it is recommended to
                              use 'extern "C"' linkage where appropriate.

            \return Location of the symbol

            \throw NoSuchSymbol  Named symbol could not be located
         */
        void *find_data(const char *const symbol) throw(NoSuchSymbol);

    private:
        LoaderData *pimpl;  //!< pimpl data

        void load(const char *const path, const char *const libname) throw(ItcLoader::CouldNotLoad);
    };
}

#endif /* ITC_LOADER_HPP */
